#!/usr/bin/env python3
"""Finite exact control of the fixed feature-minor formulas.

For each n=3,...,14 and two asymmetric positive source assignments, this
script compares the prefix/bordered-minor feature formulas with the existing
feature extractor.  It independently checks the full response, including z,
and for spike cases recomputes the response after moving p_{2L} to the
internal set.  It also checks the exact source-feature degeneration family
against direct source responses.  No base recovery or R_H reconstruction is
used here.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence

from verify_local_controls import graph_response
import verify_uniform_transform as transform


Q = Fraction
EPSILONS = (Q(1, 100), Q(1, 7), Q(2))


def sign(value: Fraction) -> int:
    return 1 if value > 0 else -1 if value < 0 else 0


def response_minor_by_labels(
    response: Sequence[Sequence[Fraction]],
    ports: Sequence[str],
    rows: Sequence[str],
    columns: Sequence[str],
) -> Fraction:
    row_indices = [ports.index(node) for node in rows]
    column_indices = [ports.index(node) for node in columns]
    return transform.response_minor(response, row_indices, column_indices)


def asymmetric_source_weights(graph: Mapping[str, Any], seed: int) -> dict[str, Fraction]:
    """Two deterministic, unequal, strictly positive assignments per n."""

    return {
        edge["id"]: Q(1) + Q((17 * index + 5 * seed) % 23, 100)
        for index, edge in enumerate(graph["edges"])
    }


def reduced_spike_graph(source: Mapping[str, Any], port: str) -> dict[str, Any]:
    if port not in source["ports"]:
        raise ValueError(f"spike port {port} is not a source port")
    return {
        "ports": [node for node in source["ports"] if node != port],
        "internal": list(source.get("internal", [])) + [port],
        "edges": [dict(edge) for edge in source["edges"]],
    }


def baseline_weights(graph: Mapping[str, Any], mode: str) -> dict[str, Fraction]:
    if mode == "all_one":
        return {edge["id"]: Q(1) for edge in graph["edges"]}
    if mode == "asymmetric":
        return {
            edge["id"]: Q(1) + Q((17 * index + 5) % 23, 100)
            for index, edge in enumerate(graph["edges"])
        }
    raise ValueError(f"unknown baseline mode {mode!r}")


def source_feature_spec(
    source: Mapping[str, Any], residue: int, layers: int
) -> tuple[str, str]:
    if residue in (3, 2):
        return ("c0_0" if residue == 3 else "b0"), "boundary_edge"
    return "spike_0", "spike"


def minor_delta(
    response: Sequence[Sequence[Fraction]],
    rows: Sequence[int],
    columns: Sequence[int],
    update: Sequence[Sequence[Fraction]],
) -> Fraction:
    before = transform.response_minor(response, rows, columns)
    after = transform.response_minor(transform.matrix_add(response, update), rows, columns)
    return after - before


def beta_minor(
    response: Sequence[Sequence[Fraction]],
    rows: Sequence[int],
    columns: Sequence[int],
    port_index: int,
) -> Fraction:
    rank_one = transform.rank_one_from_response(response, port_index)
    return minor_delta(response, rows, columns, rank_one)


def degeneration_case(
    n: int,
    layers: int,
    residue: int,
    source: Mapping[str, Any],
    base: Mapping[str, Any],
    target: Mapping[str, Any],
    P: Sequence[int],
    Q_indices: Sequence[int],
    baseline_mode: str,
    base_weights: Mapping[str, Fraction],
    base_response: Sequence[Sequence[Fraction]],
    epsilon: Fraction,
) -> dict[str, Any]:
    ports = list(source["ports"])
    source_feature_id, source_kind = source_feature_spec(source, residue, layers)
    source_weights = {
        edge["id"]: base_weights[edge["id"]]
        for edge in source["edges"]
        if edge["id"] != source_feature_id
    }
    if source_kind == "boundary_edge":
        source_weights[source_feature_id] = epsilon
    else:
        # A finite spike of conductance 1/epsilon realizes the prescribed
        # rank-one degeneration from the contracted source core H.
        source_weights[source_feature_id] = Q(1) / epsilon
    source_response = graph_response(source, source_weights)
    F0 = transform.response_minor(base_response, P, Q_indices)
    F_direct = transform.response_minor(source_response, P, Q_indices)
    source_port = 0
    if source_kind == "boundary_edge":
        source_edge = transform.edge_by_id(source, source_feature_id)
        source_update = transform.port_edge_matrix(ports, source_edge)
        kappa = minor_delta(base_response, P, Q_indices, source_update)
        F_expected = kappa * epsilon
    else:
        beta_F = beta_minor(base_response, P, Q_indices, source_port)
        kappa = -beta_F
        F_expected = kappa * epsilon / (Q(1) + epsilon * base_response[0][0])

    descriptor = transform.target_descriptor(target, n, layers, residue)
    checks: dict[str, bool] = {
        "source_response_valid": transform.validate_response(source_response, n + 1)["valid"],
        "base_F_zero": F0 == 0,
        "source_F_identity": F_direct == F_expected,
        "kappa_nonzero": kappa != 0,
    }
    data: dict[str, Any] = {
        "n": n,
        "layers_L": layers,
        "residue": residue,
        "baseline": baseline_mode,
        "epsilon": epsilon,
        "source_feature_id": source_feature_id,
        "source_feature_kind": source_kind,
        "target_feature_id": descriptor["edge_id"],
        "target_feature_kind": descriptor["kind"],
        "F0": F0,
        "F_direct": F_direct,
        "F_expected": F_expected,
        "kappa": kappa,
        "source_feature_conductance": source_weights[source_feature_id],
    }

    if descriptor["kind"] == "boundary_edge":
        G_rows = list(P[:-1])
        G_columns = list(Q_indices[:-1])
        G0 = transform.response_minor(base_response, G_rows, G_columns)
        if source_kind == "boundary_edge":
            D = minor_delta(base_response, G_rows, G_columns, source_update)
        else:
            beta_G = beta_minor(base_response, G_rows, G_columns, source_port)
            D = base_response[0][0] * G0 - beta_G
        denominator = G0 + epsilon * D
        q_formula = -kappa * epsilon / denominator if denominator != 0 else None
        target_edge = transform.edge_by_id(target, descriptor["edge_id"])
        target_update = transform.port_edge_matrix(ports, target_edge)
        target_delta = minor_delta(source_response, P, Q_indices, target_update)
        target_parameter = F_direct / target_delta if target_delta != 0 else None
        data.update(
            {
                "G0_prefix": G0,
                "D_prefix": D,
                "q_formula": q_formula,
                "target_delta": target_delta,
                "q_direct_parameter": target_parameter,
                "q_denominator": denominator,
            }
        )
        checks.update(
            {
                "q_denominator_nonzero": denominator != 0,
                "target_delta_nonzero": target_delta != 0,
                "q_formula_equals_direct": q_formula is not None and q_formula == target_parameter,
            }
        )
    else:
        t = 2 * layers
        C_rows = list(P) + [t]
        C_columns = list(Q_indices) + [t]
        C0 = transform.response_minor(base_response, C_rows, C_columns)
        if source_kind == "boundary_edge":
            D = minor_delta(base_response, C_rows, C_columns, source_update)
        else:
            beta_C = beta_minor(base_response, C_rows, C_columns, source_port)
            D = base_response[0][0] * C0 - beta_C
        h_formula = C0 / (kappa * epsilon) + D / kappa if kappa != 0 else None
        target_beta = beta_minor(source_response, P, Q_indices, t)
        target_parameter = (
            source_response[t][t] - target_beta / F_direct if F_direct != 0 else None
        )
        data.update(
            {
                "C0_bordered": C0,
                "D_bordered": D,
                "h_formula": h_formula,
                "target_beta": target_beta,
                "target_beta_nonzero": target_beta != 0,
                "h_direct_parameter": target_parameter,
            }
        )
        checks.update(
            {
                "target_F_nonzero": F_direct != 0,
                "h_formula_equals_direct": h_formula is not None and h_formula == target_parameter,
            }
        )
        # Optional only: the full contraction/stripping extractor has an
        # extra denominator proportional to target_beta.  It is deliberately
        # excluded from the direct-control pass/fail conditions.
        if target_beta != 0 and F_direct != 0:
            try:
                optional = transform.extract_target_parameter(target, base, source_response, n, layers, residue)
                data["optional_full_extraction"] = {
                    "parameter": optional["parameter"],
                    "division_checks": optional["division_checks"],
                    "matches_direct": optional["parameter"] == target_parameter,
                }
            except Exception as exc:
                data["optional_full_extraction"] = {
                    "error": f"{type(exc).__name__}: {exc}",
                    "matches_direct": False,
                }
        else:
            data["optional_full_extraction"] = {"skipped": True, "reason": "target_beta_zero_or_F_zero"}
    data["checks"] = checks
    data["all_checks_pass"] = all(checks.values())
    return data


def check_sample(n: int, seed: int) -> dict[str, Any]:
    source, layers, residue = transform.build_source(n)
    base, target = transform.build_base_and_target(source, n, layers, residue)
    P, Q_indices, k = transform.minor_indices(n, layers, residue)
    source_weights = asymmetric_source_weights(source, seed)
    source_response = graph_response(source, source_weights)
    ports = list(source["ports"])
    F = transform.response_minor(source_response, P, Q_indices)
    expected_F_sign = 1 if k % 2 == 0 else -1
    checks: dict[str, bool] = {
        "source_graph_valid": transform.validate_graph(source)["valid"],
        "base_graph_valid": transform.validate_graph(base)["valid"],
        "target_graph_valid": transform.validate_graph(target)["valid"],
        "source_response_valid": transform.validate_response(source_response, n + 1)["valid"],
        "source_weights_strictly_positive": all(weight > 0 for weight in source_weights.values()),
        "source_weights_asymmetric": len(set(source_weights.values())) > 1,
        "F_nonzero": F != 0,
        "F_sign_matches": sign(F) == expected_F_sign,
    }
    if not all(checks.values()):
        raise ValueError(f"initial source control failed for n={n}, seed={seed}: {checks}")

    descriptor = transform.target_descriptor(target, n, layers, residue)
    feature_id = descriptor["edge_id"]
    feature_kind = descriptor["kind"]

    data: dict[str, Any] = {
        "n": n,
        "seed": seed,
        "layers_L": layers,
        "residue": residue,
        "k": k,
        "source_edge_count": len(source["edges"]),
        "feature_kind": feature_kind,
        "feature_id": feature_id,
        "P": P,
        "Q": Q_indices,
        "F": F,
        "F_sign": sign(F),
        "expected_F_sign": expected_F_sign,
        "source_weight_min": min(source_weights.values()),
        "source_weight_max": max(source_weights.values()),
    }

    if feature_kind == "boundary_edge":
        edge = transform.edge_by_id(target, feature_id)
        edge_ports = {edge["u"], edge["v"]}
        expected_ports = {ports[P[-1]], ports[Q_indices[-1]]}
        prefix = transform.response_minor(source_response, P[:-1], Q_indices[:-1])
        target_update = transform.port_edge_matrix(ports, edge)
        target_delta = minor_delta(source_response, P, Q_indices, target_update)
        target_parameter = F / target_delta if target_delta != 0 else None
        expected_prefix_sign = 1 if (k - 1) % 2 == 0 else -1
        q_formula = -F / prefix
        data.update(
            {
                "target_edge_endpoints": sorted(edge_ports),
                "expected_last_pair": sorted(expected_ports),
                "target_edge_is_last_pair": edge_ports == expected_ports,
                "prefix_minor": prefix,
                "prefix_sign": sign(prefix),
                "expected_prefix_sign": expected_prefix_sign,
                "q_prefix_formula": q_formula,
                "target_delta": target_delta,
                "q_direct_parameter": target_parameter,
            }
        )
        checks.update(
            {
                "target_edge_is_last_pair": edge_ports == expected_ports,
                "prefix_nonzero": prefix != 0,
                "target_delta_nonzero": target_delta != 0,
                "prefix_sign_matches": sign(prefix) == expected_prefix_sign,
                "q_formula_strictly_positive": q_formula > 0,
                "q_formula_equals_direct": target_parameter is not None and q_formula == target_parameter,
            }
        )
    else:
        p_label = f"p{2 * layers}"
        p_index = ports.index(p_label)
        bordered = transform.response_minor(source_response, P + [p_index], Q_indices + [p_index])
        expected_C_sign = expected_F_sign
        h_formula = bordered / F
        target_beta = beta_minor(source_response, P, Q_indices, p_index)
        target_parameter = source_response[p_index][p_index] - target_beta / F
        reduced = reduced_spike_graph(source, p_label)
        reduced_response = graph_response(reduced, source_weights)
        reduced_ports = list(reduced["ports"])
        reduced_F = response_minor_by_labels(
            reduced_response,
            reduced_ports,
            [ports[index] for index in P],
            [ports[index] for index in Q_indices],
        )
        M_pp = source_response[p_index][p_index]
        beta = M_pp * F - bordered
        data.update(
            {
                "spike_port": p_label,
                "spike_port_index": p_index,
                "M_pp": M_pp,
                "bordered_minor_C": bordered,
                "C_sign": sign(bordered),
                "expected_C_sign": expected_C_sign,
                "target_beta": target_beta,
                "target_beta_matches_C_identity": target_beta == beta,
                "target_beta_nonzero": target_beta != 0,
                "h_bordered_formula": h_formula,
                "h_direct_parameter": target_parameter,
                "reduced_ports": reduced_ports,
                "reduced_F": reduced_F,
                "reduced_identity_rhs": M_pp * reduced_F,
                "reduced_response_valid": transform.validate_response(reduced_response, n)["valid"],
            }
        )
        checks.update(
            {
                "spike_port_outside_PQ": p_index not in P and p_index not in Q_indices,
                "bordered_minor_nonzero": bordered != 0,
                "C_sign_matches": sign(bordered) == expected_C_sign,
                "M_pp_nonzero": M_pp != 0,
                "h_formula_strictly_positive": h_formula > 0,
                "h_formula_equals_direct": h_formula == target_parameter,
                "reduced_response_valid": transform.validate_response(reduced_response, n)["valid"],
                "reduced_bordered_identity": bordered == M_pp * reduced_F,
            }
        )

        # The full contraction/stripping extractor has an extra denominator
        # proportional to target_beta.  It is only an optional comparison
        # when that beta is nonzero; the direct minor formula above is the
        # actual control and does not depend on this stripping step.
        if target_beta != 0:
            optional = transform.extract_target_parameter(target, base, source_response, n, layers, residue)
            data["optional_full_extraction"] = {
                "parameter": optional["parameter"],
                "division_checks": optional["division_checks"],
                "matches_direct": optional["parameter"] == target_parameter,
            }
        else:
            data["optional_full_extraction"] = {"skipped": True, "reason": "target_beta_zero"}

    data["checks"] = checks
    data["all_checks_pass"] = all(checks.values())
    return data


def degeneration_controls() -> list[dict[str, Any]]:
    cases: list[dict[str, Any]] = []
    for n in range(3, 15):
        source, layers, residue = transform.build_source(n)
        base, target = transform.build_base_and_target(source, n, layers, residue)
        P, Q_indices, _ = transform.minor_indices(n, layers, residue)
        for baseline_mode in ("all_one", "asymmetric"):
            base_weights = baseline_weights(base, baseline_mode)
            base_response = graph_response(base, base_weights)
            for epsilon in EPSILONS:
                try:
                    cases.append(
                        degeneration_case(
                            n,
                            layers,
                            residue,
                            source,
                            base,
                            target,
                            P,
                            Q_indices,
                            baseline_mode,
                            base_weights,
                            base_response,
                            epsilon,
                        )
                    )
                except Exception as exc:
                    cases.append(
                        {
                            "n": n,
                            "layers_L": layers,
                            "residue": residue,
                            "baseline": baseline_mode,
                            "epsilon": epsilon,
                            "all_checks_pass": False,
                            "failure": f"{type(exc).__name__}: {exc}",
                        }
                    )
    return cases


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve()
    parser.add_argument("--output", type=Path, default=here.parent / "feature_minor_certificate.json")
    args = parser.parse_args(argv)
    cases: list[dict[str, Any]] = []
    for n in range(3, 15):
        for seed in (1, 2):
            try:
                cases.append(check_sample(n, seed))
            except Exception as exc:
                cases.append(
                    {
                        "n": n,
                        "seed": seed,
                        "all_checks_pass": False,
                        "failure": f"{type(exc).__name__}: {exc}",
                    }
                )
    degeneration_cases = degeneration_controls()
    all_cases_pass = all(case.get("all_checks_pass", False) for case in cases)
    all_degeneration_pass = all(case.get("all_checks_pass", False) for case in degeneration_cases)
    certificate = {
        "scope": "Finite exact feature-minor control for n=3,...,14 with two asymmetric positive source assignments per n. It compares the prefix/bordered formulas to the direct F/Delta and Mpp-beta/F formulas and independently checks spike reduction; the full stripping extractor is only an optional comparison when its beta denominator is nonzero. It also checks the exact source-feature degeneration family for all-one and asymmetric contracted source cores at epsilon=1/100,1/7,2. It does not run R_H or prove the uniform theorem.",
        "feature_rules": {
            "edge": "Delta_t=-det M[P[:-1],Q[:-1]], q=-F/prefix",
            "spike": "C=det M[P+[p],Q+[p]]=M_pp F-beta_p(M), h=C/F",
        },
        "sample_count": len(cases),
        "expected_sample_count": 24,
        "cases": cases,
        "all_cases_pass": all_cases_pass,
        "all_feature_formulas_pass": all(
            case.get("checks", {}).get("q_formula_equals_direct", case.get("checks", {}).get("h_formula_equals_direct", False))
            for case in cases
        ),
        "all_sign_checks_pass": all(
            case.get("checks", {}).get("F_sign_matches", False)
            and case.get("checks", {}).get("prefix_sign_matches", case.get("checks", {}).get("C_sign_matches", False))
            for case in cases
        ),
        "degeneration_rules": {
            "source_edge": "kappa=Delta_source^F(M0), q(epsilon)=-kappa*epsilon/(G0+epsilon*D), h(epsilon)=C0/(kappa*epsilon)+D/kappa",
            "source_spike": "kappa=-beta_0^F(M0), q(epsilon)=-kappa*epsilon/(G0+epsilon*D), h(epsilon)=C0/(kappa*epsilon)+D/kappa",
            "source_spike_conductance": "1/epsilon",
            "D": "Delta_source^G or Delta_source^C for a source edge; M00*minor-beta_0^minor for a source spike",
        },
        "degeneration_sample_count": len(degeneration_cases),
        "expected_degeneration_sample_count": 72,
        "degeneration_cases": degeneration_cases,
        "all_degeneration_pass": all_degeneration_pass,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(transform.exact_json(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"certificate: {args.output.resolve()}")
    print(f"samples: {len(cases)}/24")
    print(f"all_cases_pass: {all_cases_pass}")
    print(f"all_feature_formulas_pass: {certificate['all_feature_formulas_pass']}")
    print(f"all_sign_checks_pass: {certificate['all_sign_checks_pass']}")
    print(f"degeneration_samples: {len(degeneration_cases)}/72")
    print(f"all_degeneration_pass: {all_degeneration_pass}")
    return 0 if all_cases_pass and all_degeneration_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())
