#!/usr/bin/env python3
"""Finite exact checks for inverse recovery and common local support.

The calculation is deliberately a certificate generator.  It tests the
common-minor inverse, the target circular projection, and the prescribed
edge-then-spike support reduction on the finite samples used by the uniform
transform control.  It is not a proof of the all-n uniform construction.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence

from verify_local_controls import graph_response
import verify_uniform_transform as u


Q = Fraction


class AlgorithmError(RuntimeError):
    """A finite exact topology or division obstruction."""


def matrix_equal(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> bool:
    return len(left) == len(right) and all(
        len(a) == len(b) and all(x == y for x, y in zip(a, b))
        for a, b in zip(left, right)
    )


def edge_sort_key(edge_id: str) -> str:
    # The prescribed order is the literal edge-id order used by the existing
    # graph generators and by the finite support control.
    return edge_id


def endpoint_pair(edge: Mapping[str, str]) -> tuple[str, str]:
    return tuple(sorted((edge["u"], edge["v"])))


def p_index(node: str, n: int) -> int | None:
    if not node.startswith("p"):
        return None
    try:
        index = int(node[1:])
    except ValueError:
        return None
    return index if 0 <= index < n else None


def edge_degree(graph: Mapping[str, Any], node: str) -> int:
    return sum(node in (edge["u"], edge["v"]) for edge in graph["edges"])


def division(
    records: list[dict[str, Any]],
    name: str,
    numerator: Fraction,
    denominator: Fraction,
) -> None:
    records.append(
        {
            "name": name,
            "numerator": numerator,
            "denominator": denominator,
            "nonzero": denominator != 0,
        }
    )
    if denominator == 0:
        raise AlgorithmError(f"zero denominator in {name}")


def source_feature(n: int, residue: int) -> dict[str, Any]:
    if residue == 3:
        return {"kind": "boundary_edge", "edge_id": "c0_0", "port_index": None}
    if residue == 2:
        return {"kind": "boundary_edge", "edge_id": "b0", "port_index": None}
    return {"kind": "spike", "edge_id": "spike_0", "port_index": 0}


def source_inverse_case(
    n: int,
    source: Mapping[str, Any],
    base: Mapping[str, Any],
    layers: int,
    residue: int,
    source_weights: Mapping[str, Fraction],
    source_response: Sequence[Sequence[Fraction]],
) -> dict[str, Any]:
    """Strip the source feature, recover the base, and put the feature back."""

    feature = source_feature(n, residue)
    feature_id = feature["edge_id"]
    if feature["kind"] == "boundary_edge":
        after = u.remove_edge(source, feature_id)
        topology_match = u.edge_endpoint_map(after) == u.edge_endpoint_map(base)
    else:
        port = source["ports"][feature["port_index"]]
        degree_before = edge_degree(source, port)
        if degree_before != 1:
            raise AlgorithmError(f"source feature {feature_id} has port degree {degree_before}, expected 1")
        after = u.contract_port_edge(source, feature_id, port)
        topology_match = u.edge_endpoint_map(after) == u.edge_endpoint_map(base)

    P, Q_indices, k = u.minor_indices(n, layers, residue)
    before_linkage = u.linkage_count(source, P, Q_indices)
    after_linkage = u.linkage_count(after, P, Q_indices)
    if before_linkage != k or after_linkage >= k:
        raise AlgorithmError(
            f"source common minor is not a witness: before={before_linkage}, after={after_linkage}, k={k}"
        )
    M = [list(row) for row in source_response]
    F = u.response_minor(M, P, Q_indices)
    divisions: list[dict[str, Any]] = []
    if feature["kind"] == "boundary_edge":
        edge = u.edge_by_id(source, feature_id)
        update = u.port_edge_matrix(source["ports"], edge)
        D = u.response_minor(u.matrix_add(M, update), P, Q_indices) - F
        division(divisions, f"source_edge:{feature_id}:D", F, D)
        coefficient = F / D
        stripped = u.matrix_sub(M, u.matrix_scale(update, coefficient))
        coefficient_formula = "F_over_D"
    else:
        port_index = feature["port_index"]
        rank_one = u.rank_one_from_response(M, port_index)
        B = u.response_minor(u.matrix_add(M, rank_one), P, Q_indices) - F
        division(divisions, f"source_spike:{feature_id}:F", B, F)
        coefficient = M[port_index][port_index] - B / F
        denominator = coefficient - M[port_index][port_index]
        division(divisions, f"source_spike:{feature_id}:c-Mpp", Q(1), denominator)
        stripped = u.matrix_add(M, u.matrix_scale(rank_one, Q(1) / denominator))
        coefficient_formula = "Mpp_minus_B_over_F"

    recovery = u.recover_base_weights(base, stripped, n, layers, residue)
    recovered_source_weights = dict(recovery["weights"])
    recovered_source_weights[feature_id] = coefficient
    recovered_response = graph_response(source, recovered_source_weights)
    shared_ids = sorted(recovery["weights"])
    shared_exact = all(recovery["weights"][edge_id] == source_weights[edge_id] for edge_id in shared_ids)
    source_exact = all(recovered_source_weights[edge_id] == source_weights[edge_id] for edge_id in source_weights)
    checks = {
        "source_feature_topology_match": topology_match,
        "common_minor_is_source_witness": before_linkage == k and after_linkage < k,
        "source_feature_recovered_exact": coefficient == source_weights[feature_id],
        "shared_weights_recovered_exact": shared_exact,
        "all_source_weights_recovered_exact": source_exact,
        "reconstructed_response_exact": u.matrix_residual(M, recovered_response) == 0,
        "source_response_valid": u.validate_response(M, len(source["ports"]))["valid"],
        "recovered_response_valid": u.validate_response(recovered_response, len(source["ports"]))["valid"],
        "all_divisions_nonzero": all(item["nonzero"] for item in divisions + recovery["division_checks"]),
        "recovery_checks": all(recovery["checks"].values()),
    }
    return {
        "feature": feature,
        "feature_formula": coefficient_formula,
        "feature_coefficient": coefficient,
        "source_feature_original_weight": source_weights[feature_id],
        "minor": {"P": P, "Q": Q_indices, "k": k, "F": F, "before_linkage": before_linkage, "after_linkage": after_linkage},
        "degree_before": edge_degree(source, source["ports"][feature["port_index"]]) if feature["kind"] == "spike" else None,
        "recovered_shared_weights": recovery["weights"],
        "reconstructed_source_weights": recovered_source_weights,
        "division_checks": divisions + recovery["division_checks"],
        "residual": u.matrix_residual(M, recovered_response),
        "checks": checks,
        "all_checks_pass": all(checks.values()),
    }


def remove_center_star(graph: Mapping[str, Any]) -> dict[str, Any]:
    """Project to the circle-port graph without Schur-eliminating the centre."""

    return {
        "ports": [node for node in graph["ports"] if node != "z"],
        "internal": list(graph.get("internal", [])),
        "edges": [
            dict(edge)
            for edge in graph["edges"]
            if edge["u"] != "z" and edge["v"] != "z"
        ],
    }


def target_circle_recovery_case(
    n: int,
    source: Mapping[str, Any],
    base: Mapping[str, Any],
    target: Mapping[str, Any],
    layers: int,
    residue: int,
) -> dict[str, Any]:
    """Recover an all-one target from its centre-free circular response."""

    circle_base = remove_center_star(base)
    circle_target = remove_center_star(target)
    target_weights = u.all_one(circle_target)
    response = graph_response(circle_target, target_weights)
    extracted = u.extract_target_parameter(circle_target, circle_base, response, n, layers, residue)
    recovery = u.recover_base_weights(
        circle_base, extracted["stripped_response"], n, layers, residue
    )
    reconstructed = {edge["id"]: recovery["weights"][edge["id"]] for edge in circle_base["edges"]}
    feature_id = extracted["descriptor"]["edge_id"]
    reconstructed[feature_id] = extracted["parameter"]
    reconstructed_response = graph_response(circle_target, reconstructed)
    no_center = all("z" not in (edge["u"], edge["v"]) for edge in circle_target["edges"])
    all_one_target = all(weight == Q(1) for weight in reconstructed.values())
    checks = {
        "circle_base_valid": u.validate_graph(circle_base)["valid"],
        "circle_target_valid": u.validate_graph(circle_target)["valid"],
        "centre_removed_without_schur": "z" not in circle_target["ports"] and no_center,
        "target_parameter_recovered_one": extracted["parameter"] == Q(1),
        "base_weights_recovered_one": all(weight == Q(1) for weight in recovery["weights"].values()),
        "all_target_circle_weights_recovered_one": all_one_target,
        "reconstructed_response_exact": u.matrix_residual(response, reconstructed_response) == 0,
        "all_divisions_nonzero": all(
            item["nonzero"] for item in extracted["division_checks"] + recovery["division_checks"]
        ),
        "recovery_checks": all(recovery["checks"].values()),
    }
    return {
        "circle_port_count": len(circle_target["ports"]),
        "circle_edge_count": len(circle_target["edges"]),
        "feature": extracted["descriptor"],
        "feature_parameter": extracted["parameter"],
        "recovered_weights": recovery["weights"],
        "reconstructed_target_weights": reconstructed,
        "division_checks": extracted["division_checks"] + recovery["division_checks"],
        "residual": u.matrix_residual(response, reconstructed_response),
        "checks": checks,
        "all_checks_pass": all(checks.values()),
    }


def is_outer_boundary(edge: Mapping[str, str], n: int) -> bool:
    u_index = p_index(edge["u"], n)
    v_index = p_index(edge["v"], n)
    if u_index is None or v_index is None or u_index == v_index:
        return False
    return (u_index - v_index) % n in (1, n - 1)


def common_spike_port(
    left: Mapping[str, Any], right: Mapping[str, Any], edge_left: Mapping[str, str], edge_right: Mapping[str, str], n: int
) -> tuple[int, str] | None:
    if endpoint_pair(edge_left) != endpoint_pair(edge_right):
        return None
    for node in (edge_left["u"], edge_left["v"]):
        index = p_index(node, n)
        if index is None or node not in left["ports"] or node not in right["ports"]:
            continue
        other_left = edge_left["v"] if edge_left["u"] == node else edge_left["u"]
        other_right = edge_right["v"] if edge_right["u"] == node else edge_right["u"]
        if other_left != other_right:
            continue
        if other_left not in left.get("internal", []) or other_right not in right.get("internal", []):
            continue
        if edge_degree(left, node) != 1 or edge_degree(right, node) != 1:
            continue
        return index, other_left
    return None


def common_candidates(left: Mapping[str, Any], right: Mapping[str, Any], n: int) -> tuple[list[str], list[str]]:
    left_edges = {edge["id"]: edge for edge in left["edges"]}
    right_edges = {edge["id"]: edge for edge in right["edges"]}
    edge_candidates: list[str] = []
    spike_candidates: list[str] = []
    for edge_id in sorted(set(left_edges) & set(right_edges), key=edge_sort_key):
        edge_left, edge_right = left_edges[edge_id], right_edges[edge_id]
        if endpoint_pair(edge_left) != endpoint_pair(edge_right):
            continue
        if is_outer_boundary(edge_left, n) and is_outer_boundary(edge_right, n):
            edge_candidates.append(edge_id)
            continue
        if common_spike_port(left, right, edge_left, edge_right, n) is not None:
            spike_candidates.append(edge_id)
    return edge_candidates, spike_candidates


def common_support_case(
    n: int,
    source: Mapping[str, Any],
    target: Mapping[str, Any],
    source_weights: Mapping[str, Fraction],
    target_weights: Mapping[str, Fraction],
    source_response: Sequence[Sequence[Fraction]],
    layers: int,
    residue: int,
) -> dict[str, Any]:
    """Perform the fixed edge-first, then spike, common-support reduction."""

    left = u.clone_graph(source)
    right = u.clone_graph(target)
    left_weights = dict(source_weights)
    right_weights = dict(target_weights)
    left_response = [list(row) for row in source_response]
    right_response = graph_response(right, right_weights)
    divisions: list[dict[str, Any]] = []
    operations: list[dict[str, Any]] = []
    failures: list[str] = []
    initial_response_equal = u.matrix_residual(left_response, right_response) == 0

    while not failures:
        edge_candidates, spike_candidates = common_candidates(left, right, n)
        if edge_candidates:
            edge_id = edge_candidates[0]
            operation = "delete_common_boundary_edge"
        elif spike_candidates:
            edge_id = spike_candidates[0]
            operation = "contract_common_spike"
        else:
            break
        edge_left = u.edge_by_id(left, edge_id)
        edge_right = u.edge_by_id(right, edge_id)
        before_left = u.clone_graph(left)
        before_right = u.clone_graph(right)
        if operation == "delete_common_boundary_edge":
            after_left = u.remove_edge(left, edge_id)
            after_right = u.remove_edge(right, edge_id)
            witness = u.find_witness(left, after_left, n)
            port_index = None
            old_internal = None
        else:
            spike = common_spike_port(left, right, edge_left, edge_right, n)
            if spike is None:
                failures.append(f"common spike classification disappeared for {edge_id}")
                break
            port_index, old_internal = spike
            port = left["ports"][port_index]
            if edge_degree(left, port) != 1 or edge_degree(right, port) != 1:
                failures.append(f"common spike {edge_id} does not have degree-one port {port}")
                break
            after_left = u.contract_port_edge(left, edge_id, port)
            after_right = u.contract_port_edge(right, edge_id, port)
            witness = u.find_witness(left, after_left, n, exclude_ports=(port_index,))
        if witness is None:
            failures.append(f"no left linkage witness for {operation}:{edge_id}")
            break
        P, Q_indices, k = witness["P"], witness["Q"], witness["k"]
        right_before_linkage = u.linkage_count(right, P, Q_indices)
        right_after_linkage = u.linkage_count(after_right, P, Q_indices)
        same_right_witness = (
            right_before_linkage == witness["before_linkage"]
            and right_after_linkage == witness["after_linkage"]
            and right_before_linkage == k
            and right_after_linkage < k
        )
        if not same_right_witness:
            failures.append(
                f"right linkage does not match left witness for {edge_id}: "
                f"left={witness['before_linkage']}->{witness['after_linkage']}, "
                f"right={right_before_linkage}->{right_after_linkage}"
            )
            break

        F = u.response_minor(left_response, P, Q_indices)
        if operation == "delete_common_boundary_edge":
            update = u.port_edge_matrix(left["ports"], edge_left)
            D = u.response_minor(u.matrix_add(left_response, update), P, Q_indices) - F
            division(divisions, f"common_edge:{edge_id}:D", F, D)
            coefficient = F / D
            next_response = u.matrix_sub(left_response, u.matrix_scale(update, coefficient))
            denominator = D
        else:
            rank_one = u.rank_one_from_response(left_response, port_index)
            B = u.response_minor(u.matrix_add(left_response, rank_one), P, Q_indices) - F
            division(divisions, f"common_spike:{edge_id}:F", B, F)
            coefficient = left_response[port_index][port_index] - B / F
            denominator = coefficient - left_response[port_index][port_index]
            division(divisions, f"common_spike:{edge_id}:c-Mpp", Q(1), denominator)
            next_response = u.matrix_add(left_response, u.matrix_scale(rank_one, Q(1) / denominator))

        left_coefficient = left_weights[edge_id]
        right_coefficient = right_weights[edge_id]
        coefficients_exact = coefficient == left_coefficient == right_coefficient
        if not coefficients_exact:
            failures.append(
                f"coefficient mismatch for {edge_id}: extracted={coefficient}, "
                f"left={left_coefficient}, right={right_coefficient}"
            )
            break

        left = after_left
        right = after_right
        del left_weights[edge_id]
        del right_weights[edge_id]
        left_response = next_response
        right_response = next_response
        left_valid = u.validate_graph(left)["valid"]
        right_valid = u.validate_graph(right)["valid"]
        local_left = graph_response(left, left_weights)
        local_right = graph_response(right, right_weights)
        residual_left = u.matrix_residual(left_response, local_left)
        residual_right = u.matrix_residual(right_response, local_right)
        old_promoted = True
        if operation == "contract_common_spike":
            port = left["ports"][port_index]
            old_promoted = (
                port in left["ports"]
                and port in right["ports"]
                and old_internal not in left.get("internal", [])
                and old_internal not in right.get("internal", [])
            )
        op_record = {
            "operation": operation,
            "edge_id": edge_id,
            "coefficient": coefficient,
            "source_weight": left_coefficient,
            "target_weight": right_coefficient,
            "endpoint_before": {"source": endpoint_pair(edge_left), "target": endpoint_pair(edge_right)},
            "endpoint_after": {
                "source": sorted([endpoint_pair(edge) for edge in left["edges"] if edge["id"] == edge_id]),
                "target": sorted([endpoint_pair(edge) for edge in right["edges"] if edge["id"] == edge_id]),
            },
            "witness": witness,
            "right_linkage": {"before": right_before_linkage, "after": right_after_linkage},
            "division_denominator": denominator,
            "port_index": port_index,
            "contracted_internal_neighbor": old_internal,
            "source_port_degree_before": edge_degree(before_left, before_left["ports"][port_index]) if port_index is not None else None,
            "target_port_degree_before": edge_degree(before_right, before_right["ports"][port_index]) if port_index is not None else None,
            "old_internal_promoted_to_interface": old_promoted,
            "graph_valid": left_valid and right_valid,
            "response_residual_source": residual_left,
            "response_residual_target": residual_right,
            "full_local_response_equal": residual_left == 0 and residual_right == 0,
            "common_coefficient_exact": coefficients_exact,
        }
        operations.append(op_record)
        if not (left_valid and right_valid and old_promoted and residual_left == 0 and residual_right == 0):
            failures.append(f"local support invariant failed after {edge_id}")
            break

    expected_counts = {3: 6, 4: 9, 5: 13, 6: 17, 7: 22}
    final_count = len(left["edges"])
    count_check = final_count == expected_counts[n] if n in expected_counts else True
    checks = {
        "initial_full_response_equal": initial_response_equal,
        "all_divisions_nonzero": all(item["nonzero"] for item in divisions),
        "no_operation_failure": not failures,
        "source_target_edge_count_equal": len(left["edges"]) == len(right["edges"]),
        "z_retained_as_protected_port": "z" in left["ports"] and "z" in right["ports"],
        "all_local_operations_exact": all(
            item["full_local_response_equal"] and item["common_coefficient_exact"] for item in operations
        ),
        "expected_local_edge_count": count_check,
    }
    return {
        "initial_edge_count": len(source["edges"]),
        "initial_target_edge_count": len(target["edges"]),
        "operations": operations,
        "division_checks": divisions,
        "final_source_graph": left,
        "final_target_graph": right,
        "final_source_weights": left_weights,
        "final_target_weights": right_weights,
        "remaining_edge_count": final_count,
        "remaining_edge_ids": sorted(edge["id"] for edge in left["edges"]),
        "support_count_only_for_n": [] if n <= 7 else [n],
        "failures": failures,
        "checks": checks,
        "all_checks_pass": all(checks.values()),
    }


def attachment_response(
    core_response: Sequence[Sequence[Fraction]],
    operations: Sequence[Mapping[str, Any]],
    ports: Sequence[str],
    external_weights: Mapping[str, Fraction],
) -> tuple[list[list[Fraction]], list[dict[str, Any]]]:
    """Reverse the recorded boundary removals on a fixed core response.

    A deletion is reversed by adding its port-port edge.  A contracted spike
    is reversed by the rank-one formula
    ``N-col_i row_i/(a+N_ii)``.  The logical port slots are retained through
    every contraction, exactly as in the common-support construction.
    """

    response = [list(row) for row in core_response]
    pivots: list[dict[str, Any]] = []
    for operation in reversed(list(operations)):
        edge_id = operation["edge_id"]
        conductance = external_weights[edge_id]
        if operation["operation"] == "delete_common_boundary_edge":
            endpoints = operation["endpoint_before"]["source"]
            update = u.port_edge_matrix(ports, {"id": edge_id, "u": endpoints[0], "v": endpoints[1]})
            response = u.matrix_add(response, u.matrix_scale(update, conductance))
            pivots.append(
                {
                    "edge_id": edge_id,
                    "operation": "add_boundary_edge",
                    "conductance": conductance,
                    "pivot": Q(1),
                    "nonzero": True,
                }
            )
            continue
        if operation["operation"] != "contract_common_spike":
            raise AlgorithmError(f"unknown support operation {operation['operation']!r}")
        port_index = operation["port_index"]
        denominator = conductance + response[port_index][port_index]
        pivots.append(
            {
                "edge_id": edge_id,
                "operation": "add_boundary_spike",
                "port_index": port_index,
                "conductance": conductance,
                "pivot": denominator,
                "nonzero": denominator != 0,
            }
        )
        if denominator == 0:
            raise AlgorithmError(f"zero attachment spike pivot for {edge_id}")
        rank_one = u.rank_one_from_response(response, port_index)
        response = u.matrix_sub(response, u.matrix_scale(rank_one, Q(1) / denominator))
    return response, pivots


def full_target_transform_from_response(
    M: Sequence[Sequence[Fraction]],
    n: int,
    base: Mapping[str, Any],
    target: Mapping[str, Any],
    layers: int,
    residue: int,
) -> dict[str, Any]:
    """Apply the same fixed target-feature extraction and base recovery as T_n."""

    extracted = u.extract_target_parameter(target, base, M, n, layers, residue)
    recovery = u.recover_base_weights(base, extracted["stripped_response"], n, layers, residue)
    weights = {edge["id"]: recovery["weights"][edge["id"]] for edge in base["edges"]}
    feature_id = extracted["descriptor"]["edge_id"]
    weights[feature_id] = extracted["parameter"]
    response = graph_response(target, weights)
    divisions = extracted["division_checks"] + recovery["division_checks"]
    return {
        "weights": weights,
        "response": response,
        "parameter": extracted["parameter"],
        "divisions": divisions,
        "extracted": extracted,
        "recovery": recovery,
    }


def local_parameter_independence_case(
    n: int,
    source: Mapping[str, Any],
    base: Mapping[str, Any],
    target: Mapping[str, Any],
    layers: int,
    residue: int,
    source_weights: Mapping[str, Fraction],
    target_weights: Mapping[str, Fraction],
    locality: Mapping[str, Any],
) -> dict[str, Any]:
    """Check that the recovered core map is independent of common exterior data."""

    core_source_graph = locality["final_source_graph"]
    core_target_graph = locality["final_target_graph"]
    core_source_weights = locality["final_source_weights"]
    core_target_weights = locality["final_target_weights"]
    operations = locality["operations"]
    removed_ids = [operation["edge_id"] for operation in operations]
    core_source_response = graph_response(core_source_graph, core_source_weights)
    core_source_positive = all(weight > 0 for weight in core_source_weights.values())
    core_target_positive = all(weight > 0 for weight in core_target_weights.values())
    cases: list[dict[str, Any]] = []

    original_external = {edge_id: source_weights[edge_id] for edge_id in removed_ids}
    attachment_specs = [
        ("A_original", None, original_external),
        ("A_1", Q(1), {edge_id: Q(1) for edge_id in removed_ids}),
        ("A_2", Q(2), {edge_id: Q(2) for edge_id in removed_ids}),
    ]
    for name, uniform_external, external_weights in attachment_specs:
        attached_source_weights = {}
        for edge in source["edges"]:
            edge_id = edge["id"]
            attached_source_weights[edge_id] = (
                core_source_weights[edge_id] if edge_id in core_source_weights else external_weights[edge_id]
            )
        direct_source_response = graph_response(source, attached_source_weights)
        attached_response, pivots = attachment_response(
            core_source_response, operations, source["ports"], external_weights
        )
        full_transform = full_target_transform_from_response(
            attached_response, n, base, target, layers, residue
        )
        target_output_weights = full_transform["weights"]
        target_output_response = full_transform["response"]
        target_core_exact = all(
            target_output_weights[edge_id] == core_target_weights[edge_id]
            for edge_id in core_target_weights
        )
        target_external_exact = all(
            target_output_weights[edge_id] == external_weights[edge_id]
            for edge_id in removed_ids
        )
        target_original_exact = name != "A_original" or all(
            target_output_weights[edge_id] == target_weights[edge_id]
            for edge_id in target_weights
        )
        source_response_residual = u.matrix_residual(direct_source_response, attached_response)
        target_response_residual = u.matrix_residual(attached_response, target_output_response)
        checks = {
            "attachment_response_exact": source_response_residual == 0,
            "all_attachment_pivots_nonzero": all(item["nonzero"] for item in pivots),
            "source_core_fixed": all(
                attached_source_weights[edge_id] == core_source_weights[edge_id]
                for edge_id in core_source_weights
            ),
            "target_core_coefficients_exact": target_core_exact,
            "target_external_coefficients_exact": target_external_exact,
            "target_original_coefficients_exact": target_original_exact,
            "target_full_response_exact": target_response_residual == 0,
            "source_core_weights_positive": core_source_positive,
            "target_core_weights_positive": core_target_positive,
            "target_full_weights_positive": all(weight > 0 for weight in target_output_weights.values()),
            "all_transform_divisions_nonzero": all(item["nonzero"] for item in full_transform["divisions"]),
        }
        cases.append(
            {
                "name": name,
                "external_conductance": uniform_external,
                "external_ids": removed_ids,
                "external_input_weights": external_weights,
                "attachment_pivots": pivots,
                "target_core_weights": {
                    edge_id: target_output_weights[edge_id] for edge_id in core_target_weights
                },
                "target_external_weights": {
                    edge_id: target_output_weights[edge_id] for edge_id in removed_ids
                },
                "source_response_residual": source_response_residual,
                "target_response_residual": target_response_residual,
                "checks": checks,
                "all_checks_pass": all(checks.values()),
            }
        )
    checks = {
        "core_source_response_valid": u.validate_response(core_source_response, len(source["ports"]))["valid"],
        "core_source_weights_positive": core_source_positive,
        "core_target_weights_positive": core_target_positive,
        "all_attachment_variants_pass": all(case["all_checks_pass"] for case in cases),
    }
    return {
        "scope": "Semantic local parameter-independence control using the recorded common support and the fixed F_target plus R_H transform.",
        "removed_edge_ids": removed_ids,
        "core_source_edge_count": len(core_source_graph["edges"]),
        "core_target_edge_count": len(core_target_graph["edges"]),
        "variants": cases,
        "checks": checks,
        "all_checks_pass": all(checks.values()),
    }


def sample_case(n: int, asymmetric: bool = False) -> dict[str, Any]:
    source, layers, residue = u.build_source(n)
    base, target = u.build_base_and_target(source, n, layers, residue)
    shared = u.asymmetric_shared_weights(n) if asymmetric else None
    sample_name = "asymmetric_shared_edges_n7_n10" if asymmetric else "all_one_shared_edges"
    epsilon = Q(1, 100)
    source_weights, feature_id, feature_weight = u.source_weights_for_epsilon(
        source, residue, epsilon, shared
    )
    attempt = u.source_transform_attempt(
        n, source, base, target, layers, residue, epsilon, shared
    )
    if not attempt.get("positive_sample"):
        raise AlgorithmError(f"source positive sample failed for n={n}, asymmetric={asymmetric}")
    source_response = attempt["source_response"]
    inverse = source_inverse_case(
        n, source, base, layers, residue, source_weights, source_response
    )
    circle = target_circle_recovery_case(n, source, base, target, layers, residue)
    locality = common_support_case(
        n,
        source,
        target,
        source_weights,
        attempt["target_weights"],
        source_response,
        layers,
        residue,
    )
    local_independence = (
        local_parameter_independence_case(
            n,
            source,
            base,
            target,
            layers,
            residue,
            source_weights,
            attempt["target_weights"],
            locality,
        )
        if asymmetric and n >= 7
        else {"status": "not_run_for_n_below_7_or_uniform_sample", "all_checks_pass": True}
    )
    return {
        "n": n,
        "residue": residue,
        "layers_L": layers,
        "sample_name": sample_name,
        "epsilon": epsilon,
        "source_feature": {"id": feature_id, "weight": feature_weight},
        "target_feature": {
            "id": attempt["target_parameter"]["descriptor"]["edge_id"],
            "weight": attempt["target_parameter"]["parameter"],
        },
        "inverse": inverse,
        "target_circle_recovery": circle,
        "common_support": locality,
        "local_parameter_independence": local_independence,
        "checks": {
            "inverse": inverse["all_checks_pass"],
            "target_circle_recovery": circle["all_checks_pass"],
            "common_support": locality["all_checks_pass"],
            "local_parameter_independence": local_independence["all_checks_pass"],
        },
        "all_checks_pass": (
            inverse["all_checks_pass"]
            and circle["all_checks_pass"]
            and locality["all_checks_pass"]
            and local_independence["all_checks_pass"]
        ),
    }


def failed_case(n: int, asymmetric: bool, exc: Exception) -> dict[str, Any]:
    return {
        "n": n,
        "sample_name": "asymmetric_shared_edges_n7_n10" if asymmetric else "all_one_shared_edges",
        "error": f"{type(exc).__name__}: {exc}",
        "all_checks_pass": False,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve()
    parser.add_argument("--output", type=Path, default=here.parent / "locality_inverse_certificate.json")
    args = parser.parse_args(argv)

    cases: list[dict[str, Any]] = []
    for n in range(3, 11):
        try:
            cases.append(sample_case(n, asymmetric=False))
        except Exception as exc:
            cases.append(failed_case(n, False, exc))
        if n >= 7:
            try:
                cases.append(sample_case(n, asymmetric=True))
            except Exception as exc:
                cases.append(failed_case(n, True, exc))

    certificate = {
        "scope": "Finite exact inverse, centre-free target circular recovery, common-support controls for n=3,...,10, and semantic local parameter-independence controls on asymmetric n=7,...,10 samples. Exact finite checks are evidence only and do not prove the uniform theorem.",
        "source_feature_rule": "residue 3: c0_0; residue 2: b0; residue 0/1: spike_0",
        "support_rule": "shared exact endpoints; delete outer boundary edges first, then contract degree-one common port spikes; z remains protected",
        "local_edge_count_assertions": {"n3": 6, "n4": 9, "n5": 13, "n6": 17, "n7": 22},
        "cases": cases,
        "all_inverse_pass": all(case.get("checks", {}).get("inverse", False) for case in cases),
        "all_target_circle_recovery_pass": all(case.get("checks", {}).get("target_circle_recovery", False) for case in cases),
        "all_common_support_pass": all(case.get("checks", {}).get("common_support", False) for case in cases),
        "all_local_parameter_independence_pass": all(
            case.get("checks", {}).get("local_parameter_independence", False)
            for case in cases
            if case.get("sample_name") == "asymmetric_shared_edges_n7_n10"
        ),
        "all_checks_pass": all(case.get("all_checks_pass", False) for case in cases),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(u.exact_json(certificate), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"certificate: {args.output.resolve()}")
    print(f"all_inverse_pass: {certificate['all_inverse_pass']}")
    print(f"all_target_circle_recovery_pass: {certificate['all_target_circle_recovery_pass']}")
    print(f"all_common_support_pass: {certificate['all_common_support_pass']}")
    print(f"all_local_parameter_independence_pass: {certificate['all_local_parameter_independence_pass']}")
    for case in cases:
        print(
            case.get("n"),
            case.get("sample_name"),
            "inverse=" + str(case.get("checks", {}).get("inverse", False)),
            "circle=" + str(case.get("checks", {}).get("target_circle_recovery", False)),
            "locality=" + str(case.get("checks", {}).get("common_support", False)),
            "param_ind=" + str(case.get("checks", {}).get("local_parameter_independence", False)),
            "count=" + str(case.get("common_support", {}).get("remaining_edge_count", "n/a")),
            "error=" + str(case.get("error", "")),
        )
    return 0 if certificate["all_checks_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
