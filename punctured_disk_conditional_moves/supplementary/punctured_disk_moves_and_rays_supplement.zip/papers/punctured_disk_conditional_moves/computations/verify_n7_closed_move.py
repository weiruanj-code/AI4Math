#!/usr/bin/env python3
"""Exact Fraction certificate for the closed n=7 candidate move.

The source and candidate graph tables are reused from the two earlier local
utilities.  This file only adds the closed-form reconstruction supplied by
the root proof: a rank-one minor extracts the spike conductance, and a cyclic
tridiagonal Green completion reconstructs the seven inner conductances.

The output is a finite exact check of the displayed formulas at two positive
source samples and of the Green-completion algebra on one independent cyclic
tridiagonal matrix.  It is not a substitute for the general proof.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence

from explore_n7_endpoint import source_graph, target_graph
from verify_local_controls import graph_response, solve


Q = Fraction


def fs(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


def exact_json(value: Any) -> Any:
    if isinstance(value, Fraction):
        return fs(value)
    if isinstance(value, dict):
        return {str(key): exact_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [exact_json(item) for item in value]
    return value


def zero(rows: int, cols: int) -> list[list[Fraction]]:
    return [[Q(0) for _ in range(cols)] for _ in range(rows)]


def identity(size: int) -> list[list[Fraction]]:
    result = zero(size, size)
    for index in range(size):
        result[index][index] = Q(1)
    return result


def transpose(matrix: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    return [list(column) for column in zip(*matrix)]


def determinant(matrix: Sequence[Sequence[Fraction]]) -> Fraction:
    work = [list(row) for row in matrix]
    size = len(work)
    if size == 0:
        return Q(1)
    result = Q(1)
    for column in range(size):
        pivot = next((row for row in range(column, size) if work[row][column] != 0), None)
        if pivot is None:
            return Q(0)
        if pivot != column:
            work[column], work[pivot] = work[pivot], work[column]
            result = -result
        pivot_value = work[column][column]
        result *= pivot_value
        for row in range(column + 1, size):
            factor = work[row][column] / pivot_value
            if factor:
                for entry in range(column + 1, size):
                    work[row][entry] -= factor * work[column][entry]
    return result


def inverse(matrix: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    return solve(matrix, identity(len(matrix)))


def matrix_add(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    return [[left[row][col] + right[row][col] for col in range(len(left[row]))] for row in range(len(left))]


def matrix_sub(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    return [[left[row][col] - right[row][col] for col in range(len(left[row]))] for row in range(len(left))]


def matrix_scale(matrix: Sequence[Sequence[Fraction]], scalar: Fraction) -> list[list[Fraction]]:
    return [[scalar * value for value in row] for row in matrix]


def matrix_multiply(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    if not left or not right:
        return []
    return [
        [sum(left[row][index] * right[index][col] for index in range(len(right))) for col in range(len(right[0]))]
        for row in range(len(left))
    ]


def equal_matrix(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> bool:
    return len(left) == len(right) and all(
        len(row_left) == len(row_right) and all(a == b for a, b in zip(row_left, row_right))
        for row_left, row_right in zip(left, right)
    )


def max_abs(matrix: Sequence[Sequence[Fraction]]) -> Fraction:
    return max((abs(value) for row in matrix for value in row), default=Q(0))


def reconstruct_green(h_outer: Sequence[Sequence[Fraction]]) -> dict[str, Any]:
    """Complete a cyclic-tridiagonal Green matrix from its non-neighbor entries."""

    size = 7
    p_matrix = zero(size, size)
    for i in range(size):
        for j in range(size):
            distance = (j - i) % size
            if i != j and distance not in (1, size - 1):
                p_matrix[i][j] = -h_outer[i][j]
    cross_products: list[dict[str, Any]] = []
    for i in range(size):
        j1, j2 = (i + 3) % size, (i + 4) % size
        first = [p_matrix[(i - 1) % size][j1], p_matrix[i][j1], p_matrix[(i + 1) % size][j1]]
        second = [p_matrix[(i - 1) % size][j2], p_matrix[i][j2], p_matrix[(i + 1) % size][j2]]
        alpha = first[1] * second[2] - first[2] * second[1]
        beta = first[2] * second[0] - first[0] * second[2]
        gamma = first[0] * second[1] - first[1] * second[0]
        if gamma == 0:
            raise ZeroDivisionError(f"gamma_{i}=0 in Green completion")
        neighbor = -(
            alpha * p_matrix[(i - 1) % size][(i + 2) % size]
            + beta * p_matrix[i][(i + 2) % size]
        ) / gamma
        edge_row, edge_col = (i + 1) % size, (i + 2) % size
        prior_neighbor = p_matrix[edge_col][edge_row]
        p_matrix[edge_row][edge_col] = neighbor
        p_matrix[edge_col][edge_row] = neighbor
        cross_products.append(
            {
                "i": i,
                "j1": j1,
                "j2": j2,
                "alpha": alpha,
                "beta": beta,
                "gamma": gamma,
                "neighbor_reconstruction": neighbor,
                "prior_neighbor_value": prior_neighbor,
            }
        )
    # Every cyclic neighbor has now been reconstructed.  The diagonal
    # identity uses the already-completed neighbor P[i,i+1], so it is a
    # separate pass rather than an in-loop update.
    for cross in cross_products:
        i = cross["i"]
        alpha, beta, gamma = cross["alpha"], cross["beta"], cross["gamma"]
        diagonal = -(
            alpha * p_matrix[(i - 1) % size][(i + 1) % size]
            + beta * p_matrix[i][(i + 1) % size]
        ) / gamma
        diagonal_index = (i + 1) % size
        cross["diagonal_reconstruction"] = diagonal
        cross["prior_diagonal_value"] = p_matrix[diagonal_index][diagonal_index]
        p_matrix[diagonal_index][diagonal_index] = diagonal
    return {"P": p_matrix, "cross_products": cross_products}


def source_weights(**overrides: Fraction) -> dict[str, Fraction]:
    weights = {edge["id"]: Q(1) for edge in source_graph()["edges"]}
    weights.update(overrides)
    return weights


def closed_weights(source_response: Sequence[Sequence[Fraction]], source_weight_map: Mapping[str, Fraction]) -> dict[str, Any]:
    ports = source_graph()["ports"]
    pivot_index = ports.index("p4")
    P_indices = [0, 6, 5]
    Q_indices = [1, 2, 3]
    A = [[source_response[row][col] for col in Q_indices] for row in P_indices]
    u = [[source_response[row][pivot_index]] for row in P_indices]
    v = [[source_response[pivot_index][col] for col in Q_indices]]
    F = determinant(A)
    B = determinant(matrix_add(A, matrix_multiply(u, v))) - F
    if F == 0 or B == 0:
        raise ZeroDivisionError("minor denominators F or B vanish")
    h = source_response[pivot_index][pivot_index] - B / F
    column = [[source_response[row][pivot_index]] for row in range(len(source_response))]
    row = [source_response[pivot_index][col] for col in range(len(source_response))]
    H = matrix_sub(source_response, matrix_scale(matrix_multiply(column, [row]), F / B))
    completion = reconstruct_green([H[row][:7] for row in range(7)])
    P = completion["P"]
    S = inverse(P)
    b_values: list[Fraction] = []
    r_values: list[Fraction] = []
    e_values: list[Fraction] = []
    a_values: list[Fraction] = []
    for i in range(7):
        b_values.append(-H[i][(i + 1) % 7] - P[i][(i + 1) % 7])
    for i in range(7):
        r_values.append(H[i][i] + P[i][i] - b_values[i] - b_values[(i - 1) % 7])
    for i in range(7):
        e_values.append(-S[i][(i + 1) % 7] * r_values[i] * r_values[(i + 1) % 7])
    for i in range(7):
        a_values.append(S[i][i] * r_values[i] * r_values[i] - r_values[i] - e_values[i] - e_values[(i - 1) % 7])
    target_weights: dict[str, Fraction] = {}
    for i in range(7):
        target_weights[f"a{i}"] = a_values[i]
        target_weights[f"e{i}"] = e_values[i]
        target_weights[f"r{i}"] = r_values[i]
    for i in range(1, 7):
        target_weights[f"b{i}"] = b_values[i]
    target_weights["s4"] = h
    return {
        "F": F,
        "B": B,
        "h": h,
        "H": H,
        "P": P,
        "S": S,
        "cross_products": completion["cross_products"],
        "a": a_values,
        "e": e_values,
        "r": r_values,
        "b": b_values,
        "target_weights": target_weights,
        "source_weights": dict(source_weight_map),
        "green_determinant": determinant(P),
        "detGreen": determinant(P),
        "gamma_values": [cross["gamma"] for cross in completion["cross_products"]],
        "green_offband_max": max_abs(
            [[S[i][j] if (i - j) % 7 not in (0, 1, 6) else Q(0) for j in range(7)] for i in range(7)]
        ),
    }


def target_response(target_weight_map: Mapping[str, Fraction]) -> list[list[Fraction]]:
    return graph_response(target_graph(), target_weight_map)


def closed_sample(name: str, weights: Mapping[str, Fraction], expected: Mapping[str, Any] | None = None) -> dict[str, Any]:
    source_response = graph_response(source_graph(), weights)
    result = closed_weights(source_response, weights)
    recovered_target_response = target_response(result["target_weights"])
    residual = matrix_sub(recovered_target_response, source_response)
    positive = all(value > 0 for edge_id, value in result["target_weights"].items() if edge_id != "b0")
    checks: dict[str, Any] = {
        "response_equal_full_8x8": equal_matrix(recovered_target_response, source_response),
        "residual_max_abs": max_abs(residual),
        "residual_zero": max_abs(residual) == 0,
        "b0_recovered_zero": result["b"][0] == 0,
        "green_offband_zero": result["green_offband_max"] == 0,
        "all_target_weights_positive": positive,
        "F_nonzero": result["F"] != 0,
        "B_nonzero": result["B"] != 0,
        "green_determinant_nonzero": result["green_determinant"] != 0,
    }
    if expected:
        checks["matches_expected_arrays"] = (
            result["h"] == expected["h"]
            and result["a"] == expected["a"]
            and result["e"] == expected["e"]
            and result["r"] == expected["r"]
            and result["b"] == expected["b"]
        )
    result.update({"name": name, "checks": checks, "response_residual": residual, "target_response": recovered_target_response})
    return result


def generic_green_check() -> dict[str, Any]:
    size = 7
    S = zero(size, size)
    for i in range(size):
        S[i][i] = Q(5 + i)
        edge = Q(1) + Q(i, 10)
        j = (i + 1) % size
        S[i][j] -= edge
        S[j][i] -= edge
    P = inverse(S)
    H_outer = matrix_scale(P, Q(-1))
    completion = reconstruct_green(H_outer)
    P_recovered = completion["P"]
    S_recovered = inverse(P_recovered)
    return {
        "S": S,
        "P_inverse": P,
        "P_recovered": P_recovered,
        "S_recovered": S_recovered,
        "cross_products": completion["cross_products"],
        "green_completion_exact": equal_matrix(P, P_recovered),
        "left_inverse_exact": equal_matrix(matrix_multiply(P_recovered, S), identity(size)),
        "S_recovery_exact": equal_matrix(S, S_recovered),
        "offband_S_recovered_zero": all(
            S_recovered[i][j] == 0
            for i in range(size)
            for j in range(size)
            if (i - j) % size not in (0, 1, size - 1)
        ),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve()
    parser.add_argument("--output", type=Path, default=here.parent / "n7_closed_move_certificate.json")
    args = parser.parse_args(argv)

    expected = {
        "h": Q(83),
        "a": [Q(3, 8), Q(3, 8), Q(1), Q(27, 8), Q(3), Q(27, 8), Q(1)],
        "e": [Q(9, 4), Q(3, 8), Q(27, 8), Q(81, 38), Q(81, 38), Q(27, 8), Q(3, 8)],
        "r": [Q(6), Q(6), Q(1), Q(27, 38), Q(249, 361), Q(27, 38), Q(1)],
        "b": [Q(0), Q(1), Q(1), Q(83, 76), Q(83, 76), Q(1), Q(1)],
    }
    sample_one = source_weights(a2=Q(2), a6=Q(2))
    sample_two = source_weights(a2=Q(2), a6=Q(2), b2=Q(101, 100), e4=Q(99, 100), r3=Q(100, 99), a5=Q(100, 101))
    certificate = {
        "scope": "Exact Fraction checks for the closed n=7 candidate formula; finite samples and an independent Green-completion test are evidence for the algebra, not a replacement for the general proof.",
        "endpoint_interpretation": "The target deletes b0, promotes old p4 to internal v4, and adds the spike s4:p4-v4. No planarity or independent Conjecture 4 claim is inferred here.",
        "source_graph": source_graph(),
        "target_graph": target_graph(),
        "source_edge_count": len(source_graph()["edges"]),
        "target_edge_count": len(target_graph()["edges"]),
        "samples": [
            closed_sample("a2_a6_equal_2", sample_one, expected),
            closed_sample("asymmetric_rational", sample_two),
        ],
        "generic_green_check": generic_green_check(),
    }
    certificate["all_requested_checks_pass"] = (
        certificate["source_edge_count"] == 28
        and certificate["target_edge_count"] == 28
        and all(all(item for key, item in sample["checks"].items() if key != "residual_max_abs") for sample in certificate["samples"])
        and all(certificate["generic_green_check"][key] for key in ("green_completion_exact", "left_inverse_exact", "S_recovery_exact", "offband_S_recovered_zero"))
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(exact_json(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"certificate: {args.output.resolve()}")
    print(f"all_requested_checks_pass: {certificate['all_requested_checks_pass']}")
    for sample in certificate["samples"]:
        print(sample["name"], sample["checks"])
    print("generic_green_check", {key: certificate["generic_green_check"][key] for key in ("green_completion_exact", "left_inverse_exact", "S_recovery_exact", "offband_S_recovered_zero")})
    return 0 if certificate["all_requested_checks_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
