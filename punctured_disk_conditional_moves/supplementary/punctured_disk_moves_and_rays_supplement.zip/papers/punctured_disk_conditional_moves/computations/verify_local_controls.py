#!/usr/bin/env python3
"""Exact local-response checks for the conditional-move control formulas.

This file is intentionally independent of symbolic algebra packages.  It
uses only :class:`fractions.Fraction` and computes every response matrix by
forming a graph Laplacian and taking the Schur complement of the internal
vertices.  The input graph descriptions are the root-authored, manually
checked descriptions in ``notes/local_graphs.json``.

The output is an auditable certificate.  Fractions are stored as strings of
the form ``numerator/denominator`` so no floating point value is involved.
The calculation is a local algebra check; it does not assert a theorem about
the source paper's diagram interpretation.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


Q = Fraction


def q(value: int | str | Fraction) -> Fraction:
    return value if isinstance(value, Fraction) else Fraction(value)


def fs(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


def json_exact(value: Any) -> Any:
    if isinstance(value, Fraction):
        return fs(value)
    if isinstance(value, dict):
        return {str(key): json_exact(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_exact(item) for item in value]
    return value


def zero_matrix(rows: int, cols: int) -> list[list[Fraction]]:
    return [[Q(0) for _ in range(cols)] for _ in range(rows)]


def submatrix(matrix: Sequence[Sequence[Fraction]], rows: Sequence[int], cols: Sequence[int]) -> list[list[Fraction]]:
    return [[matrix[row][col] for col in cols] for row in rows]


def matrix_sub(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    return [[left[i][j] - right[i][j] for j in range(len(left[0]))] for i in range(len(left))]


def matrix_add(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    return [[left[i][j] + right[i][j] for j in range(len(left[0]))] for i in range(len(left))]


def matrix_multiply(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    if not left or not right:
        return zero_matrix(len(left), len(right[0]) if right else 0)
    return [
        [sum(left[i][k] * right[k][j] for k in range(len(right))) for j in range(len(right[0]))]
        for i in range(len(left))
    ]


def solve(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    """Solve ``left * X = right`` by exact Gauss--Jordan elimination."""

    n = len(left)
    if n == 0:
        return []
    width = len(right[0]) if right else 0
    augmented = [list(left[row]) + list(right[row]) for row in range(n)]
    pivot_row = 0
    for column in range(n):
        pivot = next((row for row in range(pivot_row, n) if augmented[row][column] != 0), None)
        if pivot is None:
            raise ValueError("singular internal Laplacian")
        augmented[pivot_row], augmented[pivot] = augmented[pivot], augmented[pivot_row]
        divisor = augmented[pivot_row][column]
        augmented[pivot_row] = [entry / divisor for entry in augmented[pivot_row]]
        for row in range(n):
            if row == pivot_row:
                continue
            factor = augmented[row][column]
            if factor:
                augmented[row] = [
                    augmented[row][col] - factor * augmented[pivot_row][col]
                    for col in range(n + width)
                ]
        pivot_row += 1
    return [row[n:] for row in augmented]


def graph_nodes(graph: Mapping[str, Any]) -> list[str]:
    result: list[str] = []
    for node in list(graph["ports"]) + list(graph.get("internal", [])):
        if node not in result:
            result.append(node)
    for edge in graph["edges"]:
        for node in (edge["u"], edge["v"]):
            if node not in result:
                result.append(node)
    return result


def graph_response(graph: Mapping[str, Any], weights: Mapping[str, Fraction]) -> list[list[Fraction]]:
    """Return the protected-port response matrix of a weighted graph."""

    nodes = graph_nodes(graph)
    positions = {node: index for index, node in enumerate(nodes)}
    laplacian = zero_matrix(len(nodes), len(nodes))
    for edge in graph["edges"]:
        conductance = q(weights[edge["id"]])
        u, v = positions[edge["u"]], positions[edge["v"]]
        laplacian[u][u] += conductance
        laplacian[v][v] += conductance
        laplacian[u][v] -= conductance
        laplacian[v][u] -= conductance
    ports = [positions[node] for node in graph["ports"]]
    internals = [positions[node] for node in graph.get("internal", [])]
    l_pp = submatrix(laplacian, ports, ports)
    if not internals:
        return l_pp
    l_pi = submatrix(laplacian, ports, internals)
    l_ip = submatrix(laplacian, internals, ports)
    l_ii = submatrix(laplacian, internals, internals)
    return matrix_sub(l_pp, matrix_multiply(l_pi, solve(l_ii, l_ip)))


def edge_graph(ports: Sequence[str], internal: Sequence[str], edges: Sequence[tuple[str, str, str]]) -> dict[str, Any]:
    return {
        "ports": list(ports),
        "central_port": "z" if "z" in ports else None,
        "internal": list(internal),
        "edges": [{"id": edge_id, "u": u, "v": v} for edge_id, u, v in edges],
    }


def edge_laplacian(ports: Sequence[str], edge_id: str, u: str, v: str, conductance: Fraction) -> list[list[Fraction]]:
    matrix = zero_matrix(len(ports), len(ports))
    index = {node: row for row, node in enumerate(ports)}
    i, j = index[u], index[v]
    matrix[i][i] += conductance
    matrix[j][j] += conductance
    matrix[i][j] -= conductance
    matrix[j][i] -= conductance
    return matrix


def add_triangle_to_port_response(
    response: Sequence[Sequence[Fraction]],
    ports: Sequence[str],
    delta: Fraction,
    r: str,
    t: str,
    z: str,
    eta: Fraction,
    zeta: Fraction,
) -> list[list[Fraction]]:
    result = [list(row) for row in response]
    index = {node: row for row, node in enumerate(ports)}
    for u, v, conductance in ((r, t, delta), (r, z, delta * eta), (t, z, delta * zeta)):
        i, j = index[u], index[v]
        result[i][i] += conductance
        result[j][j] += conductance
        result[i][j] -= conductance
        result[j][i] -= conductance
    return result


def equal_matrix(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> bool:
    return len(left) == len(right) and all(
        len(left_row) == len(right_row) and all(a == b for a, b in zip(left_row, right_row))
        for left_row, right_row in zip(left, right)
    )


def positive_weights(weights: Mapping[str, Fraction]) -> bool:
    return all(value > 0 for value in weights.values())


def generic_transform(weights: Mapping[str, Fraction], x: Fraction) -> dict[str, Any]:
    """Apply the seven-edge cell formula exactly as stated by the root agent."""

    a, b, f, j, g, k, l = (q(weights[key]) for key in "abfjgkl")
    u_total = a + j + k + f
    v_total = b + g + l + f
    denominator = u_total * v_total - f * f
    rho = k * l * f / denominator
    w = g * j * f / denominator
    theta = rho - x
    if theta == 0:
        raise ZeroDivisionError("generic cell requires x != rho")
    K = k - x * (1 + k * v_total / (l * f))
    L = l - x * (1 + l * u_total / (k * f))
    J = K * l * j * f / (denominator * theta)
    G = L * k * g * f / (denominator * theta)
    A = a * J / j
    B = b * G / g
    F = K * L * f * f / (denominator * theta)
    delta = w * x / theta
    eta = (a * f + b * u_total) / (j * f)
    zeta = (a * v_total + b * f) / (g * f)
    new_weights = {"a": A, "b": B, "f": F, "j": J, "g": G, "k": K, "l": L}
    return {
        "U": u_total,
        "V": v_total,
        "D": denominator,
        "rho": rho,
        "w": w,
        "theta": theta,
        "x": x,
        "new_weights": new_weights,
        "delta": delta,
        "eta": eta,
        "zeta": zeta,
    }


def generic_identity_case(weights: Mapping[str, Fraction], x: Fraction) -> dict[str, Any]:
    data = generic_transform(weights, x)
    ports = ["p", "q", "r", "t", "z"]
    old = edge_graph(
        ports,
        ["u", "v"],
        [("a", "z", "u"), ("b", "z", "v"), ("f", "u", "v"), ("j", "u", "t"), ("g", "v", "r"), ("k", "p", "u"), ("l", "q", "v")],
    )
    transformed = edge_graph(
        ports,
        ["u", "v"],
        [("a", "z", "u"), ("b", "z", "v"), ("f", "u", "v"), ("j", "u", "t"), ("g", "v", "r"), ("k", "p", "u"), ("l", "q", "v"), ("x", "p", "q")],
    )
    old_response = graph_response(old, weights)
    transformed_weights = dict(data["new_weights"])
    transformed_weights["x"] = x
    transformed_response = graph_response(transformed, transformed_weights)
    triangle_response = add_triangle_to_port_response(
        zero_matrix(len(ports), len(ports)), ports, data["delta"], "r", "t", "z", data["eta"], data["zeta"]
    )
    expected = matrix_add(old_response, triangle_response)
    return {
        "input_weights": dict(weights),
        "formula": data,
        "positive_new_seven_weights": positive_weights(data["new_weights"]),
        "response_identity": equal_matrix(transformed_response, expected),
        "old_response": old_response,
        "transformed_response": transformed_response,
        "expected_old_plus_triangle": expected,
    }


def generic_reversibility_case(weights: Mapping[str, Fraction], x: Fraction) -> dict[str, Any]:
    first = generic_transform(weights, x)
    transformed_zero = generic_transform(first["new_weights"], Q(0))
    reverse = generic_transform(first["new_weights"], -x)
    return {
        "input_weights": dict(weights),
        "x": x,
        "inverse_parameter": -x,
        "external_edge_sum": x + (-x),
        "rho": first["rho"],
        "rho_new": transformed_zero["rho"],
        "rho_minus_x": first["rho"] - x,
        "rho_new_identity": transformed_zero["rho"] == first["rho"] - x,
        "eta_invariant": transformed_zero["eta"] == first["eta"],
        "zeta_invariant": transformed_zero["zeta"] == first["zeta"],
        "round_trip_weights": reverse["new_weights"],
        "round_trip_identity": reverse["new_weights"] == dict(weights),
    }


def two_layer_n7_first_sweep() -> dict[str, Any]:
    """Check the specified auxiliary first sweep on the two-layer Xi_7 graph."""

    ports = [f"p{i}" for i in range(7)] + ["z"]
    internals = [f"u{i}" for i in range(7)]
    edges: list[tuple[str, str, str]] = []
    for i in range(7):
        edges.append((f"a{i}", "z", f"u{i}"))
    for i in range(7):
        edges.append((f"e{i}", f"u{i}", f"u{(i + 1) % 7}"))
    for i in range(7):
        edges.append((f"r{i}", f"u{i}", f"p{i}"))
    for i in range(7):
        edges.append((f"b{i}", f"p{i}", f"p{(i + 1) % 7}"))
    source_graph = edge_graph(ports, internals, edges)
    source_weights = {edge_id: Q(1) for edge_id, _, _ in edges}

    cell_input = {"a": Q(1), "b": Q(1), "f": Q(1), "j": Q(1), "g": Q(1), "k": Q(1), "l": Q(1)}
    cell = generic_transform(cell_input, Q(-1))
    epsilon = -cell["delta"]

    # The cell is (u,v,P,Q,R,T,Z)=(u1,u0,p1,p0,u6,u2,z).
    replacement_map = {"a1": "a", "a0": "b", "e0": "f", "e1": "j", "e6": "g", "r1": "k", "r0": "l"}
    target_edges = [edge for edge in edges if edge[0] != "b0"]
    target_edges.append(("aux_u6_u2", "u6", "u2"))
    target_graph = edge_graph(ports, internals, target_edges)
    target_weights = dict(source_weights)
    target_weights.pop("b0")
    for source_edge, generic_edge in replacement_map.items():
        target_weights[source_edge] = cell["new_weights"][generic_edge]
    target_weights["aux_u6_u2"] = epsilon
    target_weights["a6"] += epsilon * cell["eta"]
    target_weights["a2"] += epsilon * cell["zeta"]

    source_response = graph_response(source_graph, source_weights)
    target_response = graph_response(target_graph, target_weights)
    expected_replacements = {
        "a1": cell["new_weights"]["a"],
        "a0": cell["new_weights"]["b"],
        "e0": cell["new_weights"]["f"],
        "e1": cell["new_weights"]["j"],
        "e6": cell["new_weights"]["g"],
        "r1": cell["new_weights"]["k"],
        "r0": cell["new_weights"]["l"],
    }
    return {
        "scope": "Auxiliary Xi_7 two-layer first sweep only; not the prescribed Conjecture 4 endpoint. No planarity or completed local-move claim is made.",
        "protected_ports": ports,
        "central_port": "z",
        "internal_vertices": internals,
        "cell_identification": {"u": "u1", "v": "u0", "P": "p1", "Q": "p0", "R": "u6", "T": "u2", "Z": "z"},
        "cell_input_identification": {"a": "a1", "b": "a0", "f": "e0", "j": "e1", "g": "e6", "k": "r1", "l": "r0"},
        "cell_parameter_x": Q(-1),
        "cell_formula": cell,
        "expected_seven_replacements": expected_replacements,
        "expected_replacement_values": {"K=L": cell["new_weights"]["k"], "A=B=J=G": cell["new_weights"]["a"], "F": cell["new_weights"]["f"]},
        "deleted_source_edge": "b0",
        "auxiliary_chord": {"edge": "u6-u2", "epsilon": epsilon, "epsilon_eta": epsilon * cell["eta"], "epsilon_zeta": epsilon * cell["zeta"]},
        "source_edge_count": len(source_graph["edges"]),
        "target_edge_count": len(target_graph["edges"]),
        "final_weights_positive": positive_weights(target_weights),
        "response_equal_full_8x8_including_z": equal_matrix(source_response, target_response),
        "source_response": source_response,
        "target_response": target_response,
        "target_weights": target_weights,
    }


def n3_formula(values: Mapping[str, Fraction]) -> dict[str, Fraction]:
    a, b, c, d, e, f = (q(values[key]) for key in "abcdef")
    W = b * f + d * e + d * f + e * f
    return {"A": a - b * f / e, "C": c - b * f / d, "B": b * W / (d * e), "D": W / e, "E": W / d, "F": W / f}


def n4_formula(values: Mapping[str, Fraction]) -> dict[str, Fraction]:
    a, b, c, d, e, f, g, h, i = (q(values[key]) for key in "abcdefghi")
    H0 = b + e + f + i
    I = d + g + h + g * h * H0 / (e * f)
    S0 = I - d - g - h
    return {
        "A": a + b * e / H0 - d * h / S0,
        "C": c + b * f / H0 - d * g / S0,
        "B": b * i / H0,
        "E": e * i / H0,
        "F": f * i / H0,
        "D": d * I / S0,
        "G": g * I / S0,
        "H": h * I / S0,
        "I": I,
    }


def n5_formula(values: Mapping[str, Fraction]) -> dict[str, Fraction]:
    cell_values = {key: q(values[key]) for key in "abfgjkl"}
    top = {key: q(values[key]) for key in "dhim"}
    c, e = q(values["c"]), q(values["e"])
    cell = generic_transform(cell_values, Q(0))  # replaced below after top conductance is known
    Htop = top["d"] + top["h"] + top["i"] + top["m"]
    wtop = top["h"] * top["i"] / Htop
    x = cell["rho"] * wtop / (cell["w"] + wtop)
    cell = generic_transform(cell_values, x)
    return {
        "A": cell["new_weights"]["a"],
        "B": cell["new_weights"]["b"],
        "F": cell["new_weights"]["f"],
        "J": cell["new_weights"]["j"],
        "G": cell["new_weights"]["g"],
        "K": cell["new_weights"]["k"],
        "L": cell["new_weights"]["l"],
        "D": top["d"] * top["m"] / Htop,
        "H": top["h"] * top["m"] / Htop,
        "I": top["i"] * top["m"] / Htop,
        "C": c + top["d"] * top["h"] / Htop - cell["delta"] * cell["eta"],
        "E": e + top["d"] * top["i"] / Htop - cell["delta"] * cell["zeta"],
        "M": x,
    }


def n6_formula(values: Mapping[str, Fraction]) -> tuple[dict[str, Fraction], dict[str, Any]]:
    lower_values = {"a": values["a"], "b": values["b"], "f": values["g"], "j": values["l"], "g": values["h"], "k": values["m"], "l": values["n"]}
    lower = generic_transform(lower_values, -q(values["q"]))
    delta_b = lower["delta"]
    upper_values = {"a": values["e"], "b": values["d"], "f": values["j"], "j": values["k"], "g": values["i"], "k": values["p"], "l": values["o"]}
    upper_zero = generic_transform(upper_values, Q(0))
    delta_t = -delta_b
    x_t = upper_zero["rho"] * delta_t / (upper_zero["w"] + delta_t)
    upper = generic_transform(upper_values, x_t)
    output = {
        "A": lower["new_weights"]["a"],
        "B": lower["new_weights"]["b"],
        "G": lower["new_weights"]["f"],
        "H": lower["new_weights"]["g"],
        "L": lower["new_weights"]["j"],
        "M": lower["new_weights"]["k"],
        "N": lower["new_weights"]["l"],
        "E": upper["new_weights"]["a"],
        "D": upper["new_weights"]["b"],
        "J": upper["new_weights"]["f"],
        "I": upper["new_weights"]["g"],
        "K": upper["new_weights"]["j"],
        "P": upper["new_weights"]["k"],
        "O": upper["new_weights"]["l"],
        "Q": x_t,
        "C": q(values["c"]) - delta_b * lower["eta"] - delta_t * upper["eta"],
        "F": q(values["f"]) - delta_b * lower["zeta"] - delta_t * upper["zeta"],
    }
    return output, {"lower": lower, "upper": upper, "delta_b": delta_b, "delta_t": delta_t, "x_t": x_t}


def graph_from_local(local: Mapping[str, Any], n: int, side: str) -> Mapping[str, Any]:
    specification = local["graphs"][str(n)]
    graph = dict(specification[side])
    graph["ports"] = list(specification["ports"])
    graph["central_port"] = specification.get("central_port")
    return graph


def check_formula(
    local: Mapping[str, Any],
    n: int,
    values: Mapping[str, Fraction],
    formula: Mapping[str, Fraction],
    extra: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    input_graph = graph_from_local(local, n, "input")
    output_graph = graph_from_local(local, n, "output")
    input_response = graph_response(input_graph, values)
    output_response = graph_response(output_graph, formula)
    return {
        "input_weights": dict(values),
        "output_weights": dict(formula),
        "all_output_weights_positive": positive_weights(formula),
        "response_equal": equal_matrix(input_response, output_response),
        "input_response": input_response,
        "output_response": output_response,
        "formula_auxiliary": dict(extra or {}),
    }


def n3_samples() -> list[dict[str, int]]:
    return [
        {"a": 5, "b": 1, "c": 5, "d": 2, "e": 3, "f": 4},
        {"a": 9, "b": 2, "c": 8, "d": 3, "e": 5, "f": 7},
    ]


def n4_samples() -> list[dict[str, int]]:
    return [
        {"a": 12, "b": 2, "c": 14, "d": 3, "e": 4, "f": 5, "g": 6, "h": 2, "i": 7},
        {"a": 20, "b": 3, "c": 18, "d": 5, "e": 7, "f": 4, "g": 8, "h": 3, "i": 6},
    ]


def n5_samples() -> list[dict[str, int]]:
    return [
        {"a": 5, "b": 2, "c": 100, "d": 4, "e": 100, "f": 3, "g": 6, "h": 3, "i": 5, "j": 4, "k": 7, "l": 5, "m": 7},
        {"a": 9, "b": 3, "c": 100, "d": 6, "e": 100, "f": 4, "g": 9, "h": 4, "i": 7, "j": 5, "k": 6, "l": 8, "m": 5},
    ]


def n6_samples() -> list[dict[str, int]]:
    return [
        {"a": 8, "b": 7, "c": 100, "d": 5, "e": 6, "f": 100, "g": 3, "h": 5, "i": 7, "j": 4, "k": 6, "l": 8, "m": 9, "n": 7, "o": 5, "p": 4, "q": 1},
        {"a": 11, "b": 9, "c": 100, "d": 7, "e": 8, "f": 100, "g": 4, "h": 6, "i": 9, "j": 5, "k": 7, "l": 10, "m": 8, "n": 6, "o": 9, "p": 5, "q": 2},
    ]


def generic_samples() -> list[tuple[dict[str, int], str]]:
    return [
        ({"a": 5, "b": 3, "f": 4, "j": 6, "g": 7, "k": 8, "l": 9}, "rho/3"),
        ({"a": 11, "b": 4, "f": 5, "j": 7, "g": 9, "k": 6, "l": 8}, "-1"),
    ]


def verify(local: Mapping[str, Any]) -> dict[str, Any]:
    appendix_diagnostic = appendix_n5_response_diagnostic(local)
    appendix_diagnostic["diagnostic_pass"] = (
        appendix_diagnostic["sample_has_f_neq_g"]
        and appendix_diagnostic["sample_evaluations"]["L_differs"]
        and appendix_diagnostic["sample_evaluations"]["M_differs"]
        and bool(appendix_diagnostic["nonzero_residual_entries"])
        and bool(appendix_diagnostic["centre_nonzero_residual_entries"])
        and appendix_diagnostic["source_derived_response_equals_input_response"]
        and not appendix_diagnostic["printed_response_equals_input_response"]
    )
    certificate: dict[str, Any] = {
        "method": "Fraction Laplacian with exact Schur complement; no symbolic package",
        "input": "notes/local_graphs.json",
        "interpretation_scope": "Calculates the supplied graph descriptions only; does not certify port interpretation of source SVGs.",
        "generic_seven_edge_cell": [],
        "generic_reversibility": [],
        "two_layer_n7_first_sweep": None,
        "n3": [],
        "n4": [],
        "n5": [],
        "n6": [],
        "appendix_n5_printed_comparison": appendix_diagnostic,
    }
    for raw_values, x_spec in generic_samples():
        values = {key: q(value) for key, value in raw_values.items()}
        base = generic_transform(values, Q(0))
        x = base["rho"] / 3 if x_spec == "rho/3" else Q(-1)
        certificate["generic_seven_edge_cell"].append(generic_identity_case(values, x))
        certificate["generic_reversibility"].append(generic_reversibility_case(values, x))

    formula_functions = {3: n3_formula, 4: n4_formula, 5: n5_formula}
    for n, samples in ((3, n3_samples()), (4, n4_samples()), (5, n5_samples())):
        for raw_values in samples:
            values = {key: q(value) for key, value in raw_values.items()}
            formula = formula_functions[n](values)
            certificate[f"n{n}"].append(check_formula(local, n, values, formula))
    for raw_values in n6_samples():
        values = {key: q(value) for key, value in raw_values.items()}
        formula, extra = n6_formula(values)
        certificate["n6"].append(check_formula(local, 6, values, formula, extra))
    certificate["two_layer_n7_first_sweep"] = two_layer_n7_first_sweep()

    all_checks = []
    all_checks.append(certificate["appendix_n5_printed_comparison"]["diagnostic_pass"])
    all_checks.extend(item["response_identity"] and item["positive_new_seven_weights"] for item in certificate["generic_seven_edge_cell"])
    all_checks.extend(
        item["external_edge_sum"] == Q(0)
        and item["rho_new_identity"]
        and item["eta_invariant"]
        and item["zeta_invariant"]
        and item["round_trip_identity"]
        for item in certificate["generic_reversibility"]
    )
    all_checks.append(
        certificate["two_layer_n7_first_sweep"]["source_edge_count"] == 28
        and certificate["two_layer_n7_first_sweep"]["target_edge_count"] == 28
        and certificate["two_layer_n7_first_sweep"]["final_weights_positive"]
        and certificate["two_layer_n7_first_sweep"]["response_equal_full_8x8_including_z"]
    )
    for n in (3, 4, 5, 6):
        all_checks.extend(item["response_equal"] and item["all_output_weights_positive"] for item in certificate[f"n{n}"])
    certificate["all_requested_checks_pass"] = all(all_checks)
    return certificate


def appendix_n5_comparison() -> dict[str, Any]:
    """Record the two source-derived versus printed n=5 formulas.

    The expressions are kept as coefficient polynomials.  This comparison is
    diagnostic only; it does not label a source discrepancy as an erratum.
    """

    # The common source notation is retained as strings so this diagnostic
    # cannot silently acquire a floating-point or variable-name convention.
    sample = {key: q(value) for key, value in n5_samples()[0].items()}
    a, b, c, d, e, f, g, h, i, j, k, l, m = (sample[key] for key in "abcdefghijklm")
    Htop = d + h + i + m
    delta_poly = a * b * h * i + a * f * h * i + a * g * h * i + b * f * h * i + b * h * i * j + f * g * h * i + f * h * i * j + g * h * i * j
    gamma = f * g * j * Htop
    W = gamma + delta_poly + a * h * i * l + b * h * i * k + f * h * i * k + f * h * i * l + g * h * i * k + h * i * j * l + h * i * k * l
    L_print = l * (delta_poly + b * h * i * k + g * h * i * k) / W
    L_source = l * (gamma + delta_poly + b * h * i * k + g * h * i * k) / W
    M_print = g * h * i * k * l / W
    M_source = f * h * i * k * l / W
    return {
        "status": "formula-level comparison recorded; no PDF erratum asserted",
        "asymmetric_positive_sample": sample,
        "sample_has_f_neq_g": f != g,
        "sample_evaluations": {
            "gamma": gamma,
            "delta_poly": delta_poly,
            "W": W,
            "L_print": L_print,
            "L_source_derived": L_source,
            "M_print": M_print,
            "M_source_derived": M_source,
            "L_differs": L_print != L_source,
            "M_differs": M_print != M_source,
        },
        "printed_vs_source_derived": {
            "L": {"differs_symbolically": True, "reason": "the source-derived numerator contains the additional gamma term"},
            "M": {"differs_symbolically": True, "reason": "the source-derived numerator uses f in place of the printed g"},
        },
        "printed_L_numerator": "l*(delta_poly + b*h*i*k + g*h*i*k)",
        "source_derived_L_numerator": "l*(gamma + delta_poly + b*h*i*k + g*h*i*k)",
        "gamma": "f*g*j*(d+h+i+m)",
        "printed_M_numerator": "g*h*i*k*l",
        "source_derived_M_numerator": "f*h*i*k*l",
        "W": "f*g*j*(d+h+i+m)+delta_poly+a*h*i*l+b*h*i*k+f*h*i*k+f*h*i*l+g*h*i*k+h*i*j*l+h*i*k*l",
    }


def appendix_n5_response_diagnostic(local: Mapping[str, Any]) -> dict[str, Any]:
    diagnostic = appendix_n5_comparison()
    sample = diagnostic["asymmetric_positive_sample"]
    values = {key: q(value) for key, value in sample.items()}
    correct = n5_formula(values)
    evaluations = diagnostic["sample_evaluations"]
    printed = dict(correct)
    printed["L"] = evaluations["L_print"]
    printed["M"] = evaluations["M_print"]
    output_graph = graph_from_local(local, 5, "output")
    correct_response = graph_response(output_graph, correct)
    printed_response = graph_response(output_graph, printed)
    residual = matrix_sub(printed_response, correct_response)
    ports = list(local["graphs"]["5"]["ports"])
    nonzero = [
        {"row": ports[row], "column": ports[column], "value": value}
        for row, row_values in enumerate(residual)
        for column, value in enumerate(row_values)
        if value
    ]
    centre_index = ports.index(local["graphs"]["5"]["central_port"])
    diagnostic.update(
        {
            "source_derived_output_weights": correct,
            "printed_LM_output_weights": printed,
            "response_residual_printed_minus_source_derived": residual,
            "nonzero_residual_entries": nonzero,
            "centre_port": local["graphs"]["5"]["central_port"],
            "centre_residual_row": residual[centre_index],
            "centre_nonzero_residual_entries": [
                entry for entry in nonzero if entry["row"] == local["graphs"]["5"]["central_port"] or entry["column"] == local["graphs"]["5"]["central_port"]
            ],
            "source_derived_response_equals_input_response": equal_matrix(correct_response, graph_response(graph_from_local(local, 5, "input"), values)),
            "printed_response_equals_source_derived_response": equal_matrix(printed_response, correct_response),
            "printed_response_equals_input_response": equal_matrix(printed_response, graph_response(graph_from_local(local, 5, "input"), values)),
        }
    )
    return diagnostic


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve()
    default_root = here.parents[1]
    parser.add_argument("--input", type=Path, default=default_root / "notes" / "local_graphs.json")
    parser.add_argument("--output", type=Path, default=here.parent / "local_control_certificate.json")
    args = parser.parse_args(argv)
    local = json.loads(args.input.read_text(encoding="utf-8"))
    certificate = verify(local)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(json_exact(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"certificate: {args.output.resolve()}")
    print(f"all_requested_checks_pass: {certificate['all_requested_checks_pass']}")
    for key in ("generic_seven_edge_cell", "n3", "n4", "n5", "n6"):
        entries = certificate[key]
        if key == "generic_seven_edge_cell":
            state = [entry["response_identity"] and entry["positive_new_seven_weights"] for entry in entries]
        else:
            state = [entry["response_equal"] and entry["all_output_weights_positive"] for entry in entries]
        print(f"{key}: {state}")
    print(f"generic_reversibility: {[entry['round_trip_identity'] and entry['rho_new_identity'] and entry['eta_invariant'] and entry['zeta_invariant'] for entry in certificate['generic_reversibility']]}")
    sweep = certificate["two_layer_n7_first_sweep"]
    print(f"two_layer_n7_first_sweep: {sweep['response_equal_full_8x8_including_z'] and sweep['final_weights_positive']} (edges {sweep['source_edge_count']} -> {sweep['target_edge_count']})")
    return 0 if certificate["all_requested_checks_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
