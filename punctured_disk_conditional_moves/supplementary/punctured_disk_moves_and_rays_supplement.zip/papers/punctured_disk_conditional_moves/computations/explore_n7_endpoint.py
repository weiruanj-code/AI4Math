#!/usr/bin/env python3
"""Numerically explore the proposed two-layer n=7 endpoint.

This is a deliberately finite numerical experiment.  It constructs the
source Xi_7 graph and the candidate graph obtained by deleting ``b0``,
splitting the old ``p4`` into an internal vertex ``v4`` plus a new edge
``s4``, and solves for positive target conductances with a damped Newton
iteration in logarithmic coordinates.  It does not assert that the candidate
is the endpoint of Conjecture 4 and does not certify an exact identity.

Only Python's standard library is used.  The response is computed from the
Laplacian Schur complement; the analytic Jacobian uses harmonic edge drops.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence


EPS = 1.0e-12
LOG_MIN = -30.0
LOG_MAX = 30.0
MAX_ITER = 80


def source_graph() -> dict[str, Any]:
    ports = [f"p{i}" for i in range(7)] + ["z"]
    internal = [f"u{i}" for i in range(7)]
    edges: list[dict[str, str]] = []
    for i in range(7):
        edges.append({"id": f"a{i}", "u": "z", "v": f"u{i}"})
    for i in range(7):
        edges.append({"id": f"e{i}", "u": f"u{i}", "v": f"u{(i + 1) % 7}"})
    for i in range(7):
        edges.append({"id": f"r{i}", "u": f"u{i}", "v": f"p{i}"})
    for i in range(7):
        edges.append({"id": f"b{i}", "u": f"p{i}", "v": f"p{(i + 1) % 7}"})
    return {"ports": ports, "internal": internal, "edges": edges}


def target_graph() -> dict[str, Any]:
    source = source_graph()
    edges: list[dict[str, str]] = []
    for edge in source["edges"]:
        if edge["id"] == "b0":
            continue
        copied = dict(edge)
        copied["u"] = "v4" if copied["u"] == "p4" else copied["u"]
        copied["v"] = "v4" if copied["v"] == "p4" else copied["v"]
        edges.append(copied)
    edges.append({"id": "s4", "u": "p4", "v": "v4"})
    return {"ports": list(source["ports"]), "internal": list(source["internal"]) + ["v4"], "edges": edges}


def graph_nodes(graph: Mapping[str, Any]) -> list[str]:
    result: list[str] = []
    for node in list(graph["ports"]) + list(graph["internal"]):
        if node not in result:
            result.append(node)
    for edge in graph["edges"]:
        for node in (edge["u"], edge["v"]):
            if node not in result:
                result.append(node)
    return result


def zero(rows: int, cols: int) -> list[list[float]]:
    return [[0.0 for _ in range(cols)] for _ in range(rows)]


def solve_linear(matrix: Sequence[Sequence[float]], right: Sequence[Sequence[float]]) -> list[list[float]]:
    """Gauss--Jordan solve with partial pivoting."""

    n = len(matrix)
    if n == 0:
        return []
    m = len(right[0]) if right else 0
    augmented = [list(matrix[row]) + list(right[row]) for row in range(n)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda row: abs(augmented[row][col]))
        if abs(augmented[pivot][col]) <= EPS:
            raise ValueError("singular or ill-conditioned internal/Jacobian matrix")
        augmented[col], augmented[pivot] = augmented[pivot], augmented[col]
        scale = augmented[col][col]
        augmented[col] = [value / scale for value in augmented[col]]
        for row in range(n):
            if row == col:
                continue
            factor = augmented[row][col]
            if abs(factor) > 0.0:
                augmented[row] = [
                    augmented[row][j] - factor * augmented[col][j]
                    for j in range(n + m)
                ]
    return [row[n:] for row in augmented]


def laplacian_and_harmonic(graph: Mapping[str, Any], conductances: Mapping[str, float]) -> tuple[list[list[float]], list[list[float]]]:
    nodes = graph_nodes(graph)
    positions = {node: index for index, node in enumerate(nodes)}
    boundary = [positions[node] for node in graph["ports"]]
    internal = [positions[node] for node in graph["internal"]]
    laplacian = zero(len(nodes), len(nodes))
    for edge in graph["edges"]:
        value = conductances[edge["id"]]
        u, v = positions[edge["u"]], positions[edge["v"]]
        laplacian[u][u] += value
        laplacian[v][v] += value
        laplacian[u][v] -= value
        laplacian[v][u] -= value

    # H has one column per protected port and satisfies H|B=I, L_II H_I=-L_IB.
    harmonic = zero(len(nodes), len(boundary))
    for col, row in enumerate(boundary):
        harmonic[row][col] = 1.0
    if internal:
        l_ii = [[laplacian[row][col] for col in internal] for row in internal]
        l_ib = [[laplacian[row][col] for col in boundary] for row in internal]
        rhs = [[-value for value in row] for row in l_ib]
        internal_harmonic = solve_linear(l_ii, rhs)
        for row, values in zip(internal, internal_harmonic):
            harmonic[row] = values

    # The Schur complement is evaluated directly from the same Laplacian.
    l_pp = [[laplacian[row][col] for col in boundary] for row in boundary]
    if not internal:
        return l_pp, harmonic
    l_pi = [[laplacian[row][col] for col in internal] for row in boundary]
    l_ip = [[laplacian[row][col] for col in boundary] for row in internal]
    solved = solve_linear([[laplacian[row][col] for col in internal] for row in internal], l_ip)
    correction = [[sum(l_pi[i][k] * solved[k][j] for k in range(len(internal))) for j in range(len(boundary))] for i in range(len(boundary))]
    response = [[l_pp[i][j] - correction[i][j] for j in range(len(boundary))] for i in range(len(boundary))]
    return response, harmonic


def boundary_pairs(graph: Mapping[str, Any]) -> list[tuple[int, int]]:
    count = len(graph["ports"])
    return [(row, col) for row in range(count) for col in range(row + 1, count)]


def response_offdiag(response: Sequence[Sequence[float]], pairs: Sequence[tuple[int, int]]) -> list[float]:
    return [response[row][col] for row, col in pairs]


def norm_inf(values: Sequence[float]) -> float:
    return max((abs(value) for value in values), default=0.0)


def analytic_jacobian(graph: Mapping[str, Any], conductances: Mapping[str, float], harmonic: Sequence[Sequence[float]], pairs: Sequence[tuple[int, int]]) -> list[list[float]]:
    node_index = {node: row for row, node in enumerate(graph_nodes(graph))}
    jacobian = zero(len(pairs), len(graph["edges"]))
    for edge_index, edge in enumerate(graph["edges"]):
        u, v = node_index[edge["u"]], node_index[edge["v"]]
        drops = [harmonic[u][port] - harmonic[v][port] for port in range(len(graph["ports"]))]
        scale = conductances[edge["id"]]
        for equation, (row, col) in enumerate(pairs):
            jacobian[equation][edge_index] = scale * drops[row] * drops[col]
    return jacobian


def vector_add(left: Sequence[float], right: Sequence[float], scale: float = 1.0) -> list[float]:
    return [a + scale * b for a, b in zip(left, right)]


def finite(values: Sequence[float]) -> bool:
    return all(math.isfinite(value) for value in values)


def log_weights(edge_ids: Sequence[str], conductances: Mapping[str, float]) -> list[float]:
    return [math.log(max(conductances[edge_id], math.exp(LOG_MIN))) for edge_id in edge_ids]


def conductances_from_log(edge_ids: Sequence[str], logarithms: Sequence[float]) -> dict[str, float]:
    return {edge_id: math.exp(min(LOG_MAX, max(LOG_MIN, value))) for edge_id, value in zip(edge_ids, logarithms)}


def response_from_log(graph: Mapping[str, Any], edge_ids: Sequence[str], logarithms: Sequence[float], pairs: Sequence[tuple[int, int]]) -> tuple[list[float], list[list[float]], list[list[float]], dict[str, float]]:
    conductances = conductances_from_log(edge_ids, logarithms)
    response, harmonic = laplacian_and_harmonic(graph, conductances)
    return response_offdiag(response, pairs), response, harmonic, conductances


def newton_solve(
    graph: Mapping[str, Any],
    source_offdiag: Sequence[float],
    initial: Mapping[str, float],
    pairs: Sequence[tuple[int, int]],
    max_iterations: int = MAX_ITER,
) -> dict[str, Any]:
    edge_ids = [edge["id"] for edge in graph["edges"]]
    logarithms = log_weights(edge_ids, initial)
    history: list[dict[str, Any]] = []
    status = "max_iterations"
    failure: str | None = None
    final_response: list[list[float]] | None = None
    final_harmonic: list[list[float]] | None = None
    final_conductances: dict[str, float] | None = None
    for iteration in range(max_iterations):
        try:
            current, response, harmonic, conductances = response_from_log(graph, edge_ids, logarithms, pairs)
            residual = [current[i] - source_offdiag[i] for i in range(len(pairs))]
            residual_norm = norm_inf(residual)
        except (ValueError, OverflowError, ZeroDivisionError) as exc:
            status = "linear_algebra_failure"
            failure = str(exc)
            break
        history.append({"iteration": iteration, "residual_inf": residual_norm, "min_conductance": min(conductances.values()), "max_conductance": max(conductances.values())})
        final_response, final_harmonic, final_conductances = response, harmonic, conductances
        if not math.isfinite(residual_norm):
            status = "nonfinite_residual"
            failure = "nonfinite residual"
            break
        if residual_norm < 1.0e-10:
            status = "converged"
            break
        jacobian = analytic_jacobian(graph, conductances, harmonic, pairs)
        try:
            direction = [row[0] for row in solve_linear(jacobian, [[-value] for value in residual])]
        except (ValueError, OverflowError, ZeroDivisionError) as exc:
            status = "jacobian_failure"
            failure = str(exc)
            break
        max_direction = max((abs(value) for value in direction), default=0.0)
        if max_direction > 6.0:
            direction = [value * (6.0 / max_direction) for value in direction]
        accepted = False
        alpha = 1.0
        for _ in range(25):
            trial_logs = [min(LOG_MAX, max(LOG_MIN, current_log + alpha * step)) for current_log, step in zip(logarithms, direction)]
            try:
                trial_values, _, _, _ = response_from_log(graph, edge_ids, trial_logs, pairs)
                trial_residual = [trial_values[i] - source_offdiag[i] for i in range(len(pairs))]
                trial_norm = norm_inf(trial_residual)
            except (ValueError, OverflowError, ZeroDivisionError):
                trial_norm = math.inf
            if math.isfinite(trial_norm) and trial_norm < residual_norm:
                logarithms = trial_logs
                accepted = True
                break
            alpha *= 0.5
        if not accepted:
            status = "backtracking_stagnation"
            failure = "no Newton step decreased the residual"
            break
    if final_conductances is None:
        final_conductances = conductances_from_log(edge_ids, logarithms)
    if final_response is None:
        try:
            _, final_response, final_harmonic, _ = response_from_log(graph, edge_ids, logarithms, pairs)
        except Exception:
            final_response, final_harmonic = [], []
    final_offdiag = response_offdiag(final_response, pairs) if final_response else []
    final_residual = [final_offdiag[i] - source_offdiag[i] for i in range(min(len(final_offdiag), len(source_offdiag)))]
    return {
        "status": status,
        "success": status == "converged",
        "failure": failure,
        "iterations": len(history),
        "history": history,
        "target_conductances": final_conductances,
        "residual_inf": norm_inf(final_residual),
        "residual_offdiag": final_residual,
        "response": final_response,
        "harmonic": final_harmonic,
    }


def finite_difference_control(graph: Mapping[str, Any], conductances: Mapping[str, float], edge_id: str, pairs: Sequence[tuple[int, int]]) -> dict[str, Any]:
    edge_ids = [edge["id"] for edge in graph["edges"]]
    logarithms = log_weights(edge_ids, conductances)
    index = edge_ids.index(edge_id)
    _, response, harmonic, current = response_from_log(graph, edge_ids, logarithms, pairs)
    analytic = analytic_jacobian(graph, current, harmonic, pairs)
    step = 1.0e-6
    plus = list(logarithms)
    minus = list(logarithms)
    plus[index] += step
    minus[index] -= step
    plus_values, _, _, _ = response_from_log(graph, edge_ids, plus, pairs)
    minus_values, _, _, _ = response_from_log(graph, edge_ids, minus, pairs)
    finite_difference = [(plus_values[row] - minus_values[row]) / (2.0 * step) for row in range(len(pairs))]
    analytic_column = [analytic[row][index] for row in range(len(pairs))]
    errors = [abs(a - b) for a, b in zip(analytic_column, finite_difference)]
    return {
        "edge_id": edge_id,
        "step_in_log_conductance": step,
        "max_abs_error": max(errors),
        "pass_tolerance_1e-6": max(errors) < 1.0e-6,
        "analytic_column": analytic_column,
        "finite_difference_column": finite_difference,
    }


def source_patterns() -> list[dict[str, Any]]:
    base = {edge["id"]: 1.0 for edge in source_graph()["edges"]}
    patterns: list[dict[str, Any]] = []
    patterns.append({"name": "all_one", "weights": dict(base)})
    centre_a = dict(base)
    centre_a["a4"] = 0.1
    patterns.append({"name": "a4_centre_0.1", "weights": centre_a})
    triple_a = dict(base)
    for index in (3, 4, 5):
        triple_a[f"a{index}"] = 0.1
    patterns.append({"name": "a3_a4_a5_centre_0.1", "weights": triple_a})
    all_centre = dict(base)
    for index in range(7):
        all_centre[f"a{index}"] = 0.01
    patterns.append({"name": "all_a_centre_0.01", "weights": all_centre})
    return patterns


def initial_guesses(graph: Mapping[str, Any]) -> list[dict[str, Any]]:
    all_one = {edge["id"]: 1.0 for edge in graph["edges"]}
    s4_large = dict(all_one)
    s4_large["s4"] = 10.0
    return [{"name": "all_one", "weights": all_one}, {"name": "s4_10", "weights": s4_large}]


def graph_table(graph: Mapping[str, Any]) -> list[dict[str, str]]:
    return [dict(edge) for edge in graph["edges"]]


def run() -> dict[str, Any]:
    source = source_graph()
    target = target_graph()
    pairs = boundary_pairs(source)
    source_edge_ids = [edge["id"] for edge in source["edges"]]
    target_edge_ids = [edge["id"] for edge in target["edges"]]
    result: dict[str, Any] = {
        "scope": "Numerical endpoint exploration only; no exact proof, no planarity claim, and no claim that this candidate is the prescribed Conjecture 4 endpoint.",
        "numerical_domain": {
            "parameterization": "target conductance c_e=exp(y_e), so every trial conductance is strictly positive",
            "log_clamp": [LOG_MIN, LOG_MAX],
            "newton_iterations_per_start": MAX_ITER,
            "backtracking_trials_per_iteration": 25,
            "convergence_tolerance_inf_norm": 1.0e-10,
            "equations": "all 28 upper-triangular off-diagonal response entries on (p0,...,p6,z)",
        },
        "source_graph": {"ports": source["ports"], "internal": source["internal"], "edge_count": len(source["edges"]), "edges": graph_table(source)},
        "candidate_target_graph": {"ports": target["ports"], "internal": target["internal"], "edge_count": len(target["edges"]), "edges": graph_table(target)},
        "response_equations": [{"row": source["ports"][row], "column": source["ports"][col]} for row, col in pairs],
        "graph_count_check": {"source_edges_28": len(source["edges"]) == 28, "target_edges_28": len(target["edges"]) == 28, "source_internals_7": len(source["internal"]) == 7, "target_internals_8": len(target["internal"]) == 8, "equation_count_28": len(pairs) == 28},
        "patterns": [],
    }
    for pattern in source_patterns():
        source_response, _ = laplacian_and_harmonic(source, pattern["weights"])
        source_offdiag = response_offdiag(source_response, pairs)
        pattern_result: dict[str, Any] = {
            "name": pattern["name"],
            "source_weights": pattern["weights"],
            "source_response_offdiag": source_offdiag,
            "starts": [],
        }
        for guess in initial_guesses(target):
            solved = newton_solve(target, source_offdiag, guess["weights"], pairs)
            solved["start_name"] = guess["name"]
            solved["finite_difference_control"] = finite_difference_control(
                target,
                solved["target_conductances"],
                "s4",
                pairs,
            )
            pattern_result["starts"].append(solved)
            if solved["success"]:
                print(f"FOUND {pattern['name']} from {guess['name']}: residual_inf={solved['residual_inf']:.3e}")
        result["patterns"].append(pattern_result)
    result["summary"] = {
        "successful_runs": sum(1 for pattern in result["patterns"] for start in pattern["starts"] if start["success"]),
        "total_runs": sum(len(pattern["starts"]) for pattern in result["patterns"]),
        "all_runs_have_finite_residual": all(math.isfinite(start["residual_inf"]) for pattern in result["patterns"] for start in pattern["starts"]),
    }
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve()
    parser.add_argument("--output", type=Path, default=here.parent / "explore_n7_endpoint.json")
    args = parser.parse_args(argv)
    result = run()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(f"JSON: {args.output.resolve()}")
    print(json.dumps(result["summary"], ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
