# 局部响应的精确验证

更新：2026-10-15。统一数学证明在 [uniform_minor_proof.md](../notes/uniform_minor_proof.md)，七环例子在 [n7_closed_move.md](../notes/n7_closed_move.md)。计算是有限控制，不从有限样本推出任意 n。

| 新工具 | 范围与证书 |
| --- | --- |
| [verify_feature_minor_formulas.py](verify_feature_minor_formulas.py) | n=3–14，24组prefix/bordered minor及候选feature正性；72组精确退化公式；[证书](feature_minor_certificate.json) |
| [verify_uniform_path_table.py](verify_uniform_path_table.py) | n=3–30 表内路径逐点构造，不调用max-flow；56组paths及28组separator通过；[证书](path_table_certificate.json) |
| [verify_three_sided_formula.py](verify_three_sided_formula.py) | 三角形显式式子、完整响应、固定算法、严格正阈值及域外控制；[证书](three_sided_formula_certificate.json) |
| [verify_n7_closed_move.py](verify_n7_closed_move.py) | 七环两组正样本、Green 左逆；[证书](n7_closed_move_certificate.json) |
| [verify_uniform_minors.py](verify_uniform_minors.py) | n=3–14 规定图、端点声明、完整响应行和、缺失连接/双侧修复和minor符号；[证书](uniform_minors_certificate.json) |
| [verify_uniform_transform.py](verify_uniform_transform.py) | n=3–10 recovery、指定 F_n、除数、完整响应和正性；n=7–10 另加非对称样本；[证书](uniform_transform_certificate.json) |
| [verify_locality_and_inverse.py](verify_locality_and_inverse.py) | n=3–10逆、真正去星恢复、共同外部剥离；n=7–10固定core并改变外部原值/1/2，逐边core输出独立；[证书](locality_inverse_certificate.json) |
| [explore_n7_endpoint.py](explore_n7_endpoint.py) | 历史浮点 Newton 探针，未收敛不证明不存在 |

响应计算工具使用标准库 Fraction，路径表工具检查离散图的边、端口及连通性。从工作区运行 python computations/verify_uniform_transform.py 等，默认重写各自证书。每次收缩前检查实际端口 degree 1，目标 endpoint topology 逐边核对；中心从不消元。

以下为早期单元控制说明。

从工作目录运行：

```text
python computations/verify_local_controls.py
```

脚本只用 Python 标准库 `Fraction`。它从 [local_graphs.json](../notes/local_graphs.json) 建立 Laplacian，独立消去显式内部点，包含中心端口 z；默认重写 [local_control_certificate.json](local_control_certificate.json)。

证书涵盖七边恒等式及逆操作、n=3–6 每种两组精确正样本、Xi_7 完整首步，以及五边形缓存公式的两项残差。样本检查是符号证明的控制证据，不是任意 n 的证明。Xi_7 辅助图也不是 Conjecture 4 终点。

## 可重复补充附件

可分发的标准库附件见 [supplementary/punctured_disk_conditional_moves_supplement.zip](../supplementary/punctured_disk_conditional_moves_supplement.zip)。其 [构建脚本](../supplementary/build_supplement.py) 将七个论文入口、递归本地依赖、八份缓存证书和 `notes/local_graphs.json` 打包，并写入包内 `README.md` 与 `SHA256SUMS.txt`。附件 README 给出从独立解压根目录创建 `results/` 并逐项指定 `--output` 的完整命令；浮点探索输出、SVG 工具和 `__pycache__` 均不纳入包。

源图几何检查工具为 [inspect_source_svg.py](inspect_source_svg.py)。它读取已提取的原 SVG，记录路径、标签、颜色和坐标，可用本机 Edge 无头模式或 Pillow 渲染；原图与已有 PNG/JSON 在 [source_figures](../notes/source_figures/)。几何工具不自行决定端口，带端口解释由主证明逐图核对。
