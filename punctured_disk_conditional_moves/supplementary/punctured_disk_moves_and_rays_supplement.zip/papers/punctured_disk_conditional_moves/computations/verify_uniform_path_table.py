#!/usr/bin/env python3
"""Exact finite control of the path table and separators in the paper.

This utility expands the table ``tab:paths`` and its exceptional outer paths
into actual vertex sequences in the generated source and target graphs.  It
checks adjacency, observed/internal status, pair coverage, vertex disjointness,
and the stated ``k-1`` separators for n=3,...,30.  It is a finite source
control, not a proof of the all-n connection proposition.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

from verify_uniform_minors import (
    Q,
    build_base_and_target,
    build_source,
    exact_json,
    minor_indices,
    node_name,
    validate_graph,
)


class PathTableError(RuntimeError):
    """A path-table construction or graph-topology obstruction."""


def edge_map(graph: Mapping[str, Any]) -> dict[str, tuple[str, str]]:
    return {edge["id"]: (edge["u"], edge["v"]) for edge in graph["edges"]}


def edge_pairs(graph: Mapping[str, Any]) -> set[frozenset[str]]:
    return {frozenset((edge["u"], edge["v"])) for edge in graph["edges"]}


def edge_exists(graph: Mapping[str, Any], u: str, v: str) -> bool:
    return frozenset((u, v)) in edge_pairs(graph)


def other_endpoint(edge: tuple[str, str], current: str) -> str:
    if edge[0] == current:
        return edge[1]
    if edge[1] == current:
        return edge[0]
    raise PathTableError(f"edge {edge!r} does not meet current vertex {current!r}")


def outer_layer_node(residue: int, layers: int, index: int, target: bool) -> str:
    """Return the actual layer-zero vertex in source or target encoding."""

    index %= 4 * layers - 1 if residue == 3 else 4 * layers + residue
    if residue == 3:
        node = f"p{index}"
    elif residue == 0:
        node = f"w0_{index}" if index < 2 * layers else f"p{index}"
    else:
        node = f"w0_{index}"

    # The common-base contraction at p_0 changes the layer-zero label.
    if target and residue in (0, 1) and index == 0:
        node = "p0"
    # The target spike replaces the old outer polygon vertex by an internal
    # vertex.  The new observed port has the same logical index but is not the
    # polygon-layer vertex used by an arc.
    if target and residue in (3, 0) and index == 2 * layers:
        node = f"v{2 * layers}"
    return node


def endpoint_to_layer(
    graph: Mapping[str, Any],
    n: int,
    layers: int,
    residue: int,
    index: int,
    layer: int,
    target: bool,
) -> list[str]:
    """Follow the actual spike/radial edges from p_index to layer ``layer``."""

    index %= n
    current = f"p{index}"
    layer_zero = outer_layer_node(residue, layers, index, target)
    path = [current]
    if current != layer_zero:
        if not edge_exists(graph, current, layer_zero):
            raise PathTableError(
                f"missing outer spike from {current} to {layer_zero} in {'target' if target else 'source'}"
            )
        path.append(layer_zero)
    current = layer_zero
    for depth in range(layer):
        edge_id = f"rad{depth}_{index}"
        edge = edge_map(graph).get(edge_id)
        if edge is None:
            raise PathTableError(f"missing radial edge {edge_id}")
        current = other_endpoint(edge, current)
        path.append(current)
    expected = layer_zero if layer == 0 else node_name(layer, index)
    if path[-1] != expected:
        raise PathTableError(
            f"radial path for p{index} at layer {layer} ends at {path[-1]!r}, expected {expected!r}"
        )
    return path


def arc_columns(n: int, x: int, y: int, first: bool, endpoint_type: str) -> list[int]:
    """Return the column sequence from x to y on the requested polygon arc."""

    x %= n
    y %= n
    step = -1 if (endpoint_type == "j_minus_j" and first) else 1
    if endpoint_type == "minus_j_jplus1":
        step = 1 if first else -1
    columns = [x]
    current = x
    for _ in range(n):
        if current == y:
            break
        current = (current + step) % n
        columns.append(current)
    if columns[-1] != y:
        raise PathTableError(f"failed to construct polygon arc {x}->{y}, first={first}")
    return columns


def polygon_path(
    graph: Mapping[str, Any],
    n: int,
    layers: int,
    residue: int,
    p_index: int,
    q_index: int,
    layer: int,
    first: bool,
    target: bool,
) -> list[str]:
    endpoint_type = "minus_j_jplus1" if residue in (3, 2) else "j_minus_j"
    left = endpoint_to_layer(graph, n, layers, residue, p_index, layer, target)
    right = endpoint_to_layer(graph, n, layers, residue, q_index, layer, target)
    columns = arc_columns(n, p_index, q_index, first, endpoint_type)
    arc_nodes = [
        (outer_layer_node(residue, layers, column, target) if layer == 0 else node_name(layer, column))
        for column in columns
    ]
    if not edge_exists(graph, arc_nodes[0], left[-1]) or not edge_exists(graph, arc_nodes[-1], right[-1]):
        # The endpoint itself may already be the layer vertex, so these are
        # harmless zero-length joins; all positive-length joins are checked
        # below through the complete concatenated path.
        if arc_nodes[0] != left[-1] or arc_nodes[-1] != right[-1]:
            raise PathTableError(f"arc endpoint mismatch at layer {layer}: {arc_nodes}")
    path = left + arc_nodes[1:]
    path.extend(reversed(right[:-1]))
    return path


def direct_path(graph: Mapping[str, Any], p_index: int, q_index: int, edge_id: str | None = None) -> list[str]:
    p, q = f"p{p_index}", f"p{q_index}"
    if edge_id is not None:
        edges = edge_map(graph)
        if edge_id not in edges or frozenset(edges[edge_id]) != frozenset((p, q)):
            raise PathTableError(f"exceptional edge {edge_id} is not {p}-{q}")
    elif not edge_exists(graph, p, q):
        raise PathTableError(f"missing direct exceptional edge {p}-{q}")
    return [p, q]


def pair_indices(n: int, layers: int, residue: int, j: int) -> tuple[int, int]:
    if residue in (3, 2):
        return (-j) % n, (j + 1) % n
    return j % n, (-j) % n


def path_assignments(n: int, layers: int, residue: int, target: bool) -> list[dict[str, Any]]:
    """Expand exactly the table rows plus the nearby exceptional paths."""

    assignments: list[dict[str, Any]] = []

    def add_arc(j: int, layer: int, first: bool, tag: str) -> None:
        p, q = pair_indices(n, layers, residue, j)
        assignments.append({"j": j, "layer": layer, "first": first, "p": p, "q": q, "tag": tag, "kind": "arc"})

    def add_direct(j: int, edge_id: str, tag: str) -> None:
        p, q = pair_indices(n, layers, residue, j)
        assignments.append({"j": j, "layer": None, "first": None, "p": p, "q": q, "tag": tag, "kind": "direct", "edge_id": edge_id})

    if residue == 3:
        if target:
            for s in range(1, layers):
                add_arc(s - 1, s, True, f"table_target_first_s{s}")
                add_arc(2 * layers - 2 - s, s, False, f"table_target_opposite_s{s}")
            add_arc(2 * layers - 2, 0, False, "exception_target_old_p_2L")
        else:
            add_direct(0, "c0_0", "exception_source_b0")
            for s in range(1, layers):
                add_arc(s, s, True, f"table_source_first_s{s}")
                add_arc(2 * layers - 1 - s, s, False, f"table_source_opposite_s{s}")
    elif residue == 0:
        if target:
            for s in range(1, layers):
                add_arc(s, s, True, f"table_target_first_s{s}")
                add_arc(2 * layers - 1 - s, s, False, f"table_target_opposite_s{s}")
            add_arc(2 * layers - 1, 0, False, "exception_target_old_p_2L")
        else:
            add_arc(1, 0, True, "exception_source_old_p_0")
            for s in range(1, layers):
                add_arc(s + 1, s, True, f"table_source_first_s{s}")
                add_arc(2 * layers - s, s, False, f"table_source_opposite_s{s}")
    elif residue == 1:
        if target:
            for s in range(1, layers):
                add_arc(s, s, True, f"table_target_first_s{s}")
                add_arc(2 * layers - 1 - s, s, False, f"table_target_opposite_s{s}")
            add_direct(2 * layers, f"target_edge_{2 * layers}_{2 * layers + 1}", "exception_target_external_edge")
            add_arc(2 * layers - 1, 0, False, "exception_target_outer_opposite")
        else:
            add_arc(1, 0, True, "exception_source_outer_first")
            add_arc(2 * layers, 0, False, "exception_source_outer_opposite")
            for s in range(1, layers):
                add_arc(s + 1, s, True, f"table_source_first_s{s}")
                add_arc(2 * layers - s, s, False, f"table_source_opposite_s{s}")
    elif residue == 2:
        if target:
            for layer in range(layers):
                add_arc(layer, layer, True, f"table_target_first_a{layer}")
                add_arc(2 * layers - 1 - layer, layer, False, f"table_target_opposite_a{layer}")
            add_direct(2 * layers, f"target_edge_{2 * layers + 1}_{2 * layers + 2}", "exception_target_external_edge")
        else:
            add_direct(0, "b0", "exception_source_b0")
            for layer in range(layers):
                add_arc(layer + 1, layer, True, f"table_source_first_a{layer}")
                add_arc(2 * layers - layer, layer, False, f"table_source_opposite_a{layer}")
    else:
        raise PathTableError(f"unsupported residue {residue}")
    return assignments


def validate_paths(
    graph: Mapping[str, Any],
    n: int,
    layers: int,
    residue: int,
    target: bool,
) -> dict[str, Any]:
    P, Q_indices, k = minor_indices(n, layers, residue)
    assignments = path_assignments(n, layers, residue, target)
    paths: list[list[str]] = []
    failures: list[str] = []
    for assignment in assignments:
        try:
            if assignment["kind"] == "direct":
                path = direct_path(graph, assignment["p"], assignment["q"], assignment["edge_id"])
            else:
                path = polygon_path(
                    graph,
                    n,
                    layers,
                    residue,
                    assignment["p"],
                    assignment["q"],
                    assignment["layer"],
                    assignment["first"],
                    target,
                )
            paths.append(path)
        except Exception as exc:
            failures.append(f"{assignment['tag']}: {type(exc).__name__}: {exc}")
            paths.append([])

    expected_pairs = list(zip(P, Q_indices))
    pair_match = len(paths) == k and len(assignments) == k
    all_adjacent = True
    all_internal = True
    all_no_z = True
    all_simple = True
    vertex_owner: dict[str, int] = {}
    disjoint = True
    path_records: list[dict[str, Any]] = []
    pairs_seen: list[tuple[int, int]] = []
    for index, (assignment, path) in enumerate(zip(assignments, paths)):
        expected = (assignment["p"], assignment["q"])
        actual = None
        if path:
            actual = (
                int(path[0][1:]) if path[0].startswith("p") else None,
                int(path[-1][1:]) if path[-1].startswith("p") else None,
            )
            pairs_seen.append(actual)
            simple = len(path) == len(set(path))
            all_simple = all_simple and simple
            if path[0] != f"p{expected[0]}" or path[-1] != f"p{expected[1]}":
                pair_match = False
            for left, right in zip(path, path[1:]):
                if not edge_exists(graph, left, right):
                    all_adjacent = False
                    failures.append(f"{assignment['tag']}: missing edge {left}-{right}")
            transit = path[1:-1]
            if any(vertex in graph["ports"] for vertex in transit):
                all_internal = False
                failures.append(f"{assignment['tag']}: observed transit vertex in {path}")
            if "z" in path:
                all_no_z = False
                failures.append(f"{assignment['tag']}: z occurs in {path}")
            for vertex in path:
                if vertex in vertex_owner and vertex_owner[vertex] != index:
                    disjoint = False
                    failures.append(
                        f"{assignment['tag']}: vertex {vertex} shared with path {vertex_owner[vertex]}"
                    )
                else:
                    vertex_owner[vertex] = index
        path_records.append({"tag": assignment["tag"], "j": assignment["j"], "p": expected[0], "q": expected[1], "path": path, "actual_pair": actual})
    expected_pair_set = set(expected_pairs)
    actual_pair_set = set(pairs_seen)
    pair_match = pair_match and actual_pair_set == expected_pair_set and len(pairs_seen) == len(expected_pair_set)
    checks = {
        "path_count_k": len(paths) == k,
        "pair_count_k": len(assignments) == k,
        "pairs_match_minor_indices": pair_match,
        "all_edges_are_actual": all_adjacent and not failures,
        "all_transit_vertices_internal": all_internal,
        "z_never_used": all_no_z,
        "all_paths_simple": all_simple,
        "all_paths_vertex_disjoint": disjoint,
    }
    return {
        "path_count": len(paths),
        "expected_k": k,
        "P": P,
        "Q": Q_indices,
        "checks": checks,
        "failures": failures,
        "path_records": path_records if failures else [],
        "all_checks_pass": all(checks.values()) and not failures,
    }


def reachable_after_separator(
    graph: Mapping[str, Any],
    P: Sequence[int],
    Q_indices: Sequence[int],
    removed: set[str],
) -> bool:
    ports = list(graph["ports"])
    sources = {ports[index] for index in P}
    sinks = {ports[index] for index in Q_indices}
    allowed = set(ports) | set(graph.get("internal", []))
    allowed -= removed
    queue = list(sources & allowed)
    visited = set(queue)
    adjacency: dict[str, set[str]] = {node: set() for node in allowed}
    for edge in graph["edges"]:
        u, v = edge["u"], edge["v"]
        if u in allowed and v in allowed:
            adjacency[u].add(v)
            adjacency[v].add(u)
    while queue:
        node = queue.pop()
        for neighbour in adjacency[node]:
            if neighbour not in visited:
                visited.add(neighbour)
                queue.append(neighbour)
    return bool(visited & sinks)


def separator_vertices(
    base: Mapping[str, Any], n: int, layers: int, residue: int
) -> tuple[set[str], str]:
    vertices: set[str] = set()
    if residue in (3, 0):
        for layer in range(1, layers):
            vertices.update({node_name(layer, 0), node_name(layer, 2 * layers)})
        rule = "inner columns 0 and 2L"
    elif residue == 1:
        vertices.add(outer_layer_node(residue, layers, 2 * layers, False))
        for layer in range(1, layers):
            vertices.update({node_name(layer, 0), node_name(layer, 2 * layers)})
        rule = "outer w0,2L plus inner columns 0 and 2L"
    elif residue == 2:
        for layer in range(layers):
            vertices.update(
                {
                    outer_layer_node(residue, layers, 0, False) if layer == 0 else node_name(layer, 0),
                    outer_layer_node(residue, layers, 2 * layers + 1, False) if layer == 0 else node_name(layer, 2 * layers + 1),
                }
            )
        rule = "columns 0 and 2L+1 on every layer"
    else:
        raise PathTableError(f"unsupported residue {residue}")
    declared = set(base["ports"]) | set(base.get("internal", []))
    if not vertices <= declared:
        raise PathTableError(f"separator contains undeclared vertices: {sorted(vertices - declared)}")
    if any(vertex in base["ports"] for vertex in vertices):
        raise PathTableError(f"separator contains observed vertex: {sorted(vertices & set(base['ports']))}")
    return vertices, rule


def validate_separator(
    base: Mapping[str, Any], n: int, layers: int, residue: int
) -> dict[str, Any]:
    P, Q_indices, k = minor_indices(n, layers, residue)
    separator, rule = separator_vertices(base, n, layers, residue)
    endpoint_ports = {base["ports"][index] for index in P + Q_indices}
    unused_observed = set(base["ports"]) - endpoint_ports
    removed = set(separator) | {"z"} | unused_observed
    connected = reachable_after_separator(base, P, Q_indices, removed)
    expected_size = k - 1
    checks = {
        "separator_size_k_minus_1": len(separator) == expected_size,
        "separator_internal": all(vertex in base.get("internal", []) for vertex in separator),
        "z_removed": "z" in removed,
        "unused_observed_removed": unused_observed <= removed,
        "P_Q_disconnected": not connected,
    }
    return {
        "P": P,
        "Q": Q_indices,
        "k": k,
        "separator_rule": rule,
        "separator_vertices": sorted(separator),
        "separator_size": len(separator),
        "unused_observed_ports": sorted(unused_observed),
        "removed_count": len(removed),
        "checks": checks,
        "all_checks_pass": all(checks.values()),
        "failure": "P-to-Q path remains after separator removal" if connected else None,
    }


def check_n(n: int) -> dict[str, Any]:
    source, layers, residue = build_source(n)
    base, target = build_base_and_target(source, n, layers, residue)
    graph_checks = {
        "source": validate_graph(source),
        "base": validate_graph(base),
        "target": validate_graph(target),
    }
    if not all(item["valid"] for item in graph_checks.values()):
        raise PathTableError(f"invalid generated graph for n={n}")
    source_paths = validate_paths(source, n, layers, residue, target=False)
    target_paths = validate_paths(target, n, layers, residue, target=True)
    separator = validate_separator(base, n, layers, residue)
    failures: list[str] = []
    if not source_paths["all_checks_pass"]:
        failures.append("source path table failed")
    if not target_paths["all_checks_pass"]:
        failures.append("target path table failed")
    if not separator["all_checks_pass"]:
        failures.append("separator failed")
    return {
        "n": n,
        "layers_L": layers,
        "residue": residue,
        "k": source_paths["expected_k"],
        "source_path_count": source_paths["path_count"],
        "target_path_count": target_paths["path_count"],
        "source_paths": source_paths,
        "target_paths": target_paths,
        "separator": separator,
        "failures": failures,
        "all_checks_pass": not failures,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve()
    parser.add_argument("--output", type=Path, default=here.parent / "path_table_certificate.json")
    args = parser.parse_args(argv)
    cases: list[dict[str, Any]] = []
    for n in range(3, 31):
        try:
            cases.append(check_n(n))
        except Exception as exc:
            cases.append({"n": n, "all_checks_pass": False, "failures": [f"{type(exc).__name__}: {exc}"]})
    path_groups = sum(2 for case in cases if case.get("source_path_count") is not None)
    separator_groups = sum(1 for case in cases if "separator" in case)
    all_paths_pass = all(
        case.get("source_paths", {}).get("all_checks_pass", False)
        and case.get("target_paths", {}).get("all_checks_pass", False)
        for case in cases
    )
    all_separators_pass = all(case.get("separator", {}).get("all_checks_pass", False) for case in cases)
    all_checks_pass = all(case.get("all_checks_pass", False) for case in cases)
    exit_code = 0 if all_checks_pass and path_groups == 56 and separator_groups == 28 else 1
    certificate = {
        "scope": "Finite literal expansion of the paper's tab:paths and exceptional outer paths, plus its H_n k-1 separators, for n=3,...,30. This is a source-level control and not an all-n proof.",
        "command": "python verify_uniform_path_table.py",
        "exit_code": exit_code,
        "n_range": [3, 30],
        "path_group_count": path_groups,
        "expected_path_group_count": 56,
        "separator_group_count": separator_groups,
        "expected_separator_group_count": 28,
        "all_paths_pass": all_paths_pass,
        "all_separators_pass": all_separators_pass,
        "all_checks_pass": all_checks_pass,
        "cases": cases,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(exact_json(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"certificate: {args.output.resolve()}")
    print(f"path_groups: {path_groups}/56")
    print(f"separator_groups: {separator_groups}/28")
    print(f"all_paths_pass: {all_paths_pass}")
    print(f"all_separators_pass: {all_separators_pass}")
    print(f"exit_code: {exit_code}")
    for case in cases:
        print(case.get("n"), "paths=" + str(case.get("all_checks_pass", False)), "failures=" + str(case.get("failures", [])))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
