#!/usr/bin/env python3
"""Finite exact control for the proposed uniform response transformation.

This utility is deliberately a certificate generator, not a proof of the
uniform construction.  It searches the prescribed circular linkage witnesses,
strips the base topology by exact edge/spike inversions, and checks the full
protected-port response for n=3,...,10.
"""

from __future__ import annotations

import argparse
import json
from itertools import combinations
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence

from verify_local_controls import graph_response
from verify_n7_closed_move import determinant
from verify_uniform_minors import (
    Q,
    all_one,
    b_id,
    build_base_and_target,
    build_source,
    exact_json,
    linkage_count,
    matrix_add,
    minor_indices,
    response_minor,
    validate_graph,
    validate_response,
)


class AlgorithmError(RuntimeError):
    """A topology or exact-division obstruction in the finite control."""


def clone_graph(graph: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "ports": list(graph["ports"]),
        "internal": list(graph.get("internal", [])),
        "edges": [dict(edge) for edge in graph["edges"]],
    }


def edge_by_id(graph: Mapping[str, Any], edge_id: str) -> dict[str, str]:
    matches = [edge for edge in graph["edges"] if edge["id"] == edge_id]
    if len(matches) != 1:
        raise AlgorithmError(f"expected one edge {edge_id!r}, found {len(matches)}")
    return dict(matches[0])


def remove_edge(graph: Mapping[str, Any], edge_id: str) -> dict[str, Any]:
    result = clone_graph(graph)
    before = len(result["edges"])
    result["edges"] = [edge for edge in result["edges"] if edge["id"] != edge_id]
    if len(result["edges"]) != before - 1:
        raise AlgorithmError(f"cannot delete missing or duplicate edge {edge_id!r}")
    return result


def contract_port_edge(graph: Mapping[str, Any], edge_id: str, port: str) -> dict[str, Any]:
    """Contract an edge from an existing port to one internal vertex."""

    edge = edge_by_id(graph, edge_id)
    internal = set(graph.get("internal", []))
    ports = set(graph["ports"])
    if port not in ports:
        raise AlgorithmError(f"contraction port {port!r} is not declared")
    if edge["u"] == port and edge["v"] in internal:
        old = edge["v"]
    elif edge["v"] == port and edge["u"] in internal:
        old = edge["u"]
    else:
        raise AlgorithmError(f"edge {edge_id!r} is not a port-to-internal contraction at {port!r}")
    result = clone_graph(graph)
    result["edges"] = []
    for candidate in graph["edges"]:
        if candidate["id"] == edge_id:
            continue
        updated = dict(candidate)
        if updated["u"] == old:
            updated["u"] = port
        if updated["v"] == old:
            updated["v"] = port
        if updated["u"] == updated["v"]:
            raise AlgorithmError(f"contraction {edge_id!r} creates a self-loop on {port!r}")
        result["edges"].append(updated)
    result["internal"] = [node for node in result["internal"] if node != old]
    return result


def matrix_copy(matrix: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    return [list(row) for row in matrix]


def matrix_sub(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    return [[left[row][col] - right[row][col] for col in range(len(left[row]))] for row in range(len(left))]


def matrix_scale(matrix: Sequence[Sequence[Fraction]], scalar: Fraction) -> list[list[Fraction]]:
    return [[scalar * entry for entry in row] for row in matrix]


def rank_one_from_response(response: Sequence[Sequence[Fraction]], port_index: int) -> list[list[Fraction]]:
    return [
        [response[row][port_index] * response[port_index][col] for col in range(len(response))]
        for row in range(len(response))
    ]


def max_abs_matrix(matrix: Sequence[Sequence[Fraction]]) -> Fraction:
    return max((abs(entry) for row in matrix for entry in row), default=Q(0))


def matrix_residual(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> Fraction:
    if len(left) != len(right) or any(len(a) != len(b) for a, b in zip(left, right)):
        return Q(1)
    return max_abs_matrix(matrix_sub(left, right))


def circular_candidates(n: int):
    """Yield every cyclic P/Q pair with Q in reverse order."""

    for k in range(1, n // 2 + 1):
        # ``2k cyclic ports`` means any 2k-subset in cyclic order, with every
        # possible cut used as the P/Q boundary; the subset need not be a
        # consecutive block of the full outer cycle.
        for subset in combinations(range(n), 2 * k):
            for rotation in range(2 * k):
                ordered = list(subset[rotation:]) + list(subset[:rotation])
                P = ordered[:k]
                Q_indices = list(reversed(ordered[k:]))
                yield P, Q_indices, k, ordered[0]


def find_witness(
    before: Mapping[str, Any],
    after: Mapping[str, Any],
    n: int,
    exclude_ports: Sequence[int] = (),
) -> dict[str, Any] | None:
    """Find the first prescribed circular linkage lost by the operation."""

    excluded = set(exclude_ports)
    for P, Q_indices, k, start in circular_candidates(n):
        if excluded.intersection(P) or excluded.intersection(Q_indices):
            continue
        before_linkage = linkage_count(before, P, Q_indices)
        if before_linkage != k:
            continue
        after_linkage = linkage_count(after, P, Q_indices)
        if after_linkage >= k:
            continue
        return {
            "P": P,
            "Q": Q_indices,
            "k": k,
            "start": start,
            "before_linkage": before_linkage,
            "after_linkage": after_linkage,
        }
    return None


def port_edge_matrix(ports: Sequence[str], edge: Mapping[str, str]) -> list[list[Fraction]]:
    size = len(ports)
    if edge["u"] not in ports or edge["v"] not in ports:
        raise AlgorithmError(f"edge {edge['id']!r} is not a port-port edge")
    u = ports.index(edge["u"])
    v = ports.index(edge["v"])
    update = [[Q(0) for _ in range(size)] for _ in range(size)]
    update[u][u] += 1
    update[v][v] += 1
    update[u][v] -= 1
    update[v][u] -= 1
    return update


def division_record(records: list[dict[str, Any]], name: str, numerator: Fraction, denominator: Fraction) -> None:
    records.append({"name": name, "numerator": numerator, "denominator": denominator, "nonzero": denominator != 0})
    if denominator == 0:
        raise AlgorithmError(f"zero denominator in {name}")


def operation_record(
    operation: str,
    edge_id: str,
    edge_weight: Fraction,
    witness: Mapping[str, Any],
    before: Mapping[str, Any],
    after: Mapping[str, Any],
) -> dict[str, Any]:
    return {
        "operation": operation,
        "edge_id": edge_id,
        "recovered_weight": edge_weight,
        "witness": dict(witness),
        "before_edge_count": len(before["edges"]),
        "after_edge_count": len(after["edges"]),
    }


def recover_base_weights(
    base: Mapping[str, Any],
    initial_response: Sequence[Sequence[Fraction]],
    n: int,
    layers: int,
    residue: int,
) -> dict[str, Any]:
    """Recover every base edge by the prescribed deletion/contraction order."""

    graph = clone_graph(base)
    response = matrix_copy(initial_response)
    ports = list(base["ports"])
    divisions: list[dict[str, Any]] = []
    operations: list[dict[str, Any]] = []
    weights: dict[str, Fraction] = {}

    def recover_edge(edge_id: str) -> None:
        nonlocal graph, response
        edge = edge_by_id(graph, edge_id)
        after = remove_edge(graph, edge_id)
        witness = find_witness(graph, after, n)
        if witness is None:
            raise AlgorithmError(f"no deletion witness for {edge_id}")
        P, Q_indices = witness["P"], witness["Q"]
        F = response_minor(response, P, Q_indices)
        update = port_edge_matrix(ports, edge)
        D = response_minor(matrix_add(response, update), P, Q_indices) - F
        division_record(divisions, f"delete:{edge_id}:D", F, D)
        coefficient = F / D
        response = matrix_sub(response, matrix_scale(update, coefficient))
        weights[edge_id] = coefficient
        operations.append(operation_record("delete_edge", edge_id, coefficient, witness, graph, after))
        graph = after

    def recover_contraction(edge_id: str, port_index: int, operation: str) -> None:
        nonlocal graph, response
        port = ports[port_index]
        edge = edge_by_id(graph, edge_id)
        port_degree = sum(port in (candidate["u"], candidate["v"]) for candidate in graph["edges"])
        if port_degree != 1:
            raise AlgorithmError(
                f"cannot contract {edge_id} at {port}: port degree {port_degree}, expected 1 in the full center-star graph"
            )
        after = contract_port_edge(graph, edge_id, port)
        witness = find_witness(graph, after, n, exclude_ports=(port_index,))
        if witness is None:
            raise AlgorithmError(f"no contraction witness for {edge_id} at {port}")
        P, Q_indices = witness["P"], witness["Q"]
        F = response_minor(response, P, Q_indices)
        rank_one = rank_one_from_response(response, port_index)
        B = response_minor(matrix_add(response, rank_one), P, Q_indices) - F
        division_record(divisions, f"contract:{edge_id}:F", B, F)
        coefficient = response[port_index][port_index] - B / F
        denominator = coefficient - response[port_index][port_index]
        division_record(divisions, f"contract:{edge_id}:c-Mpp", Q(1), denominator)
        response = matrix_add(response, matrix_scale(rank_one, Q(1) / denominator))
        weights[edge_id] = coefficient
        operation_data = operation_record(operation, edge_id, coefficient, witness, graph, after)
        operation_data["contract_port"] = port
        operation_data["port_degree_before"] = port_degree
        operations.append(operation_data)
        graph = after

    if residue == 2:
        for index in range(-layers, layers + 1):
            if index == 0:
                continue
            edge_id = b_id(index)
            if any(edge["id"] == edge_id for edge in graph["edges"]):
                recover_edge(edge_id)

    spike_ids = sorted(
        (edge["id"] for edge in graph["edges"] if edge["id"].startswith("spike_")),
        key=lambda edge_id: int(edge_id.split("_")[1]),
    )
    for edge_id in spike_ids:
        edge = edge_by_id(graph, edge_id)
        port_candidates = [node for node in (edge["u"], edge["v"]) if node in ports]
        if len(port_candidates) != 1:
            raise AlgorithmError(f"spike {edge_id} has unexpected endpoints {edge}")
        recover_contraction(edge_id, ports.index(port_candidates[0]), "contract_spike")

    for layer in range(max(0, layers - 1)):
        for index in range(n):
            edge_id = f"c{layer}_{index}"
            if any(edge["id"] == edge_id for edge in graph["edges"]):
                recover_edge(edge_id)
        for index in range(n):
            edge_id = f"rad{layer}_{index}"
            recover_contraction(edge_id, index, "contract_radial")

    final_validation = validate_graph(graph)
    pair_list = [tuple(sorted((edge["u"], edge["v"]))) for edge in graph["edges"]]
    final_checks = {
        "graph_valid": final_validation["valid"],
        "all_vertices_ports": not graph["internal"],
        "no_parallel_edges": len(pair_list) == len(set(pair_list)),
        "remaining_edges_port_port": all(edge["u"] in ports and edge["v"] in ports for edge in graph["edges"]),
        "remaining_ids_cycle_or_center": all(edge["id"].startswith("c") or edge["id"].startswith("center_") for edge in graph["edges"]),
    }
    if not all(final_checks.values()):
        raise AlgorithmError(f"final base topology check failed: {final_checks}")
    for edge in graph["edges"]:
        u, v = ports.index(edge["u"]), ports.index(edge["v"])
        weight = -response[u][v]
        weights[edge["id"]] = weight
        operations.append({"operation": "final_off_diagonal", "edge_id": edge["id"], "recovered_weight": weight})

    expected_ids = {edge["id"] for edge in base["edges"]}
    recovered_checks = {
        "all_base_edge_ids_recovered": set(weights) == expected_ids,
        "all_divisions_nonzero": all(item["nonzero"] for item in divisions),
    }
    if not all(recovered_checks.values()):
        raise AlgorithmError(f"base recovery bookkeeping failed: {recovered_checks}")
    return {
        "weights": weights,
        "stripped_response": response,
        "operations": operations,
        "division_checks": divisions,
        "final_graph": graph,
        "final_checks": final_checks,
        "checks": recovered_checks,
    }


def target_descriptor(target: Mapping[str, Any], n: int, layers: int, residue: int) -> dict[str, Any]:
    t = 2 * layers
    if residue in (1, 2):
        edge_id = f"target_edge_{t}_{t + 1}" if residue == 1 else f"target_edge_{t + 1}_{t + 2}"
        return {"kind": "boundary_edge", "edge_id": edge_id, "port_index": None}
    return {"kind": "spike", "edge_id": f"target_spike_{t}", "port_index": t % n}


def edge_endpoint_map(graph: Mapping[str, Any]) -> dict[str, tuple[str, str]]:
    return {edge["id"]: tuple(sorted((edge["u"], edge["v"]))) for edge in graph["edges"]}


def extract_target_parameter(
    target: Mapping[str, Any],
    base: Mapping[str, Any],
    source_response: Sequence[Sequence[Fraction]],
    n: int,
    layers: int,
    residue: int,
) -> dict[str, Any]:
    descriptor = target_descriptor(target, n, layers, residue)
    feature_id = descriptor["edge_id"]
    target_port_degree: int | None = None
    if descriptor["kind"] == "boundary_edge":
        after = remove_edge(target, feature_id)
    else:
        port_index = descriptor["port_index"]
        port = target["ports"][port_index]
        target_port_degree = sum(port in (edge["u"], edge["v"]) for edge in target["edges"])
        if target_port_degree != 1:
            raise AlgorithmError(
                f"cannot contract target {feature_id} at {port}: port degree {target_port_degree}, expected 1 in the full center-star graph"
            )
        after = contract_port_edge(target, feature_id, port)
    P, Q_indices, k = minor_indices(n, layers, residue)
    before_linkage = linkage_count(target, P, Q_indices)
    after_linkage = linkage_count(after, P, Q_indices)
    if before_linkage != k or after_linkage >= k:
        raise AlgorithmError(
            f"common target minor is not a linkage witness for {feature_id}: "
            f"before={before_linkage}, after={after_linkage}, expected before={k}, after<{k}"
        )
    witness = {
        "P": P,
        "Q": Q_indices,
        "k": k,
        "before_linkage": before_linkage,
        "after_linkage": after_linkage,
        "source": "minor_indices",
    }
    F = response_minor(source_response, P, Q_indices)
    divisions: list[dict[str, Any]] = []
    if descriptor["kind"] == "boundary_edge":
        edge = edge_by_id(target, feature_id)
        update = port_edge_matrix(target["ports"], edge)
        D = response_minor(matrix_add(source_response, update), P, Q_indices) - F
        division_record(divisions, f"target_edge:{feature_id}:D", F, D)
        parameter = F / D
        stripped = matrix_sub(source_response, matrix_scale(update, parameter))
        data = {"F": F, "D": D, "F_over_D": parameter}
    else:
        port_index = descriptor["port_index"]
        rank_one = rank_one_from_response(source_response, port_index)
        B = response_minor(matrix_add(source_response, rank_one), P, Q_indices) - F
        division_record(divisions, f"target_spike:{feature_id}:F", B, F)
        parameter = source_response[port_index][port_index] - B / F
        denominator = parameter - source_response[port_index][port_index]
        division_record(divisions, f"target_spike:{feature_id}:h-Mpp", Q(1), denominator)
        stripped = matrix_add(source_response, matrix_scale(rank_one, Q(1) / denominator))
        data = {"F": F, "B": B, "B_over_F": B / F, "Mpp": source_response[port_index][port_index]}
    base_topology_match = {
        "edge_count": len(after["edges"]) == len(base["edges"]),
        "ports": list(after["ports"]) == list(base["ports"]),
        "internal": list(after.get("internal", [])) == list(base.get("internal", [])),
        "edge_ids": set(edge_endpoint_map(after)) == set(edge_endpoint_map(base)),
        "edge_endpoints": edge_endpoint_map(after) == edge_endpoint_map(base),
    }
    return {
        "descriptor": descriptor,
        "target_port_degree_before": target_port_degree,
        "witness": witness,
        "parameter": parameter,
        "parameter_positive": parameter > 0,
        "data": data,
        "stripped_response": stripped,
        "division_checks": divisions,
        "base_topology_match": base_topology_match,
        "checks": {
            "parameter_positive": parameter > 0,
            "all_divisions_nonzero": all(item["nonzero"] for item in divisions),
            "base_topology_match": all(base_topology_match.values()),
            "common_minor_is_linkage_witness": witness["source"] == "minor_indices" and before_linkage == k and after_linkage < k,
        },
    }


def response_and_graph_checks(graph: Mapping[str, Any], response: Sequence[Sequence[Fraction]]) -> dict[str, Any]:
    return {
        "graph": validate_graph(graph),
        "response": validate_response(response, len(graph["ports"])),
    }


def base_recovery_case(n: int) -> dict[str, Any]:
    source, layers, residue = build_source(n)
    base, target = build_base_and_target(source, n, layers, residue)
    base_response = graph_response(base, all_one(base))
    recovery = recover_base_weights(base, base_response, n, layers, residue)
    recovered_response = graph_response(base, recovery["weights"])
    weight_checks = {
        edge_id: recovery["weights"][edge_id] == Q(1) for edge_id in sorted(recovery["weights"])
    }
    checks = {
        "base_input_graph_valid": validate_graph(base)["valid"],
        "base_input_response_valid": validate_response(base_response, n + 1)["valid"],
        "recovered_response_exact": matrix_residual(base_response, recovered_response) == 0,
        "recovered_all_one": all(weight_checks.values()),
        "recovery_checks": all(recovery["checks"].values()),
        "final_checks": all(recovery["final_checks"].values()),
    }
    return {
        "n": n,
        "residue": residue,
        "layers_L": layers,
        "base_edge_count": len(base["edges"]),
        "operation_count": len(recovery["operations"]),
        "division_count": len(recovery["division_checks"]),
        "recovered_weights": recovery["weights"],
        "max_response_residual": matrix_residual(base_response, recovered_response),
        "checks": checks,
        "all_checks_pass": all(checks.values()),
        "recovery": recovery,
    }


def source_weights_for_epsilon(
    source: Mapping[str, Any],
    residue: int,
    epsilon: Fraction,
    shared_weights: Mapping[str, Fraction] | None = None,
) -> tuple[dict[str, Fraction], str, Fraction]:
    weights = all_one(source)
    if shared_weights:
        for edge_id, weight in shared_weights.items():
            if edge_id in weights:
                weights[edge_id] = weight
    if residue == 3:
        feature_id = "c0_0"
        feature_weight = epsilon
    elif residue == 2:
        feature_id = "b0"
        feature_weight = epsilon
    else:
        feature_id = "spike_0"
        feature_weight = Q(1) / epsilon
    weights[feature_id] = feature_weight
    return weights, feature_id, feature_weight


def source_transform_attempt(
    n: int,
    source: Mapping[str, Any],
    base: Mapping[str, Any],
    target: Mapping[str, Any],
    layers: int,
    residue: int,
    epsilon: Fraction,
    shared_weights: Mapping[str, Fraction] | None = None,
) -> dict[str, Any]:
    source_weights, source_feature_id, source_feature_weight = source_weights_for_epsilon(
        source, residue, epsilon, shared_weights
    )
    source_response = graph_response(source, source_weights)
    target_parameter = extract_target_parameter(target, base, source_response, n, layers, residue)
    recovery = recover_base_weights(base, target_parameter["stripped_response"], n, layers, residue)
    recovered_base_response = graph_response(base, recovery["weights"])
    target_weights = {edge["id"]: recovery["weights"][edge["id"]] for edge in base["edges"]}
    target_feature_id = target_parameter["descriptor"]["edge_id"]
    target_weights[target_feature_id] = target_parameter["parameter"]
    target_response = graph_response(target, target_weights)
    source_response_valid = validate_response(source_response, n + 1)
    target_response_valid = validate_response(target_response, n + 1)
    all_divisions = target_parameter["division_checks"] + recovery["division_checks"]
    base_positive = all(weight > 0 for weight in recovery["weights"].values())
    target_positive = all(weight > 0 for weight in target_weights.values())
    source_positive = all(weight > 0 for weight in source_weights.values())
    no_auxiliary_ids = all("aux" not in edge["id"] for edge in target["edges"])
    checks = {
        "source_response_valid": source_response_valid["valid"],
        "target_response_valid": target_response_valid["valid"],
        "target_parameter_positive": target_parameter["parameter"] > 0,
        "base_weights_positive": base_positive,
        "target_weights_positive": target_positive,
        "source_weights_positive": source_positive,
        "base_recovery_response_exact": matrix_residual(target_parameter["stripped_response"], recovered_base_response) == 0,
        "target_source_response_exact": matrix_residual(source_response, target_response) == 0,
        "all_divisions_nonzero": all(item["nonzero"] for item in all_divisions),
        "no_auxiliary_edge_ids": no_auxiliary_ids,
        "source_no_auxiliary_edge_ids": all("aux" not in edge["id"] for edge in source["edges"]),
        "base_no_auxiliary_edge_ids": all("aux" not in edge["id"] for edge in base["edges"]),
        "target_graph_valid": validate_graph(target)["valid"],
        "recovered_base_response_valid": validate_response(recovered_base_response, n + 1)["valid"],
    }
    return {
        "epsilon": epsilon,
        "source_feature_id": source_feature_id,
        "source_feature_weight": source_feature_weight,
        "source_response": source_response,
        "target_parameter": target_parameter,
        "recovery": recovery,
        "target_weights": target_weights,
        "residuals": {
            "base_response": matrix_residual(target_parameter["stripped_response"], recovered_base_response),
            "target_source_response": matrix_residual(source_response, target_response),
        },
        "checks": checks,
        "positive_sample": all(checks.values()),
    }


def source_transform_case(
    n: int,
    shared_weights: Mapping[str, Fraction] | None = None,
    sample_name: str = "all_one_shared_edges",
) -> dict[str, Any]:
    source, layers, residue = build_source(n)
    base, target = build_base_and_target(source, n, layers, residue)
    attempts: list[dict[str, Any]] = []
    selected: dict[str, Any] | None = None
    for exponent in range(2, 8):
        epsilon = Q(1, 10**exponent)
        try:
            attempt = source_transform_attempt(n, source, base, target, layers, residue, epsilon, shared_weights)
        except Exception as exc:  # record finite obstruction without hiding it
            attempt = {"epsilon": epsilon, "positive_sample": False, "error": f"{type(exc).__name__}: {exc}"}
        attempts.append(attempt)
        if attempt.get("positive_sample"):
            selected = attempt
            break
    initial = attempts[0]
    checks = {
        "initial_attempt_recorded": bool(attempts),
        "positive_sample_found": selected is not None,
        "initial_or_fallback_exact": selected is not None and all(selected["checks"].values()),
    }
    return {
        "n": n,
        "residue": residue,
        "layers_L": layers,
        "sample_name": sample_name,
        "shared_weight_rule": "all shared base/source/target edge IDs have weight 1+(index mod 5)/100" if shared_weights else "all shared edge weights are 1",
        "shared_weight_count": len(shared_weights) if shared_weights else len(base["edges"]),
        "initial_epsilon": initial.get("epsilon"),
        "initial_positive_sample": initial.get("positive_sample", False),
        "attempt_count": len(attempts),
        "attempts": attempts,
        "selected_epsilon": selected.get("epsilon") if selected else None,
        "checks": checks,
        "all_checks_pass": all(checks.values()),
    }


def asymmetric_shared_weights(n: int) -> dict[str, Fraction]:
    source, layers, residue = build_source(n)
    base, target = build_base_and_target(source, n, layers, residue)
    return {
        edge["id"]: Q(1) + Q(index % 5, 100)
        for index, edge in enumerate(base["edges"])
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve()
    parser.add_argument("--output", type=Path, default=here.parent / "uniform_transform_certificate.json")
    args = parser.parse_args(argv)
    cases: list[dict[str, Any]] = []
    for n in range(3, 11):
        base_case = base_recovery_case(n)
        source_case = source_transform_case(n)
        case: dict[str, Any] = {"n": n, "base_recovery": base_case, "source_transform": source_case}
        if n >= 7:
            case["source_transform_asymmetric"] = source_transform_case(
                n,
                asymmetric_shared_weights(n),
                sample_name="asymmetric_shared_edges_n7_n10",
            )
        cases.append(case)
    certificate = {
        "scope": "Finite exact control for the specified layered graph transformation, n=3,...,10. Circular linkage witnesses, rational stripping, and full protected-port response checks do not prove the uniform theorem.",
        "no_new_edges": "Only prescribed source/base/target edge IDs are used; no auxiliary edge is introduced.",
        "cases": cases,
        "all_base_recovery_pass": all(case["base_recovery"]["all_checks_pass"] for case in cases),
        "all_source_transform_pass": all(case["source_transform"]["all_checks_pass"] for case in cases),
        "all_asymmetric_source_transform_pass": all(
            case["source_transform_asymmetric"]["all_checks_pass"]
            for case in cases
            if "source_transform_asymmetric" in case
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(exact_json(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"certificate: {args.output.resolve()}")
    print(f"all_base_recovery_pass: {certificate['all_base_recovery_pass']}")
    print(f"all_source_transform_pass: {certificate['all_source_transform_pass']}")
    for case in cases:
        print(
            case["n"],
            "base=" + str(case["base_recovery"]["all_checks_pass"]),
            "source=" + str(case["source_transform"]["all_checks_pass"]),
            "asym=" + str(case["source_transform_asymmetric"]["all_checks_pass"]) if "source_transform_asymmetric" in case else "asym=n/a",
            "epsilon=" + str(case["source_transform"]["selected_epsilon"]),
        )
    return 0 if certificate["all_base_recovery_pass"] and certificate["all_source_transform_pass"] and certificate["all_asymmetric_source_transform_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
