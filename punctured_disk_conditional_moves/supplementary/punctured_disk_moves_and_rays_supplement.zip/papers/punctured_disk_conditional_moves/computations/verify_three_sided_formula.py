#!/usr/bin/env python3
"""Finite exact control of the explicit n=3 three-sided formula.

The source and target graphs come from the existing layered graph generator.
Responses are computed independently by the full Laplacian Schur complement;
the fixed-minor/base-recovery construction is used only as a separate
edge-by-edge comparison.  The result is a finite control, not a proof for
the uniform theorem.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping

from verify_local_controls import graph_response
import verify_uniform_transform as transform


Q = Fraction


def formula_weights(values: Mapping[str, Fraction]) -> dict[str, Fraction]:
    """Return target edge weights with the paper's edge-label assignment."""

    a, b, d = values["a"], values["b"], values["d"]
    u, v, w = values["u"], values["v"], values["w"]
    s = b + d + w
    return {
        "target_spike_2": s + b * d / a,
        # c0_2 is the inherited edge originally carrying b; c0_1 carries d.
        "c0_2": b + a * s / d,
        "c0_1": d + a * s / b,
        "center_0": u - a * w / d,
        "center_1": v - a * w / b,
        "center_2": w * (1 + a * s / (b * d)),
    }


def source_weights(values: Mapping[str, Fraction]) -> dict[str, Fraction]:
    return {
        "c0_0": values["a"],
        "c0_2": values["b"],
        "c0_1": values["d"],
        "center_0": values["u"],
        "center_1": values["v"],
        "center_2": values["w"],
    }


def residual(left: list[list[Fraction]], right: list[list[Fraction]]) -> Fraction:
    return transform.matrix_residual(left, right)


def exact_map(left: Mapping[str, Fraction], right: Mapping[str, Fraction], keys: list[str]) -> bool:
    return all(left[key] == right[key] for key in keys)


def run_case(name: str, values: Mapping[str, Fraction]) -> dict[str, Any]:
    source, layers, residue = transform.build_source(3)
    base, target = transform.build_base_and_target(source, 3, layers, residue)
    source_w = source_weights(values)
    displayed = formula_weights(values)
    source_response = graph_response(source, source_w)
    formula_response = graph_response(target, displayed)

    # Re-run the existing fixed-minor and R_H recovery with the same source
    # conductances.  shared_weights supplies every base coefficient while the
    # explicit epsilon supplies the selected source edge c0_0=a.
    shared = {edge_id: weight for edge_id, weight in source_w.items() if edge_id != "c0_0"}
    fixed = transform.source_transform_attempt(
        3, source, base, target, layers, residue, values["a"], shared
    )
    fixed_w = fixed["target_weights"]
    target_ids = [edge["id"] for edge in target["edges"]]
    formula_defined = all(values[key] != 0 for key in ("a", "b", "d"))
    threshold = min(values["u"] * values["d"] / values["w"], values["v"] * values["b"] / values["w"])
    condition = values["a"] > 0 and values["a"] < threshold
    formula_positive = all(displayed[edge_id] > 0 for edge_id in target_ids)
    source_positive = all(weight > 0 for weight in source_w.values())
    fixed_divisions = fixed["target_parameter"]["division_checks"] + fixed["recovery"]["division_checks"]
    checks = {
        "source_graph_valid": transform.validate_graph(source)["valid"],
        "base_graph_valid": transform.validate_graph(base)["valid"],
        "target_graph_valid": transform.validate_graph(target)["valid"],
        "source_response_valid": transform.validate_response(source_response, 4)["valid"],
        "formula_target_response_valid": transform.validate_response(formula_response, 4)["valid"],
        "source_weights_match_named_parameters": exact_map(source_w, source_weights(values), list(source_w)),
        "formula_matches_fixed_F_RH_edgewise": exact_map(displayed, fixed_w, target_ids),
        "fixed_source_response_matches_independent": residual(source_response, fixed["source_response"]) == 0,
        "fixed_target_response_matches_source": fixed["residuals"]["target_source_response"] == 0,
        "formula_target_response_matches_source": residual(source_response, formula_response) == 0,
        "formula_defined": formula_defined,
        "all_fixed_divisions_nonzero": all(item["nonzero"] for item in fixed_divisions),
        "source_strictly_positive": source_positive,
        "strict_positive_iff_threshold_condition": formula_positive == condition,
    }
    return {
        "name": name,
        "parameters": dict(values),
        "s": values["b"] + values["d"] + values["w"],
        "threshold": threshold,
        "condition_a_lt_threshold": condition,
        "formula_defined": formula_defined,
        "formula_strictly_positive": formula_positive,
        "source_weights": source_w,
        "formula_target_weights": displayed,
        "fixed_target_weights": fixed_w,
        "residuals": {
            "formula_target_vs_source": residual(source_response, formula_response),
            "fixed_target_vs_source": fixed["residuals"]["target_source_response"],
        },
        "fixed_division_checks": fixed_divisions,
        "checks": checks,
        "all_checks_pass": all(checks.values()),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve()
    parser.add_argument("--output", type=Path, default=here.parent / "three_sided_formula_certificate.json")
    args = parser.parse_args(argv)
    cases = [
        run_case(
            "asymmetric_strict_positive_1",
            {"a": Q(1), "b": Q(3), "d": Q(5), "u": Q(7), "v": Q(11), "w": Q(2)},
        ),
        run_case(
            "asymmetric_strict_positive_2",
            {"a": Q(2), "b": Q(5), "d": Q(7), "u": Q(13), "v": Q(17), "w": Q(3)},
        ),
        run_case(
            "symmetric_threshold_boundary_a1",
            {"a": Q(1), "b": Q(1), "d": Q(1), "u": Q(1), "v": Q(1), "w": Q(1)},
        ),
        run_case(
            "symmetric_domain_outside_a2",
            {"a": Q(2), "b": Q(1), "d": Q(1), "u": Q(1), "v": Q(1), "w": Q(1)},
        ),
    ]
    certificate = {
        "scope": "Finite exact control of the displayed n=3 formula, its strict positivity iff condition, independent full response, and edgewise comparison with the fixed F/R_H transform. This does not replace the uniform proof.",
        "graph": "n=3 source c0_0=a, c0_2=b, c0_1=d, center_0=u, center_1=v, center_2=w; target c0_2=b_hat, c0_1=d_hat, center_0=u_hat, center_1=v_hat, center_2=w_hat, target_spike_2=h.",
        "positivity_condition": "for positive source parameters, all target weights are strictly positive iff 0<a<min(u*d/w, v*b/w)",
        "cases": cases,
        "all_cases_pass": all(case["all_checks_pass"] for case in cases),
        "strict_positive_examples": sum(case["formula_strictly_positive"] for case in cases),
        "boundary_examples": sum(not case["formula_strictly_positive"] and case["name"].endswith("boundary_a1") for case in cases),
        "defined_outside_examples": sum(case["formula_defined"] and not case["formula_strictly_positive"] for case in cases),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(transform.exact_json(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"certificate: {args.output.resolve()}")
    print(f"all_cases_pass: {certificate['all_cases_pass']}")
    for case in cases:
        print(
            case["name"],
            "formula_positive=" + str(case["formula_strictly_positive"]),
            "condition=" + str(case["condition_a_lt_threshold"]),
            "edgewise_fixed=" + str(case["checks"]["formula_matches_fixed_F_RH_edgewise"]),
            "residual=" + str(case["residuals"]["formula_target_vs_source"]),
        )
    return 0 if certificate["all_cases_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
