#!/usr/bin/env python3
"""Extract evidence from the four original conditional-move SVG diagrams.

The extracted coordinates are source geometry only.  This script deliberately
does not decide which vertices are ports or which labels define a graph.

Run with the bundled Python when available, for example::

    python inspect_source_svg.py

The default output is ``notes/source_figures/source_geometry.json`` together
with one PNG per input SVG.
"""

from __future__ import annotations

import argparse
import html
import json
import math
import re
import shutil
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
from typing import Any, Iterable


NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"
STRAIGHT_PATH = re.compile(
    rf"^\s*M\s*({NUMBER})[ ,]+({NUMBER})\s*L\s*({NUMBER})[ ,]+({NUMBER})\s*$"
)
MOVE = re.compile(rf"M\s*({NUMBER})[ ,]+({NUMBER})")
TRANSFORM = re.compile(r"([A-Za-z]+)\s*\(([^)]*)\)")
NUMBERS = re.compile(NUMBER)

# A matrix is (a, b, c, d, e, f), acting by x'=a*x+c*y+e,
# y'=b*x+d*y+f.  Transform-list multiplication follows SVG's matrix
# convention: M_total = M_total @ M_next, so the rightmost operation acts
# first on a column vector.
IDENTITY = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)


def matrix_multiply(left: tuple[float, ...], right: tuple[float, ...]) -> tuple[float, ...]:
    a, b, c, d, e, f = left
    g, h, i, j, k, l = right
    return (
        a * g + c * h,
        b * g + d * h,
        a * i + c * j,
        b * i + d * j,
        a * k + c * l + e,
        b * k + d * l + f,
    )


def apply_matrix(matrix: tuple[float, ...], point: tuple[float, float]) -> tuple[float, float]:
    a, b, c, d, e, f = matrix
    x, y = point
    return (a * x + c * y + e, b * x + d * y + f)


def parse_transform(value: str | None) -> tuple[float, ...]:
    result = IDENTITY
    if not value:
        return result
    for name, argument_text in TRANSFORM.findall(value):
        values = [float(item) for item in NUMBERS.findall(argument_text)]
        lname = name.lower()
        if lname == "matrix" and len(values) == 6:
            local = tuple(values)  # type: ignore[assignment]
        elif lname == "translate" and values:
            local = (1.0, 0.0, 0.0, 1.0, values[0], values[1] if len(values) > 1 else 0.0)
        elif lname == "scale" and values:
            sx = values[0]
            sy = values[1] if len(values) > 1 else sx
            local = (sx, 0.0, 0.0, sy, 0.0, 0.0)
        elif lname == "rotate" and values:
            angle = math.radians(values[0])
            cosine, sine = math.cos(angle), math.sin(angle)
            rotation = (cosine, sine, -sine, cosine, 0.0, 0.0)
            if len(values) >= 3:
                cx, cy = values[1], values[2]
                local = matrix_multiply(
                    matrix_multiply((1.0, 0.0, 0.0, 1.0, cx, cy), rotation),
                    (1.0, 0.0, 0.0, 1.0, -cx, -cy),
                )
            else:
                local = rotation
        elif lname in {"skewx", "skewy"} and values:
            tangent = math.tan(math.radians(values[0]))
            local = (1.0, 0.0, tangent, 1.0, 0.0, 0.0) if lname == "skewx" else (1.0, tangent, 0.0, 1.0, 0.0, 0.0)
        else:
            # Keep extraction deterministic even if a future source adds an
            # unsupported transform; the raw transform remains in the chain.
            continue
        result = matrix_multiply(result, local)
    return result


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def parse_style(value: str | None) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in (value or "").split(";"):
        if ":" in item:
            key, val = item.split(":", 1)
            result[key.strip()] = val.strip()
    return result


def effective_presentation(inherited: dict[str, str], element: ET.Element) -> dict[str, Any]:
    style = dict(inherited)
    style.update(parse_style(element.attrib.get("style")))
    for key in ("fill", "stroke", "stroke-width", "color"):
        if key in element.attrib:
            style[key] = element.attrib[key]
    return {
        "fill": style.get("fill"),
        "stroke": style.get("stroke"),
        "stroke_width": style.get("stroke-width"),
        "style_values": style,
    }


def clean_number(value: float) -> float | int:
    return int(value) if value.is_integer() else round(value, 8)


def point_json(point: tuple[float, float]) -> list[float | int]:
    return [clean_number(point[0]), clean_number(point[1])]


def transform_chain_json(chain: list[dict[str, str]]) -> list[dict[str, str]]:
    return [{"tag": item["tag"], "transform": item["transform"]} for item in chain]


def first_move(d: str) -> tuple[float, float] | None:
    match = MOVE.search(d)
    return (float(match.group(1)), float(match.group(2))) if match else None


def is_vertex_marker(d: str) -> bool:
    return bool(re.search(r"\bC\b", d) and re.search(r"\bZ\b", d) and len(MOVE.findall(d)) >= 2)


def expected_edge_labels(index: int) -> tuple[list[str], list[str]]:
    # The source uses alttext="\\ell" for the lower-case l.
    count = [6, 9, 13, 17][index]
    return list("abcdefghijklmnopqrstuvwxyz"[:count]), list("ABCDEFGHIJKLMNOPQRSTUVWXYZ"[:count])


def normalized_alttext(value: str) -> str:
    return "l" if value == r"\ell" else value


def label_record(
    element: ET.Element,
    matrix: tuple[float, ...],
    chain: list[dict[str, str]],
    presentation: dict[str, Any],
    order: int,
) -> dict[str, Any]:
    alttext = element.attrib.get("alttext", "")
    position = apply_matrix(matrix, (0.0, 0.0))
    return {
        "order": order,
        "id": element.attrib.get("id"),
        "alttext": alttext,
        "normalized_label": normalized_alttext(alttext),
        "raw_attributes": dict(element.attrib),
        "transform_chain": transform_chain_json(chain),
        "matrix": [clean_number(v) for v in matrix],
        "position_transformed": point_json(position),
        "presentation": presentation,
    }


def path_record(
    element: ET.Element,
    matrix: tuple[float, ...],
    chain: list[dict[str, str]],
    presentation: dict[str, Any],
    order: int,
) -> dict[str, Any]:
    d = element.attrib.get("d", "")
    match = STRAIGHT_PATH.match(d)
    if match:
        start = (float(match.group(1)), float(match.group(2)))
        end = (float(match.group(3)), float(match.group(4)))
        return {
            "order": order,
            "kind": "straight_edge",
            "raw_d": d,
            "raw_start": point_json(start),
            "raw_end": point_json(end),
            "transformed_start": point_json(apply_matrix(matrix, start)),
            "transformed_end": point_json(apply_matrix(matrix, end)),
            "transform_chain": transform_chain_json(chain),
            "matrix": [clean_number(v) for v in matrix],
            "presentation": presentation,
        }
    marker = is_vertex_marker(d)
    center = first_move(d)
    return {
        "order": order,
        "kind": "vertex_marker" if marker else "other_path",
        "raw_d": d,
        "raw_center": point_json(center) if center is not None else None,
        "transformed_center": point_json(apply_matrix(matrix, center)) if center is not None else None,
        "transform_chain": transform_chain_json(chain),
        "matrix": [clean_number(v) for v in matrix],
        "presentation": presentation,
    }


def collect_figure(path: Path, index: int) -> dict[str, Any]:
    root = ET.parse(path).getroot()
    paths: list[dict[str, Any]] = []
    labels: list[dict[str, Any]] = []
    order = 0

    def visit(
        element: ET.Element,
        parent_matrix: tuple[float, ...],
        parent_chain: list[dict[str, str]],
        inherited_style: dict[str, str],
    ) -> None:
        nonlocal order
        order += 1
        element_tag = local_name(element.tag)
        raw_transform = element.attrib.get("transform", "")
        matrix = matrix_multiply(parent_matrix, parse_transform(raw_transform))
        chain = parent_chain + ([{"tag": element_tag, "transform": raw_transform}] if raw_transform else [])
        presentation = effective_presentation(inherited_style, element)
        style = presentation["style_values"]
        if element_tag == "path":
            paths.append(path_record(element, matrix, chain, presentation, order))
        elif element_tag == "math" and "alttext" in element.attrib:
            labels.append(label_record(element, matrix, chain, presentation, order))
        for child in list(element):
            visit(child, matrix, chain, style)

    visit(root, IDENTITY, [], {})

    edge_paths = [item for item in paths if item["kind"] == "straight_edge"]
    marker_paths = [item for item in paths if item["kind"] == "vertex_marker"]
    ordered_labels = sorted(labels, key=lambda item: item["order"])
    for edge in edge_paths:
        start = edge["transformed_start"]
        end = edge["transformed_end"]
        midpoint = [(start[0] + end[0]) / 2.0, (start[1] + end[1]) / 2.0]
        distances = []
        for label in ordered_labels:
            point = label["position_transformed"]
            distance = math.hypot(point[0] - midpoint[0], point[1] - midpoint[1])
            distances.append((distance, label))
        distances.sort(key=lambda item: (item[0], item[1]["order"]))
        next_labels = [label for label in ordered_labels if label["order"] > edge["order"]]
        edge["transformed_midpoint"] = [clean_number(midpoint[0]), clean_number(midpoint[1])]
        edge["nearby_label_evidence"] = {
            "method": "DOM-next and transformed midpoint distance; no port interpretation",
            "next_foreign_object_math": next_labels[0] if next_labels else None,
            "nearest_by_midpoint": {
                "distance": clean_number(distances[0][0]),
                "label": distances[0][1],
            }
            if distances
            else None,
        }

    lower, upper = expected_edge_labels(index)
    actual = [label["normalized_label"] for label in ordered_labels if label["alttext"] != r"\leftrightarrow"]
    counts = Counter(actual)
    expected = lower + upper
    validation = {
        "expected_lower_labels": lower,
        "expected_upper_labels": upper,
        "counts_for_expected_labels": {label: counts[label] for label in expected},
        "all_expected_labels_exactly_once": all(counts[label] == 1 for label in expected),
        "ignored_for_label_check": [label["alttext"] for label in ordered_labels if label["alttext"] == r"\leftrightarrow"],
    }

    return {
        "source_file": path.name,
        "source_root_attributes": dict(root.attrib),
        "raw_view_box": root.attrib.get("viewBox"),
        "paths_in_document_order": paths,
        "straight_edges": edge_paths,
        "vertex_markers": marker_paths,
        "labels_in_document_order": ordered_labels,
        "label_validation": validation,
        "evidence_scope": "Raw SVG geometry and inherited presentation only; port and graph interpretations are intentionally absent.",
    }


def find_edge() -> Path | None:
    candidates = [
        Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
        Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
    ]
    return next((candidate for candidate in candidates if candidate.exists()), None)


def edge_wrapper(svg_text: str) -> str:
    # The cached extracted SVGs have no xmlns declaration and are otherwise
    # valid SVG/XML.  Embedding them in HTML with the namespace makes Edge
    # render the figure rather than display an XML tree.
    svg_text = re.sub(r"<svg\b", '<svg xmlns="http://www.w3.org/2000/svg"', svg_text, count=1)
    return (
        "<!doctype html><meta charset='utf-8'><style>"
        "html,body{margin:0;width:100%;height:100%;background:white;overflow:hidden}"
        ".page{width:100%;height:100%;display:flex;align-items:center;justify-content:center}"
        "svg{width:calc(100vw - 24px);height:auto;max-height:calc(100vh - 24px)}"
        "</style><div class='page'>" + svg_text + "</div>"
    )


def render_with_edge(svg_path: Path, png_path: Path, edge: Path) -> bool:
    with tempfile.TemporaryDirectory(prefix="conditional_svg_") as temp_dir:
        wrapper = Path(temp_dir) / "figure.html"
        wrapper.write_text(edge_wrapper(svg_path.read_text(encoding="utf-8")), encoding="utf-8")
        if png_path.exists():
            png_path.unlink()
        command = [
            str(edge),
            "--headless",
            "--disable-gpu",
            "--no-sandbox",
            "--hide-scrollbars",
            "--force-device-scale-factor=2",
            "--window-size=1300,500",
            f"--screenshot={png_path}",
            wrapper.as_uri(),
        ]
        try:
            subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60, check=False)
        except (OSError, subprocess.SubprocessError):
            return False
        deadline = time.time() + 5.0
        while time.time() < deadline:
            if png_path.exists() and png_path.stat().st_size > 1000:
                return True
            time.sleep(0.1)
    return png_path.exists() and png_path.stat().st_size > 1000


def render_with_pillow(figure: dict[str, Any], png_path: Path) -> None:
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError as exc:  # pragma: no cover - only used without Edge/Pillow
        raise RuntimeError("Neither Edge nor Pillow is available for PNG rendering") from exc
    viewbox = [float(item) for item in (figure["raw_view_box"] or "0 0 408.17 150.59").split()]
    _, _, width, height = viewbox
    scale = 3.0
    margin = 24
    image = Image.new("RGB", (round(width * scale + 2 * margin), round(height * scale + 2 * margin)), "white")
    draw = ImageDraw.Draw(image)

    def xy(point: Iterable[float]) -> tuple[float, float]:
        return (margin + (float(point[0]) - viewbox[0]) * scale, margin + (float(point[1]) - viewbox[1]) * scale)

    def color(value: str | None, fallback: str) -> str:
        return value if value and value.lower() not in {"none", "transparent"} else fallback

    for edge in figure["straight_edges"]:
        draw.line([xy(edge["transformed_start"]), xy(edge["transformed_end"])], fill=color(edge["presentation"]["stroke"], "black"), width=4)
    for marker in figure["vertex_markers"]:
        center = xy(marker["transformed_center"])
        radius = 7.5
        draw.ellipse((center[0] - radius, center[1] - radius, center[0] + radius, center[1] + radius), fill=color(marker["presentation"]["fill"], "white"), outline="black", width=2)
    font_candidates = [Path(r"C:\Windows\Fonts\arial.ttf"), Path(r"C:\Windows\Fonts\times.ttf")]
    font_path = next((path for path in font_candidates if path.exists()), None)
    font = ImageFont.truetype(str(font_path), 30) if font_path else ImageFont.load_default()
    for label in figure["labels_in_document_order"]:
        if label["alttext"] == r"\leftrightarrow":
            text = "↔"
        else:
            text = label["normalized_label"]
        draw.text(xy(label["position_transformed"]), text, fill="black", font=font, anchor="mm")
    image.save(png_path)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve()
    default_dir = here.parents[1] / "notes" / "source_figures"
    parser.add_argument("--svg-dir", type=Path, default=default_dir)
    parser.add_argument("--out-dir", type=Path, default=default_dir)
    parser.add_argument("--json", type=Path, default=None, help="JSON output path (default: out-dir/source_geometry.json)")
    args = parser.parse_args(argv)
    svg_dir = args.svg_dir.resolve()
    out_dir = args.out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = (args.json.resolve() if args.json else out_dir / "source_geometry.json")
    figures = []
    for index in range(4):
        source = svg_dir / f"conditional_{index:02d}.svg"
        if not source.exists():
            raise FileNotFoundError(source)
        figures.append(collect_figure(source, index))

    edge = find_edge()
    render_method = "edge-html-wrapper" if edge else "pillow-source-geometry"
    for index, figure in enumerate(figures):
        png_path = out_dir / f"conditional_{index:02d}.png"
        rendered = render_with_edge(svg_dir / f"conditional_{index:02d}.svg", png_path, edge) if edge else False
        if not rendered:
            render_with_pillow(figure, png_path)
            render_method = "pillow-source-geometry"
        figure["render"] = {"png": png_path.name, "method": render_method}

    payload = {
        "schema_version": 1,
        "tool": Path(__file__).name,
        "source_files": [f"conditional_{index:02d}.svg" for index in range(4)],
        "interpretation_warning": "Coordinates, path styles, and source labels are recorded as evidence. No port assignment or graph is inferred.",
        "figures": figures,
    }
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for index, figure in enumerate(figures):
        validation = figure["label_validation"]
        print(
            f"conditional_{index:02d}: edges={len(figure['straight_edges'])} "
            f"markers={len(figure['vertex_markers'])} labels={len(figure['labels_in_document_order'])} "
            f"expected-labels-exactly-once={validation['all_expected_labels_exactly_once']}"
        )
    print(f"JSON: {json_path}")
    print(f"PNGs: {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
