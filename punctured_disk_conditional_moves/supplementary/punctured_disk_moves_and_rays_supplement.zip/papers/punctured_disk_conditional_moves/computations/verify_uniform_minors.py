#!/usr/bin/env python3
"""Uniform finite checks for the layered n-cycle minor construction.

The graph encoding follows the current proof specification literally.  The
certificate records exact Fraction minors and unit-capacity linkage counts for
n=3,...,14.  It is a control calculation for the proposed uniform argument,
not a proof for all n.
"""

from __future__ import annotations

import argparse
import json
from collections import deque
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence

from verify_n7_closed_move import determinant
from verify_local_controls import graph_response


Q = Fraction


def fs(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


def exact_json(value: Any) -> Any:
    if isinstance(value, Fraction):
        return fs(value)
    if isinstance(value, dict):
        return {str(key): exact_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [exact_json(item) for item in value]
    return value


def node_name(layer: int, index: int) -> str:
    return f"w{layer}_{index}"


def b_id(index: int) -> str:
    return f"b{'m' + str(-index) if index < 0 else index}"


def build_source(n: int) -> tuple[dict[str, Any], int, int]:
    residue = n % 4
    layers = (n + 1) // 4
    ports = [f"p{i}" for i in range(n)] + ["z"]
    internal: list[str] = []
    edges: list[dict[str, str]] = []

    def outer_vertex(index: int) -> str:
        direct = residue == 3 or (residue == 0 and index >= 2 * layers)
        return f"p{index}" if direct else node_name(0, index)

    for layer in range(layers):
        for index in range(n):
            vertex = outer_vertex(index) if layer == 0 else node_name(layer, index)
            if vertex not in ports and vertex not in internal:
                internal.append(vertex)
    for layer in range(layers):
        for index in range(n):
            u = outer_vertex(index) if layer == 0 else node_name(layer, index)
            v = outer_vertex((index + 1) % n) if layer == 0 else node_name(layer, (index + 1) % n)
            edges.append({"id": f"c{layer}_{index}", "u": u, "v": v})
    for layer in range(layers - 1):
        for index in range(n):
            edges.append({"id": f"rad{layer}_{index}", "u": outer_vertex(index) if layer == 0 else node_name(layer, index), "v": node_name(layer + 1, index)})
    for index in range(n):
        # For L=1 the outer layer is also the innermost layer.  Reuse
        # outer_vertex so direct ports and spiked outer vertices are not
        # replaced by undeclared w0_i placeholders.
        inner_vertex = outer_vertex(index) if layers == 1 else node_name(layers - 1, index)
        edges.append({"id": f"center_{index}", "u": inner_vertex, "v": "z"})

    spike_indices: list[int]
    if residue == 3:
        spike_indices = []
    elif residue == 0:
        spike_indices = list(range(2 * layers))
    else:
        spike_indices = list(range(n))
    for index in spike_indices:
        edges.append({"id": f"spike_{index}", "u": f"p{index}", "v": node_name(0, index)})

    if residue == 2:
        for index in range(-layers, layers + 1):
            edges.append({"id": b_id(index), "u": f"p{index % n}", "v": f"p{(index + 1) % n}"})

    graph = {"ports": ports, "internal": internal, "edges": edges}
    return graph, layers, residue


def validate_graph(graph: Mapping[str, Any]) -> dict[str, Any]:
    """Check the declared vertex sets and edge identifiers before elimination."""

    ports = list(graph["ports"])
    internal = list(graph.get("internal", []))
    edge_ids = [edge["id"] for edge in graph["edges"]]
    declared = set(ports) | set(internal)
    unknown_endpoints = sorted(
        {endpoint for edge in graph["edges"] for endpoint in (edge["u"], edge["v"]) if endpoint not in declared}
    )
    checks = {
        "ports_unique": len(ports) == len(set(ports)),
        "internal_unique": len(internal) == len(set(internal)),
        "ports_internal_disjoint": set(ports).isdisjoint(internal),
        "edge_ids_unique": len(edge_ids) == len(set(edge_ids)),
        "edge_endpoints_declared": not unknown_endpoints,
    }
    return {
        "valid": all(checks.values()),
        "checks": checks,
        "unknown_endpoints": unknown_endpoints,
    }


def replace_endpoint(edge: Mapping[str, str], old: str, new: str) -> dict[str, str]:
    result = dict(edge)
    if result["u"] == old:
        result["u"] = new
    if result["v"] == old:
        result["v"] = new
    return result


def build_base_and_target(source: Mapping[str, Any], n: int, layers: int, residue: int) -> tuple[dict[str, Any], dict[str, Any]]:
    base_edges = [dict(edge) for edge in source["edges"]]
    base_internal = list(source["internal"])
    if residue in (3, 2):
        delete_id = "c0_0" if residue == 3 else "b0"
        base_edges = [edge for edge in base_edges if edge["id"] != delete_id]
    else:
        base_edges = [edge for edge in base_edges if edge["id"] != "spike_0"]
        old = node_name(0, 0)
        base_edges = [replace_endpoint(edge, old, "p0") for edge in base_edges]
        base_internal = [node for node in base_internal if node != old]
    base = {"ports": list(source["ports"]), "internal": base_internal, "edges": base_edges}

    target_edges = [dict(edge) for edge in base_edges]
    target_internal = list(base_internal)
    t = 2 * layers
    if residue in (3, 0):
        target_edges = [replace_endpoint(edge, f"p{t}", f"v{t}") for edge in target_edges]
        target_internal.append(f"v{t}")
        target_edges.append({"id": f"target_spike_{t}", "u": f"p{t}", "v": f"v{t}"})
    elif residue == 1:
        target_edges.append({"id": f"target_edge_{t}_{t + 1}", "u": f"p{t}", "v": f"p{(t + 1) % n}"})
    else:
        target_edges.append({"id": f"target_edge_{t + 1}_{t + 2}", "u": f"p{(t + 1) % n}", "v": f"p{(t + 2) % n}"})
    target = {"ports": list(source["ports"]), "internal": target_internal, "edges": target_edges}
    return base, target


def minor_indices(n: int, layers: int, residue: int) -> tuple[list[int], list[int], int]:
    if residue == 3:
        k = 2 * layers - 1
        P = [0] + [(n - j) % n for j in range(1, k)]
        Q = list(range(1, k + 1))
    elif residue == 0:
        k = 2 * layers - 1
        P = list(range(1, k + 1))
        Q = [(n - j) % n for j in range(1, k + 1)]
    elif residue == 1:
        k = 2 * layers
        P = list(range(1, k + 1))
        Q = [(n - j) % n for j in range(1, k + 1)]
    else:
        k = 2 * layers + 1
        P = [0] + [(n - j) % n for j in range(1, k)]
        Q = list(range(1, k + 1))
    return P, Q, k


def response_minor(response: Sequence[Sequence[Fraction]], P: Sequence[int], Q_indices: Sequence[int]) -> Fraction:
    return determinant([[response[row][col] for col in Q_indices] for row in P])


def all_one(graph: Mapping[str, Any]) -> dict[str, Fraction]:
    return {edge["id"]: Q(1) for edge in graph["edges"]}


def feature_update_matrix(size: int, u: int, v: int) -> list[list[Fraction]]:
    matrix = [[Q(0) for _ in range(size)] for _ in range(size)]
    matrix[u][u] += 1
    matrix[v][v] += 1
    matrix[u][v] -= 1
    matrix[v][u] -= 1
    return matrix


def matrix_add(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    return [[left[row][col] + right[row][col] for col in range(len(left[row]))] for row in range(len(left))]


def validate_response(response: Sequence[Sequence[Fraction]], expected_size: int) -> dict[str, Any]:
    """Check that a response has the full protected-port shape and Laplacian identities."""

    square = len(response) == expected_size and all(len(row) == expected_size for row in response)
    symmetric = square and all(response[row][col] == response[col][row] for row in range(expected_size) for col in range(expected_size))
    row_sum_zero = square and all(sum(response[row][col] for col in range(expected_size)) == 0 for row in range(expected_size))
    checks = {
        "square_expected_size": square,
        "symmetric": symmetric,
        "row_sum_zero": row_sum_zero,
    }
    return {"valid": all(checks.values()), "checks": checks}


def sign(value: Fraction) -> int:
    return 1 if value > 0 else -1 if value < 0 else 0


class Dinic:
    def __init__(self) -> None:
        self.graph: dict[str, list[list[Any]]] = {}

    def add_edge(self, u: str, v: str, capacity: int) -> None:
        self.graph.setdefault(u, [])
        self.graph.setdefault(v, [])
        forward = [v, capacity, len(self.graph[v])]
        backward = [u, 0, len(self.graph[u])]
        self.graph[u].append(forward)
        self.graph[v].append(backward)

    def max_flow(self, source: str, sink: str) -> int:
        result = 0
        while True:
            level = {source: 0}
            queue = deque([source])
            while queue:
                u = queue.popleft()
                for v, capacity, _ in self.graph[u]:
                    if capacity and v not in level:
                        level[v] = level[u] + 1
                        queue.append(v)
            if sink not in level:
                return result
            pointers = {node: 0 for node in self.graph}

            def send(u: str, pushed: int) -> int:
                if u == sink:
                    return pushed
                while pointers[u] < len(self.graph[u]):
                    edge = self.graph[u][pointers[u]]
                    v, capacity, reverse = edge
                    if capacity and level.get(v) == level[u] + 1:
                        amount = send(v, min(pushed, capacity))
                        if amount:
                            edge[1] -= amount
                            self.graph[v][reverse][1] += amount
                            return amount
                    pointers[u] += 1
                return 0

            while True:
                pushed = send(source, 10**6)
                if not pushed:
                    break
                result += pushed


def linkage_count(graph: Mapping[str, Any], P: Sequence[int], Q_indices: Sequence[int]) -> int:
    ports = list(graph["ports"])
    P_nodes = {ports[index] for index in P}
    Q_nodes = {ports[index] for index in Q_indices}
    other_ports = set(ports) - P_nodes - Q_nodes
    flow = Dinic()
    inf = max(len(P), len(Q_indices)) + 1

    def inside(node: str) -> str:
        return f"{node}:in"

    def outside(node: str) -> str:
        return f"{node}:out"

    allowed_nodes = [node for node in graph["ports"] + graph["internal"] if node not in other_ports]
    for node in allowed_nodes:
        flow.add_edge(inside(node), outside(node), 1)
    source = "__source__"
    sink = "__sink__"
    for node in P_nodes:
        flow.add_edge(source, inside(node), 1)
    for node in Q_nodes:
        flow.add_edge(outside(node), sink, 1)
    for edge in graph["edges"]:
        u, v = edge["u"], edge["v"]
        if u in other_ports or v in other_ports:
            continue
        # P are sources only and Q are sinks only; other ports never enter.
        if u not in Q_nodes and v not in P_nodes:
            flow.add_edge(outside(u), inside(v), inf)
        if v not in Q_nodes and u not in P_nodes:
            flow.add_edge(outside(v), inside(u), inf)
    return flow.max_flow(source, sink)


def feature_diagnostic(base_response: Sequence[Sequence[Fraction]], n: int, layers: int, residue: int, P: Sequence[int], Q_indices: Sequence[int], base_F: Fraction) -> dict[str, Any]:
    t = 2 * layers
    if residue in (1, 2):
        u, v = (t, (t + 1) % n) if residue == 1 else ((t + 1) % n, (t + 2) % n)
        update = feature_update_matrix(n + 1, u, v)
        value = response_minor(matrix_add(base_response, update), P, Q_indices) - base_F
        kind = "boundary_edge"
    else:
        column = [[base_response[row][t]] for row in range(n + 1)]
        row = [base_response[t][col] for col in range(n + 1)]
        outer = [[column[i][0] * row[j] for j in range(n + 1)] for i in range(n + 1)]
        value = response_minor(matrix_add(base_response, outer), P, Q_indices) - base_F
        kind = "spike"
    k = 2 * layers - 1 if residue in (3, 0) else 2 * layers if residue == 1 else 2 * layers + 1
    expected_feature_sign = (-1) ** (k + 1) if kind == "spike" else (-1) ** k
    return {"kind": kind, "feature_value": value, "feature_nonzero": value != 0, "feature_sign": sign(value), "expected_sign": expected_feature_sign, "feature_sign_matches_expected": sign(value) == expected_feature_sign}


def deformation_diagnostic(base: Mapping[str, Any], target: Mapping[str, Any], n: int, layers: int, residue: int, P: Sequence[int], Q_indices: Sequence[int]) -> dict[str, Any]:
    base_weights = all_one(base)
    deformed_weights = all_one(target)
    t = 2 * layers
    if residue in (1, 2):
        epsilon = Q(1, 100)
        edge_id = f"target_edge_{t}_{t + 1}" if residue == 1 else f"target_edge_{t + 1}_{t + 2}"
        deformed_weights[edge_id] = epsilon
        parameter = "boundary_edge_epsilon_1/100"
    else:
        epsilon = Q(100)
        edge_id = f"target_spike_{t}"
        deformed_weights[edge_id] = epsilon
        parameter = "spike_100"
    base_response = graph_response(base, base_weights)
    deformed_response = graph_response(target, deformed_weights)
    target_feature = response_minor(deformed_response, P, Q_indices) - response_minor(base_response, P, Q_indices)
    stripped_distance = max(
        abs(deformed_response[row][col] - base_response[row][col])
        for row in range(n + 1)
        for col in range(n + 1)
    )
    k = 2 * layers - 1 if residue in (3, 0) else 2 * layers if residue == 1 else 2 * layers + 1
    expected_sign = (-1) ** k
    return {
        "parameter": parameter,
        "edge_id": edge_id,
        "target_feature_conductance": epsilon,
        "target_feature_conductance_positive": epsilon > 0,
        "minor_difference": target_feature,
        "minor_difference_sign": sign(target_feature),
        "expected_minor_difference_sign": expected_sign,
        "matches_expected_sign": sign(target_feature) == expected_sign,
        "stripped_response_max_distance_to_base": stripped_distance,
        "note": "A finite target deformation diagnostic; the conductance positivity and minor difference are recorded separately.",
    }


def source_extraction_diagnostic(source: Mapping[str, Any], base: Mapping[str, Any], n: int, layers: int, residue: int, P: Sequence[int], Q_indices: Sequence[int]) -> dict[str, Any]:
    """Perturb the source feature and extract the proposed target parameter."""

    source_weights = all_one(source)
    t = 2 * layers
    if residue in (3, 2):
        epsilon = Q(1, 100)
        source_edge_id = "c0_0" if residue == 3 else "b0"
        source_weights[source_edge_id] = epsilon
        source_feature_kind = "boundary_edge"
        source_parameter = "source_boundary_edge_epsilon_1/100"
    else:
        epsilon = Q(100)
        source_edge_id = "spike_0"
        source_weights[source_edge_id] = epsilon
        source_feature_kind = "spike"
        source_parameter = "source_spike_100"

    base_response = graph_response(base, all_one(base))
    source_response = graph_response(source, source_weights)
    F = response_minor(source_response, P, Q_indices)
    F_base = response_minor(base_response, P, Q_indices)
    source_minor_difference = F - F_base
    stripped_distance = max(
        abs(source_response[row][col] - base_response[row][col])
        for row in range(n + 1)
        for col in range(n + 1)
    )
    if residue in (1, 2):
        u, v = (t, (t + 1) % n) if residue == 1 else ((t + 1) % n, (t + 2) % n)
        update = feature_update_matrix(n + 1, u, v)
        D = response_minor(matrix_add(source_response, update), P, Q_indices) - F
        target_parameter = D / F
        extraction_formula = "D/F"
        extraction_kind = "boundary_edge"
        extraction_data = {"D": D, "F": F, "D_over_F": target_parameter, "target_parameter": target_parameter}
    else:
        column = [[source_response[row][t]] for row in range(n + 1)]
        row = [source_response[t][col] for col in range(n + 1)]
        outer = [[column[i][0] * row[j] for j in range(n + 1)] for i in range(n + 1)]
        B = response_minor(matrix_add(source_response, outer), P, Q_indices) - F
        B_over_F = B / F
        target_parameter = source_response[t][t] - B_over_F
        extraction_formula = "M_tt-B/F"
        extraction_kind = "spike"
        extraction_data = {
            "B": B,
            "F": F,
            "B_over_F": B_over_F,
            "M_tt": source_response[t][t],
            "target_parameter": target_parameter,
        }
    k = 2 * layers - 1 if residue in (3, 0) else 2 * layers if residue == 1 else 2 * layers + 1
    expected_source_sign = (-1) ** k
    return {
        "source_parameter": source_parameter,
        "source_feature_kind": source_feature_kind,
        "source_edge_id": source_edge_id,
        "source_feature_conductance": epsilon,
        "source_feature_conductance_positive": epsilon > 0,
        "source_minor_difference": source_minor_difference,
        "source_minor_difference_sign": sign(source_minor_difference),
        "source_expected_minor_difference_sign": expected_source_sign,
        "source_minor_matches_expected_sign": sign(source_minor_difference) == expected_source_sign,
        "target_feature_kind": extraction_kind,
        "target_parameter_formula": extraction_formula,
        "target_parameter_positive": target_parameter > 0,
        "target_parameter_data": extraction_data,
        "stripped_response_max_distance_to_base": stripped_distance,
        "note": "Finite source perturbation used only as a control diagnostic; positivity of the extracted target parameter is not a uniform proof.",
    }


def check_n(n: int) -> dict[str, Any]:
    source, layers, residue = build_source(n)
    base, target = build_base_and_target(source, n, layers, residue)
    P, Q_indices, k = minor_indices(n, layers, residue)
    graph_validation = {
        "source": validate_graph(source),
        "base": validate_graph(base),
        "target": validate_graph(target),
    }
    if not all(item["valid"] for item in graph_validation.values()):
        raise ValueError(f"invalid graph encoding for n={n}: {graph_validation}")
    source_weights = all_one(source)
    base_weights = all_one(base)
    target_weights = all_one(target)
    source_response = graph_response(source, source_weights)
    base_response = graph_response(base, base_weights)
    target_response = graph_response(target, target_weights)
    response_validation = {
        "source": validate_response(source_response, n + 1),
        "base": validate_response(base_response, n + 1),
        "target": validate_response(target_response, n + 1),
    }
    F_source = response_minor(source_response, P, Q_indices)
    F_base = response_minor(base_response, P, Q_indices)
    F_target = response_minor(target_response, P, Q_indices)
    expected_sign = (-1) ** k
    source_linkage = linkage_count(source, P, Q_indices)
    base_linkage = linkage_count(base, P, Q_indices)
    target_linkage = linkage_count(target, P, Q_indices)
    feature = feature_diagnostic(base_response, n, layers, residue, P, Q_indices, F_base)
    deformation = deformation_diagnostic(base, target, n, layers, residue, P, Q_indices)
    source_extraction = source_extraction_diagnostic(source, base, n, layers, residue, P, Q_indices)
    exact_checks = {
        "source_graph_valid": graph_validation["source"]["valid"],
        "base_graph_valid": graph_validation["base"]["valid"],
        "target_graph_valid": graph_validation["target"]["valid"],
        "source_response_valid": response_validation["source"]["valid"],
        "base_response_valid": response_validation["base"]["valid"],
        "target_response_valid": response_validation["target"]["valid"],
        "source_edge_count": len(source["edges"]) == n * (n + 1) // 2,
        "base_edge_count": len(base["edges"]) == n * (n + 1) // 2 - 1,
        "target_edge_count": len(target["edges"]) == n * (n + 1) // 2,
        "base_F_zero": F_base == 0,
        "source_F_nonzero": F_source != 0,
        "target_F_nonzero": F_target != 0,
        "source_F_expected_sign": sign(F_source) == expected_sign,
        "target_F_expected_sign": sign(F_target) == expected_sign,
        "base_linkage_k_minus_1": base_linkage == k - 1,
        "source_linkage_k": source_linkage == k,
        "target_linkage_k": target_linkage == k,
        "feature_nonzero": feature["feature_nonzero"],
        "feature_sign_expected": feature["feature_sign_matches_expected"],
    }
    diagnostic_checks = {
        "target_deformation_matches_expected_sign": deformation["matches_expected_sign"],
        "source_minor_matches_expected_sign": source_extraction["source_minor_matches_expected_sign"],
        "extracted_target_parameter_positive": source_extraction["target_parameter_positive"],
    }
    return {
        "n": n,
        "residue": residue,
        "layers_L": layers,
        "ports": source["ports"],
        "P": P,
        "Q": Q_indices,
        "k": k,
        "source_edge_count": len(source["edges"]),
        "base_edge_count": len(base["edges"]),
        "target_edge_count": len(target["edges"]),
        "source_edges": source["edges"],
        "base_edges": base["edges"],
        "target_edges": target["edges"],
        "graph_validation": graph_validation,
        "response_validation": response_validation,
        "minors": {"F_base": F_base, "F_source": F_source, "F_target": F_target, "expected_sign": expected_sign},
        "linkage": {"base": base_linkage, "source": source_linkage, "target": target_linkage, "expected": {"base": k - 1, "source": k, "target": k}},
        "feature_diagnostic": feature,
        "deformation_diagnostic": deformation,
        "source_extraction_diagnostic": source_extraction,
        "checks": exact_checks,
        "all_exact_checks_pass": all(exact_checks.values()),
        "diagnostic_checks": diagnostic_checks,
        "all_diagnostic_checks_pass": all(diagnostic_checks.values()),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve()
    parser.add_argument("--output", type=Path, default=here.parent / "uniform_minors_certificate.json")
    args = parser.parse_args(argv)
    cases = [check_n(n) for n in range(3, 15)]
    certificate = {
        "scope": "Finite exact control check for the specified layered graph/minor construction, n=3,...,14; source perturbation and extracted-parameter fields are diagnostics and do not prove the uniform theorem.",
        "graph_encoding": "L=floor((n+1)/4) concentric n-cycles, radial edges, central z-star, residue-dependent spikes and boundary edges exactly as specified.",
        "cases": cases,
        "all_cases_pass": all(case["all_exact_checks_pass"] for case in cases),
        "all_diagnostic_checks_pass": all(case["all_diagnostic_checks_pass"] for case in cases),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(exact_json(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"certificate: {args.output.resolve()}")
    print(f"all_cases_pass: {certificate['all_cases_pass']}")
    for case in cases:
        print(case["n"], case["residue"], case["checks"])
    return 0 if certificate["all_cases_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
