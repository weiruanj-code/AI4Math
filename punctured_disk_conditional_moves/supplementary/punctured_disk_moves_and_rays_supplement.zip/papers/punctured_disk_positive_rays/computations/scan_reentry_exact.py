#!/usr/bin/env python3
"""Bounded exact scan for positive--negative--positive ray patterns.

The scan uses the prescribed source/base/target graphs for n=3,...,10,
three deterministic positive rational inherited assignments, and an exact
epsilon grid.  It records recovery-division failures separately from valid
negative target conductances.  A positive-negative-positive pattern on this
finite grid would be a counterexample candidate, not a general theorem.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
import time
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence

HERE = Path(__file__).resolve().parent
PREDECESSOR = HERE.parents[1] / "punctured_disk_conditional_moves" / "computations"
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
if str(PREDECESSOR) not in sys.path:
    sys.path.insert(0, str(PREDECESSOR))

from probe_n11_numeric_ray import cache_witnesses, recover_cached  # noqa: E402
from probe_n7_symbolic_ray import make_baseline  # noqa: E402
from verify_local_controls import graph_response, solve  # noqa: E402
from verify_uniform_minors import (  # noqa: E402
    Q,
    build_base_and_target,
    build_source,
    exact_json,
    matrix_add,
    response_minor,
    validate_graph,
    validate_response,
)
from verify_uniform_transform import (  # noqa: E402
    edge_by_id,
    extract_target_parameter,
    matrix_residual,
    source_weights_for_epsilon,
)


EPSILONS = [
    Q(1, 1_000_000),
    Q(1, 10_000),
    Q(1, 100),
    Q(1, 2),
    Q(2),
    Q(100),
    Q(10_000),
    Q(1_000_000),
]


def fraction_string(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


def baseline_variants(base: Mapping[str, Any], n: int) -> list[dict[str, Fraction]]:
    """Return three fixed, asymmetric, positive rational assignments."""

    first = make_baseline(base)
    rng = random.Random(2_026_101_600 + n)
    second = {
        edge["id"]: Fraction(11 + rng.randrange(0, 23), 13)
        for edge in base["edges"]
    }
    third = {
        edge["id"]: Fraction(3 + rng.randrange(0, 19), 5 + (index % 4))
        for index, edge in enumerate(base["edges"])
    }
    return [first, second, third]


def weight_sign_class(weights: Mapping[str, Fraction]) -> tuple[str, str, Fraction]:
    minimum_id, minimum = min(weights.items(), key=lambda item: item[1])
    if minimum > 0:
        return "positive", minimum_id, minimum
    if minimum == 0:
        return "zero", minimum_id, minimum
    return "negative", minimum_id, minimum


def record_error(epsilon: Fraction, source_feature_id: str, exc: Exception) -> dict[str, Any]:
    return {
        "epsilon": epsilon,
        "source_feature_id": source_feature_id,
        "classification": "division_failure",
        "error_type": type(exc).__name__,
        "error": str(exc),
        "algebraic_checks_pass": False,
        "exact_response_verified": False,
    }


def evaluate_sample(
    n: int,
    source: Mapping[str, Any],
    base: Mapping[str, Any],
    target: Mapping[str, Any],
    layers: int,
    residue: int,
    epsilon: Fraction,
    baseline: Mapping[str, Fraction],
    operations: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    source_weights, source_feature_id, source_feature_weight = source_weights_for_epsilon(
        source, residue, epsilon, baseline
    )
    try:
        source_response = graph_response(source, source_weights)
        parameter = extract_target_parameter(target, base, source_response, n, layers, residue)
        recovery = recover_cached(base, parameter["stripped_response"], operations)
        target_weights = {
            edge["id"]: recovery["weights"][edge["id"]]
            for edge in base["edges"]
        }
        target_feature_id = parameter["descriptor"]["edge_id"]
        target_weights[target_feature_id] = parameter["parameter"]
        target_response = graph_response(target, target_weights)
        recovered_response = graph_response(base, recovery["weights"])
        all_divisions = parameter["division_checks"] + recovery["divisions"]
        checks = {
            "source_response_valid": validate_response(source_response, n + 1)["valid"],
            "target_response_valid": validate_response(target_response, n + 1)["valid"],
            "recovered_response_valid": validate_response(recovered_response, n + 1)["valid"],
            "target_graph_valid": validate_graph(target)["valid"],
            "source_weights_positive": all(value > 0 for value in source_weights.values()),
            "all_divisions_nonzero": all(item["nonzero"] for item in all_divisions),
            "base_response_exact": matrix_residual(
                parameter["stripped_response"], recovered_response
            ) == 0,
            "target_source_response_exact": matrix_residual(
                source_response, target_response
            ) == 0,
        }
        algebraic_checks_pass = all(checks.values())
        classification, minimum_id, minimum = weight_sign_class(target_weights)
        return {
            "epsilon": epsilon,
            "source_feature_id": source_feature_id,
            "source_feature_weight": source_feature_weight,
            "target_feature_id": target_feature_id,
            "target_parameter": parameter["parameter"],
            "classification": classification if algebraic_checks_pass else "algebraic_failure",
            "minimum_target_edge": minimum_id,
            "minimum_target_weight": minimum,
            "target_weights": target_weights,
            "center_weights": {
                edge_id: value
                for edge_id, value in target_weights.items()
                if edge_id.startswith("center_")
            },
            "checks": checks,
            "algebraic_checks_pass": algebraic_checks_pass,
            "exact_response_verified": (
                checks["base_response_exact"]
                and checks["target_source_response_exact"]
            ),
            "division_count": len(all_divisions),
        }
    except Exception as exc:  # preserve finite obstructions as a separate class
        return record_error(epsilon, source_feature_id, exc)


def mobius_fit(points: Sequence[tuple[Fraction, Fraction]]) -> dict[str, Any]:
    """Fit y=(a+b*x)/(1+c*x) through three exact points."""

    matrix = [[Q(1), x, -x * y] for x, y in points[:3]]
    solution = solve(matrix, [[y] for _, y in points[:3]])
    return {"a": solution[0][0], "b": solution[1][0], "c": solution[2][0]}


def mobius_value(fit: Mapping[str, Fraction], x: Fraction) -> Fraction:
    denominator = Q(1) + fit["c"] * x
    if denominator == 0:
        raise ZeroDivisionError("Möbius diagnostic denominator vanishes")
    return (fit["a"] + fit["b"] * x) / denominator


def center_mobius_diagnostics(records: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    valid = [
        record for record in records
        if record.get("algebraic_checks_pass") and record.get("center_weights")
    ]
    if len(valid) < 3:
        return {"status": "fewer_than_three_valid_samples", "valid_sample_count": len(valid)}
    edge_ids = sorted(valid[0]["center_weights"])
    fits: dict[str, Any] = {}
    for edge_id in edge_ids:
        points = [
            (record["epsilon"], record["center_weights"][edge_id])
            for record in valid
        ]
        try:
            fit = mobius_fit(points)
            residuals = []
            for x, y in points[3:]:
                predicted = mobius_value(fit, x)
                residuals.append({"epsilon": x, "actual": y, "predicted": predicted, "residual": y - predicted})
            fits[edge_id] = {
                "fit_from_first_three": fit,
                "remaining_sample_count": len(residuals),
                "remaining_exact": all(item["residual"] == 0 for item in residuals),
                "violations": [item for item in residuals if item["residual"] != 0],
            }
        except Exception as exc:
            fits[edge_id] = {"status": "fit_failure", "error_type": type(exc).__name__, "error": str(exc)}
    return {
        "status": "computed",
        "valid_sample_count": len(valid),
        "all_center_fits_exact_on_remaining_samples": all(
            item.get("remaining_exact", False) for item in fits.values()
        ),
        "fits": fits,
    }


def pattern_indices(records: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    classes = [record.get("classification") for record in records]
    patterns: list[dict[str, Any]] = []
    for i in range(len(records)):
        if classes[i] != "positive":
            continue
        for j in range(i + 1, len(records)):
            if classes[j] != "negative":
                continue
            for k in range(j + 1, len(records)):
                if classes[k] == "positive":
                    patterns.append({
                        "positive_before": i,
                        "negative_middle": j,
                        "positive_after": k,
                        "epsilons": [records[i]["epsilon"], records[j]["epsilon"], records[k]["epsilon"]],
                    })
    return patterns


def negative_center_summary(records: Sequence[Mapping[str, Any]]) -> dict[str, list[Any]]:
    """Collect center coordinates that are negative at valid negative samples."""

    result: dict[str, list[Any]] = {}
    for record in records:
        if record.get("classification") != "negative":
            continue
        for edge_id, value in record.get("center_weights", {}).items():
            if value < 0:
                result.setdefault(edge_id, []).append(record["epsilon"])
    return result


def compact_record(record: Mapping[str, Any]) -> dict[str, Any]:
    keep = {
        key: record[key]
        for key in (
            "epsilon", "source_feature_id", "source_feature_weight", "target_feature_id",
            "target_parameter", "classification", "minimum_target_edge", "minimum_target_weight",
            "center_weights", "checks", "algebraic_checks_pass", "exact_response_verified",
            "division_count", "error_type", "error",
        )
        if key in record
    }
    if "target_weights" in record and record.get("classification") in {"negative", "zero"}:
        keep["target_weights"] = record["target_weights"]
    return keep


def write_checkpoint(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(exact_json(payload), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def run(output: Path, checkpoint: Path, time_limit: float) -> dict[str, Any]:
    started = time.monotonic()
    cases: list[dict[str, Any]] = []
    stopped_due_to_time = False
    write_checkpoint(checkpoint, {"status": "in_progress", "stage": "topology_scan_started", "cases": []})
    for n in range(3, 11):
        if time.monotonic() - started >= time_limit:
            stopped_due_to_time = True
            break
        source, layers, residue = build_source(n)
        base, target = build_base_and_target(source, n, layers, residue)
        operations = cache_witnesses(base, n, layers, residue)
        top_case: dict[str, Any] = {
            "n": n,
            "layers_L": layers,
            "residue": residue,
            "source_feature_kind": "boundary_edge" if residue in (2, 3) else "spike",
            "graph_counts": {
                "source_edges": len(source["edges"]),
                "base_edges": len(base["edges"]),
                "target_edges": len(target["edges"]),
                "cached_recovery_operations": len(operations),
            },
            "baseline_cases": [],
        }
        for baseline_index, baseline in enumerate(baseline_variants(base, n)):
            if time.monotonic() - started >= time_limit:
                stopped_due_to_time = True
                break
            records: list[dict[str, Any]] = []
            for epsilon in EPSILONS:
                if time.monotonic() - started >= time_limit:
                    stopped_due_to_time = True
                    break
                records.append(
                    evaluate_sample(
                        n, source, base, target, layers, residue,
                        epsilon, baseline, operations,
                    )
                )
            compact_records = [compact_record(record) for record in records]
            baseline_case = {
                "baseline_index": baseline_index,
                "baseline_inherited_weights": baseline,
                "epsilon_grid": EPSILONS,
                "records": compact_records,
                "positive_negative_positive_patterns": pattern_indices(records),
                "negative_center_samples": negative_center_summary(records),
                "center_mobius_diagnostics": center_mobius_diagnostics(records),
                "valid_negative_sample_count": sum(record.get("classification") == "negative" for record in records),
                "division_failure_count": sum(record.get("classification") == "division_failure" for record in records),
            }
            top_case["baseline_cases"].append(baseline_case)
            write_checkpoint(checkpoint, {
                "status": "in_progress",
                "stage": "sample_scan",
                "elapsed_seconds": time.monotonic() - started,
                "cases": cases + [top_case],
            })
        cases.append(top_case)
        if stopped_due_to_time:
            break
    candidate_cases = [
        {
            "n": case["n"],
            "residue": case["residue"],
            "baseline_index": baseline["baseline_index"],
            "patterns": baseline["positive_negative_positive_patterns"],
        }
        for case in cases
        for baseline in case["baseline_cases"]
        if baseline["positive_negative_positive_patterns"]
    ]
    negative_centers_by_residue: dict[int, set[str]] = {}
    for case in cases:
        for baseline in case["baseline_cases"]:
            for edge_id in baseline["negative_center_samples"]:
                negative_centers_by_residue.setdefault(case["residue"], set()).add(edge_id)
    certificate = {
        "scope": "Bounded exact Fraction scan for n=3,...,10, all four residue source types, three deterministic positive rational baselines, and a finite epsilon grid.",
        "diagnostic_status": "Finite scan only; no general no-reentry claim.",
        "epsilon_grid": EPSILONS,
        "baseline_count_per_n": 3,
        "cases": cases,
        "candidate_reentry_cases": candidate_cases,
        "candidate_count": len(candidate_cases),
        "negative_center_ids_by_residue": {
            residue: sorted(edge_ids)
            for residue, edge_ids in sorted(negative_centers_by_residue.items())
        },
        "stopped_due_to_time": stopped_due_to_time,
        "elapsed_seconds": time.monotonic() - started,
        "all_four_residue_types_covered": {residue: any(case["residue"] == residue for case in cases) for residue in range(4)},
    }
    write_checkpoint(checkpoint, {"status": "completed" if not stopped_due_to_time else "partial", "stage": "certificate_ready", "summary": {"candidate_count": len(candidate_cases), "elapsed_seconds": certificate["elapsed_seconds"]}})
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(exact_json(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return certificate


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "reentry_exact_scan_certificate.json")
    parser.add_argument("--checkpoint", type=Path, default=HERE / "reentry_exact_scan_checkpoint.json")
    parser.add_argument("--time-limit", type=float, default=140.0)
    args = parser.parse_args(argv)
    certificate = run(args.output, args.checkpoint, args.time_limit)
    print(f"certificate: {args.output.resolve()}")
    print(f"n_cases: {len(certificate['cases'])}")
    print(f"candidate_count: {certificate['candidate_count']}")
    print(f"all_four_residue_types_covered: {certificate['all_four_residue_types_covered']}")
    print(f"elapsed_seconds: {certificate['elapsed_seconds']:.3f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
