#!/usr/bin/env python3
"""Bounded exact n=11 numerical-ray diagnostic.

Topology witnesses are searched once and reused at four positive rational
epsilon values.  Centre conductances are fitted to
(a+b*epsilon)/(1+c*epsilon) from the first three samples and tested at the
fourth.  The fit is diagnostic only.
"""

from __future__ import annotations

import argparse
import json
import sys
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence

HERE = Path(__file__).resolve().parent
PREDECESSOR = HERE.parents[1] / "punctured_disk_conditional_moves" / "computations"
if str(PREDECESSOR) not in sys.path:
    sys.path.insert(0, str(PREDECESSOR))

from probe_n7_symbolic_ray import make_baseline  # noqa: E402
from verify_local_controls import graph_response, solve  # noqa: E402
from verify_uniform_minors import (  # noqa: E402
    Q, build_base_and_target, build_source, matrix_add, response_minor,
    validate_graph, validate_response,
)
from verify_uniform_transform import (  # noqa: E402
    clone_graph, contract_port_edge, edge_by_id, extract_target_parameter,
    find_witness, matrix_scale, matrix_sub, port_edge_matrix,
    rank_one_from_response, remove_edge,
)

N = 11


def fs(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


def exact_json(value: Any) -> Any:
    if isinstance(value, Fraction):
        return fs(value)
    if isinstance(value, dict):
        return {str(key): exact_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [exact_json(item) for item in value]
    return value


def matrix_residual(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> Fraction:
    if len(left) != len(right) or any(len(a) != len(b) for a, b in zip(left, right)):
        return Q(1)
    return max(
        (abs(left[i][j] - right[i][j])
         for i in range(len(left)) for j in range(len(left[i]))),
        default=Q(0),
    )


def cache_witnesses(base: Mapping[str, Any], n: int, layers: int, residue: int) -> list[dict[str, Any]]:
    graph = clone_graph(base)
    operations: list[dict[str, Any]] = []

    def delete(edge_id: str) -> None:
        nonlocal graph
        after = remove_edge(graph, edge_id)
        witness = find_witness(graph, after, n)
        if witness is None:
            raise RuntimeError(f"no deletion witness for {edge_id}")
        operations.append({"operation": "delete_edge", "edge_id": edge_id, "witness": dict(witness)})
        graph = after

    def contract(edge_id: str, port_index: int, operation: str = "contract_radial") -> None:
        nonlocal graph
        port = graph["ports"][port_index]
        after = contract_port_edge(graph, edge_id, port)
        witness = find_witness(graph, after, n, exclude_ports=(port_index,))
        if witness is None:
            raise RuntimeError(f"no contraction witness for {edge_id} at {port}")
        operations.append({
            "operation": operation, "edge_id": edge_id,
            "contract_port": port, "port_index": port_index,
            "witness": dict(witness),
        })
        graph = after

    if residue == 2:
        for index in range(-layers, layers + 1):
            edge_id = f"b{'m' + str(-index) if index < 0 else index}"
            if index and any(edge["id"] == edge_id for edge in graph["edges"]):
                delete(edge_id)
    for edge_id in sorted(
        (edge["id"] for edge in graph["edges"] if edge["id"].startswith("spike_")),
        key=lambda value: int(value.split("_")[1]),
    ):
        edge = edge_by_id(graph, edge_id)
        ports = [node for node in (edge["u"], edge["v"]) if node in graph["ports"]]
        if len(ports) != 1:
            raise RuntimeError(f"unexpected spike endpoints: {edge}")
        contract(edge_id, graph["ports"].index(ports[0]), "contract_spike")
    for layer in range(max(0, layers - 1)):
        for index in range(n):
            edge_id = f"c{layer}_{index}"
            if any(edge["id"] == edge_id for edge in graph["edges"]):
                delete(edge_id)
        for index in range(n):
            edge_id = f"rad{layer}_{index}"
            if any(edge["id"] == edge_id for edge in graph["edges"]):
                contract(edge_id, index)
    return operations


def recover_cached(
    base: Mapping[str, Any],
    initial_response: Sequence[Sequence[Fraction]],
    operations: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    graph = clone_graph(base)
    response = [list(row) for row in initial_response]
    ports = list(base["ports"])
    weights: dict[str, Fraction] = {}
    divisions: list[dict[str, Any]] = []

    def division(name: str, numerator: Fraction, denominator: Fraction) -> None:
        divisions.append({"name": name, "numerator": numerator,
                          "denominator": denominator, "nonzero": denominator != 0})
        if denominator == 0:
            raise ZeroDivisionError(name)

    for operation in operations:
        edge_id = operation["edge_id"]
        witness = operation["witness"]
        rows, cols = witness["P"], witness["Q"]
        edge = edge_by_id(graph, edge_id)
        if operation["operation"] == "delete_edge":
            after = remove_edge(graph, edge_id)
            F = response_minor(response, rows, cols)
            update = port_edge_matrix(ports, edge)
            D = response_minor(matrix_add(response, update), rows, cols) - F
            division(f"delete:{edge_id}:D", F, D)
            coefficient = F / D
            response = matrix_sub(response, matrix_scale(update, coefficient))
        else:
            port_index = operation["port_index"]
            after = contract_port_edge(graph, edge_id, ports[port_index])
            F = response_minor(response, rows, cols)
            rank = rank_one_from_response(response, port_index)
            B = response_minor(matrix_add(response, rank), rows, cols) - F
            division(f"contract:{edge_id}:F", B, F)
            coefficient = response[port_index][port_index] - B / F
            denominator = coefficient - response[port_index][port_index]
            division(f"contract:{edge_id}:c-Mpp", Q(1), denominator)
            response = matrix_add(response, matrix_scale(rank, Q(1) / denominator))
        weights[edge_id] = coefficient
        graph = after
    for edge in graph["edges"]:
        u, v = ports.index(edge["u"]), ports.index(edge["v"])
        weights[edge["id"]] = -response[u][v]
    return {"weights": weights, "stripped_response": response, "divisions": divisions}


def one_sample(
    source: Mapping[str, Any], base: Mapping[str, Any], target: Mapping[str, Any],
    epsilon: Fraction, baseline: Mapping[str, Fraction],
    operations: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    source_weights = {
        edge["id"]: baseline[edge["id"]]
        for edge in source["edges"] if edge["id"] in baseline
    }
    source_weights["c0_0"] = epsilon
    source_response = graph_response(source, source_weights)
    parameter = extract_target_parameter(target, base, source_response, N, 3, 3)
    recovery = recover_cached(base, parameter["stripped_response"], operations)
    target_weights = {edge["id"]: recovery["weights"][edge["id"]] for edge in base["edges"]}
    feature_id = parameter["descriptor"]["edge_id"]
    target_weights[feature_id] = parameter["parameter"]
    target_response = graph_response(target, target_weights)
    recovered_response = graph_response(base, recovery["weights"])
    checks = {
        "source_weights_positive": all(value > 0 for value in source_weights.values()),
        "target_weights_positive": all(value > 0 for value in target_weights.values()),
        "target_parameter_positive": parameter["parameter"] > 0,
        "source_response_valid": validate_response(source_response, N + 1)["valid"],
        "target_response_valid": validate_response(target_response, N + 1)["valid"],
        "target_graph_valid": validate_graph(target)["valid"],
        "recovery_divisions_nonzero": all(item["nonzero"] for item in recovery["divisions"]),
        "base_recovery_exact": matrix_residual(
            parameter["stripped_response"], recovered_response
        ) == 0,
        "target_source_response_exact": matrix_residual(source_response, target_response) == 0,
    }
    algebraic_checks = {
        key: value for key, value in checks.items()
        if key != "target_weights_positive"
    }
    return {
        "epsilon": epsilon,
        "target_feature": feature_id,
        "target_parameter": parameter["parameter"],
        "center_weights": {
            edge_id: value for edge_id, value in target_weights.items()
            if edge_id.startswith("center_")
        },
        "checks": checks,
        "all_algebraic_checks_pass": all(algebraic_checks.values()),
        "positive_realization": checks["target_weights_positive"],
    }


def fit_mobius(points: Sequence[tuple[Fraction, Fraction]]) -> dict[str, Fraction]:
    matrix = [[Q(1), x, -x * y] for x, y in points[:3]]
    solution = solve(matrix, [[y] for _, y in points[:3]])
    return {"a": solution[0][0], "b": solution[1][0], "c": solution[2][0]}


def evaluate_mobius(fit: Mapping[str, Fraction], x: Fraction) -> Fraction:
    denominator = Q(1) + fit["c"] * x
    if denominator == 0:
        raise ZeroDivisionError("Mobius diagnostic denominator vanishes")
    return (fit["a"] + fit["b"] * x) / denominator


def run(output: Path, checkpoint: Path) -> dict[str, Any]:
    source, layers, residue = build_source(N)
    base, target = build_base_and_target(source, N, layers, residue)
    baseline = make_baseline(base)
    checkpoint.write_text(
        json.dumps({"n": N, "status": "in_progress", "stage": "witness_search_started"}, indent=2) + "\n",
        encoding="utf-8",
    )
    operations = cache_witnesses(base, N, layers, residue)
    checkpoint.write_text(
        json.dumps({"n": N, "status": "in_progress", "stage": "witness_cache_complete",
                    "operation_count": len(operations)}, indent=2) + "\n",
        encoding="utf-8",
    )
    epsilons = [Q(1, 100), Q(1, 50), Q(1, 20), Q(1, 10)]
    records = [one_sample(source, base, target, epsilon, baseline, operations)
               for epsilon in epsilons]
    fits: dict[str, Any] = {}
    for edge_id in sorted(records[0]["center_weights"]):
        points = [(record["epsilon"], record["center_weights"][edge_id]) for record in records]
        fit = fit_mobius(points)
        first_three_exact = all(
            evaluate_mobius(fit, x) == y for x, y in points[:3]
        )
        if not first_three_exact:
            raise AssertionError(f"Möbius fit did not interpolate first three points for {edge_id}")
        predicted = evaluate_mobius(fit, points[3][0])
        fits[edge_id] = {
            "fit_from_first_three": fit,
            "first_three_exact": first_three_exact,
            "fourth_actual": points[3][1],
            "fourth_predicted": predicted,
            "fourth_residual": points[3][1] - predicted,
            "exact_fit_at_fourth": points[3][1] == predicted,
        }
    certificate = {
        "scope": "Bounded exact n=11 residue-3 numerical ray diagnostic.",
        "diagnostic_status": "Mobius fit only; no proof claim.",
        "n": N, "layers_L": layers, "residue": residue, "epsilon_samples": epsilons,
        "graph_counts": {"source_edges": len(source["edges"]),
                         "base_edges": len(base["edges"]),
                         "target_edges": len(target["edges"]),
                         "cached_recovery_operations": len(operations)},
        "baseline_inherited_weights": baseline,
        "witness_operation_ids": [operation["edge_id"] for operation in operations],
        "samples": records,
        "all_algebraic_checks_pass": all(
            record["all_algebraic_checks_pass"] for record in records
        ),
        "all_target_samples_positive": all(
            record["positive_realization"] for record in records
        ),
        "center_mobius_fits": fits,
    }
    checkpoint.write_text(
                json.dumps({
                    "n": N, "status": "completed",
                    "stage": "diagnostic_certificate_ready",
                    "all_algebraic_checks_pass": certificate["all_algebraic_checks_pass"],
                    "all_target_samples_positive": certificate["all_target_samples_positive"],
                }, indent=2) + "\n",
        encoding="utf-8",
    )
    output.write_text(json.dumps(exact_json(certificate), ensure_ascii=False, indent=2) + "\n",
                      encoding="utf-8")
    return certificate


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "n11_numeric_ray_certificate.json")
    parser.add_argument("--checkpoint", type=Path, default=HERE / "n11_numeric_ray_checkpoint.json")
    args = parser.parse_args(argv)
    print("[n11-numeric] witness search", flush=True)
    certificate = run(args.output, args.checkpoint)
    print("[n11-numeric] all_algebraic_checks_pass:", certificate["all_algebraic_checks_pass"])
    print("[n11-numeric] all_target_samples_positive:", certificate["all_target_samples_positive"])
    print("[n11-numeric] center Mobius diagnostics:", len(certificate["center_mobius_fits"]))
    return 0 if certificate["all_algebraic_checks_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
