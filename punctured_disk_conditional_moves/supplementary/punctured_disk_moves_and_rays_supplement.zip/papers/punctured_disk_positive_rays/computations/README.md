# 精确探针

## 统一阶梯与阈值验证（2026-10-17）

`verify_wedge_structure.py` 对n=3,…,40的817条中心边，检查四余类端点规则、显式路径的合法性与顶点不交性、割集大小k−1，以及删除中心边并移除割集后的实际分离。全部通过，证书为 `wedge_structure_certificate.json`。该程序不枚举全部端点配对；一般配对唯一性由[阶梯证明](../notes/uniform_wedge_certificate.md)第5节给出。

    python computations/verify_wedge_structure.py --n-min 3 --n-max 40

`verify_wedge_witnesses.py` 另作精确响应子式及max-flow核对，并复算n=7旧基线的阈值。新分离子式给出的最小正根为54997063108/61616096925，与旧符号恢复证书完全相同。仿射公式在ε=0、1确定系数后，于ε=2再作独立精确检查。

    python computations/verify_wedge_witnesses.py --n-min 3 --n-max 16 --parity-budget 0

重验证的完成范围以证书中状态为complete的case为准；超时不会列入completed_n_values，也不会返回成功退出码。上次旧日志的n=17仅验证了9条中心边，不能算作完整n=17认证。

`scan_reentry_exact.py` 保存n=3,…,10、每个n三组正有理骨架、八个ε点的反例诊断，未发现重入。计算承担构造检查，不代替任意n的证明。

## n=7 整射线

probe_n7_symbolic_ray.py 固定 \(n=7\)、\(L=2\)、源边
c0_0 = epsilon，并给继承边指定一组非对称正有理电导。程序调用前篇
图构造及 find_witness，再用独立的 \(\mathbb Q(\varepsilon)\) Schur 补和恢复
实现计算目标电导。

运行：

    python computations/probe_n7_symbolic_ray.py --output computations/n7_symbolic_ray_certificate.json

2026-10-16 的证书包含：

- 源、骨架、目标边数分别为 28, 27, 28，目标电导数为 28；
- 完整 \(8\times8\) 目标响应与源响应的符号恒等式精确成立；
- 目标电导的分子、分母次数、因式分解、零点和极点；
- 正临界点唯一，为
  \[
  \varepsilon_* = 54997063108/61616096925;
  \]
  精确符号分区给出目标严格正区间
  \((0,\varepsilon_*)\)；临界边为 center_2；
- 六个正有理样本的独立 Fraction 全响应核对。

该探针只覆盖固定的 \(n=7\) 非对称骨架与边射线，用于识别退化机制，
不替代一般 \(n\) 的证明。

## n=11 三层探针

`probe_n11_symbolic_ray.py` 使用同一非对称基线，固定 \(n=11\)、\(L=3\)、
`c0_0 = epsilon`。源响应由精确的

    M(epsilon) = M(0) + epsilon U_{c0_0}

秩一公式构造，避免再次进行源端符号 Schur 补；随后调用同一
\(\mathbb Q(\varepsilon)\) 删除/收缩恢复。运行时输出
`source_affine_complete`、`target_parameter_extracted`、
`symbolic_recovery_started` 等阶段，并可保存检查点：

    python computations/probe_n11_symbolic_ray.py \
      --output computations/n11_symbolic_ray_certificate.json \
      --checkpoint computations/n11_symbolic_ray_checkpoint.json

`--verify-symbolic-target` 可选地计算完整目标符号响应。三层全恢复的有理函数
约分成本显著高于 n=7，检查点记录最后完成阶段。

## 分离子式坐标自审核对（2026-10-17）

`audit_minor_coordinates.py` 对 n=3,…,10 的非对称正圆盘骨架，独立进行 Fraction Dirichlet 求解，构造退出矩阵 H 及 μ=e_t 对应的完整响应。按正文显式端点配对预先确定符号，直接验证全部 f_s(M_{e_t}) 构成严格正对角矩阵，同时检查 H 非负、列和为 1，以及响应对称性/行和条件。

结果见 `audit_minor_coordinates_certificate.json`：八个 n 全部通过。该检查覆盖最低层数的观测中心邻点情形，只验证有限样本，不替代统一证明。

## Ground-state 线性判据

`verify_ground_state_criterion.py` 对 \(n=3,\ldots,11\) 的固定非对称正目标
进行独立的 Fraction 检查：调和缩放、
\(Q=K_a[V\setminus S,I]\) 的 \(r=1/h\) 解、
\(\mu_s=c_{zs}h_s\)，以及行列式的径向边/spike/target-spike 单项式。

    python computations/verify_ground_state_criterion.py \
      --output computations/ground_state_criterion_certificate.json

生成的证书 `ground_state_criterion_certificate.json` 的
`all_cases_pass` 为 `true`。

## n=11 数值四点诊断

`probe_n11_numeric_ray.py` 只搜索一次恢复 witness，随后在 epsilon = 1/100, 1/50, 1/20, 1/10 上复用该拓扑序列。它把每个
`center_*` 坐标的前三点拟合为 Möbius 形式 (a+b epsilon)/(1+c epsilon)，并在第四点作精确有理数检验；该拟合仅用于诊断。

    python computations/probe_n11_numeric_ray.py \
      --output computations/n11_numeric_ray_certificate.json \
      --checkpoint computations/n11_numeric_ray_checkpoint.json

当前四点结果为：前两点全部目标电导为正；在 epsilon = 1/20, 1/10 时 `center_3` 与 `center_9` 为负。四点的
代数响应核对全部通过，且 11 个中心坐标均通过前三点到第四点的 Möbius 精确拟合。详见 `n11_numeric_ray_certificate.json`。
