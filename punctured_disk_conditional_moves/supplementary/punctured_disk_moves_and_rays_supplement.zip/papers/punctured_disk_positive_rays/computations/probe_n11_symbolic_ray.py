#!/usr/bin/env python3
"""Exact three-layer probe for the ``n=11`` boundary-edge ray.

This is the next fixed asymmetric test after ``probe_n7_symbolic_ray.py``.
The inherited conductances use the same deterministic rule as that probe and
the source edge ``c0_0`` has conductance ``epsilon``.  The source response is
formed as an affine rank-one update of the exact response with that edge set
to zero; this avoids a second symbolic Laplacian inversion.  Target
conductances are then recovered in ``Q(epsilon)`` by the independent
deletion/contraction engine from the n=7 probe.

The default certificate checks the recovered target by exact Fraction
responses at several positive rational values.  ``--verify-symbolic-target``
also computes the full symbolic target response; it is intentionally
optional because its rational Gaussian elimination is substantially larger
for three layers.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence


HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from probe_n7_symbolic_ray import (  # noqa: E402
    Rat,
    Q,
    _format_fraction,
    exact_positive_intervals,
    factor_data,
    fs_value,
    graph_response_symbolic,
    matrix_add,
    matrix_scale,
    matrix_sub,
    make_baseline,
    port_edge_matrix_symbolic,
    rat_summary,
    recover_base_symbolic,
    extract_target_symbolic,
    symbolic_matrix_residual_entries,
)
from verify_local_controls import graph_response as fraction_graph_response  # noqa: E402
from verify_uniform_minors import (  # noqa: E402
    build_base_and_target,
    build_source,
    validate_graph,
)
from verify_uniform_transform import edge_by_id  # noqa: E402


N = 11
FEATURE_ID = "c0_0"


def affine_source_response(
    source: Mapping[str, Any], baseline: Mapping[str, Fraction]
) -> tuple[list[list[Rat]], dict[str, Any]]:
    """Return M(epsilon)=M(0)+epsilon*U using exact Fraction arithmetic."""

    zero_feature_weights = {
        edge["id"]: baseline[edge["id"]]
        for edge in source["edges"]
        if edge["id"] in baseline
    }
    zero_feature_weights[FEATURE_ID] = Q(0)
    at_zero = fraction_graph_response(source, zero_feature_weights)
    constant = [[Rat.constant(value) for value in row] for row in at_zero]
    update = port_edge_matrix_symbolic(source["ports"], edge_by_id(source, FEATURE_ID))
    source_response = matrix_add(constant, matrix_scale(update, Rat.variable()))
    return source_response, {
        "feature_id": FEATURE_ID,
        "zero_feature_response": at_zero,
        "update_matrix": update,
        "construction": "M(0)+epsilon*U_c0_0",
    }


def matrix_equal_fraction(
    left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]
) -> bool:
    return len(left) == len(right) and all(
        len(left_row) == len(right_row)
        and all(a == b for a, b in zip(left_row, right_row))
        for left_row, right_row in zip(left, right)
    )


def common_denominator_data(values: Mapping[str, Rat]) -> dict[str, Any]:
    """Record whether all center conductances have one normalized denominator."""

    denominators = {edge_id: value.denominator for edge_id, value in values.items()}
    unique = {denominator for denominator in denominators.values()}
    common = next(iter(unique)) if len(unique) == 1 else None
    return {
        "all_denominators_identical": common is not None,
        "distinct_denominator_count": len(unique),
        "common_denominator": factor_data(common) if common is not None else None,
        "denominators": {
            edge_id: factor_data(denominator)
            for edge_id, denominator in sorted(denominators.items())
        },
    }


def run_probe(
    samples: Sequence[Fraction],
    verify_symbolic_target: bool = False,
    checkpoint_path: Path | None = None,
    progress: bool = True,
) -> dict[str, Any]:
    def mark(stage: str, **details: Any) -> None:
        if progress:
            print(f"[n11] {stage}", flush=True)
        if checkpoint_path is not None:
            checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "n": N,
                "status": "in_progress",
                "stage": stage,
                "details": fs_value(details),
            }
            checkpoint_path.write_text(
                json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )

    mark("initializing")
    source, layers, residue = build_source(N)
    base, target = build_base_and_target(source, N, layers, residue)
    if (layers, residue) != (3, 3):
        raise AssertionError(f"expected n=11 to have L=3, residue=3; got {(layers, residue)}")

    baseline = make_baseline(base)
    source_response, affine_data = affine_source_response(source, baseline)
    mark(
        "source_affine_complete",
        source_edges=len(source["edges"]),
        base_edges=len(base["edges"]),
        target_edges=len(target["edges"]),
        response_dimension=len(source_response),
    )
    extracted = extract_target_symbolic(target, base, source_response, N, layers, residue)
    mark(
        "target_parameter_extracted",
        feature_id=extracted["feature_id"],
        parameter_degree=extracted["parameter"].degree,
        parameter_denominator_degree=extracted["parameter"].denominator_degree,
    )
    mark("symbolic_recovery_started")
    recovery = recover_base_symbolic(base, extracted["stripped_response"], N, layers, residue)
    mark(
        "symbolic_recovery_complete",
        operation_count=len(recovery["operations"]),
        division_count=len(recovery["divisions"]),
    )
    target_weights = dict(recovery["weights"])
    target_weights[extracted["feature_id"]] = extracted["parameter"]

    center_weights = {
        edge_id: value
        for edge_id, value in target_weights.items()
        if edge_id.startswith("center_")
    }

    target_symbolic_result: dict[str, Any]
    symbolic_residuals: list[dict[str, Any]] = []
    if verify_symbolic_target:
        target_response = graph_response_symbolic(target, target_weights)
        symbolic_residuals = symbolic_matrix_residual_entries(source_response, target_response)
        target_symbolic_result = {
            "status": "computed",
            "exact": not symbolic_residuals,
            "dimension": [len(target_response), len(target_response[0])],
            "nonzero_residual_entries": symbolic_residuals,
        }
    else:
        target_symbolic_result = {
            "status": "skipped_by_default",
            "reason": "full target Q(epsilon) Schur complement is optional for the three-layer probe",
        }

    sample_records: list[dict[str, Any]] = []
    for sample in samples:
        source_weights = {
            edge["id"]: baseline[edge["id"]]
            for edge in source["edges"]
            if edge["id"] in baseline
        }
        source_weights[FEATURE_ID] = sample
        evaluated_target = {
            edge_id: value.evaluate(sample)
            for edge_id, value in target_weights.items()
        }
        direct_source = fraction_graph_response(source, source_weights)
        direct_target = fraction_graph_response(target, evaluated_target)
        symbolic_source = [
            [value.evaluate(sample) for value in row]
            for row in source_response
        ]
        sample_records.append({
            "epsilon": _format_fraction(sample),
            "all_source_weights_positive": all(value > 0 for value in source_weights.values()),
            "all_target_weights_positive": all(value > 0 for value in evaluated_target.values()),
            "affine_symbolic_source_equals_fraction_source": matrix_equal_fraction(
                symbolic_source, direct_source
            ),
            "target_equals_source_response": matrix_equal_fraction(direct_target, direct_source),
            "target_weights": {
                edge_id: _format_fraction(value)
                for edge_id, value in evaluated_target.items()
            },
        })
    mark("fraction_samples_complete", sample_count=len(sample_records))

    certificate = {
        "scope": (
            "Exact n=11 residue-3 three-layer boundary-edge ray: source c0_0=epsilon, "
            "deterministic asymmetric positive inherited weights, full observed ports (p0,...,p10,z)."
        ),
        "interpretation": (
            "Target conductances are recovered exactly in Q(epsilon). The default response check "
            "uses exact Fraction evaluations; full symbolic target response is optional."
        ),
        "n": N,
        "layers_L": layers,
        "residue": residue,
        "ports": source["ports"],
        "source_feature": {"edge_id": FEATURE_ID, "conductance": "epsilon"},
        "baseline_inherited_weights": baseline,
        "source_affine_construction": {
            "construction": affine_data["construction"],
            "zero_feature_response": affine_data["zero_feature_response"],
            "update_matrix": affine_data["update_matrix"],
        },
        "graph_counts": {
            "source_edges": len(source["edges"]),
            "base_edges": len(base["edges"]),
            "target_edges": len(target["edges"]),
            "target_weights": len(target_weights),
            "source_internal": len(source.get("internal", [])),
            "base_internal": len(base.get("internal", [])),
            "target_internal": len(target.get("internal", [])),
            "checks": {
                "source_is_66": len(source["edges"]) == 66,
                "base_is_65": len(base["edges"]) == 65,
                "target_is_66": len(target["edges"]) == 66,
                "target_weights_match_target": len(target_weights) == len(target["edges"]),
                "source_graph_valid": validate_graph(source)["valid"],
                "base_graph_valid": validate_graph(base)["valid"],
                "target_graph_valid": validate_graph(target)["valid"],
            },
        },
        "target_feature": {
            "edge_id": extracted["feature_id"],
            "port_index": extracted["port_index"],
            "witness": extracted["witness"],
            "F": extracted["F"],
            "B": extracted["B"],
            "parameter": extracted["parameter"],
        },
        "symbolic_target_response": target_symbolic_result,
        "symbolic_target_weights": {
            edge_id: rat_summary(value)
            for edge_id, value in sorted(target_weights.items())
        },
        "center_weights": {
            edge_id: rat_summary(value)
            for edge_id, value in sorted(center_weights.items())
        },
        "center_common_denominator": common_denominator_data(center_weights),
        "recovery": {
            "operation_count": len(recovery["operations"]),
            "operations": recovery["operations"],
            "division_count": len(recovery["divisions"]),
            "all_symbolic_divisors_nonzero": all(
                item["nonzero"] for item in recovery["divisions"]
            ),
            "divisions": recovery["divisions"],
        },
        "zeros_poles_degrees": {
            edge_id: {
                "numerator_degree": value.degree,
                "denominator_degree": value.denominator_degree,
                "zeros": factor_data(value.numerator)["rational_roots"],
                "poles": factor_data(value.denominator)["rational_roots"],
            }
            for edge_id, value in sorted(target_weights.items())
        },
        "positivity": exact_positive_intervals(target_weights),
        "samples": sample_records,
        "all_sample_checks_pass": all(
            record["all_source_weights_positive"]
            and record["all_target_weights_positive"]
            and record["affine_symbolic_source_equals_fraction_source"]
            and record["target_equals_source_response"]
            for record in sample_records
        ),
        "all_exact_recovery_checks_pass": (
            all(item["nonzero"] for item in recovery["divisions"])
            and len(target_weights) == len(target["edges"])
        ),
    }
    if checkpoint_path is not None:
        checkpoint_path.write_text(
            json.dumps(
                {
                    "n": N,
                    "status": "completed",
                    "stage": "certificate_ready",
                    "details": {
                        "all_sample_checks_pass": certificate["all_sample_checks_pass"],
                        "all_exact_recovery_checks_pass": certificate["all_exact_recovery_checks_pass"],
                    },
                },
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
    return certificate


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output",
        type=Path,
        default=HERE / "n11_symbolic_ray_certificate.json",
    )
    parser.add_argument(
        "--verify-symbolic-target",
        action="store_true",
        help="also compute and compare the full symbolic target response",
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=None,
        help="write the last completed stage to this JSON path",
    )
    args = parser.parse_args(argv)
    samples = [Q(1, 100), Q(1, 10), Q(1, 2), Q(1), Q(2), Q(10)]
    certificate = fs_value(
        run_probe(
            samples,
            verify_symbolic_target=args.verify_symbolic_target,
            checkpoint_path=args.checkpoint,
        )
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(certificate, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"certificate: {args.output.resolve()}")
    print(f"all_sample_checks_pass: {certificate['all_sample_checks_pass']}")
    print(f"all_exact_recovery_checks_pass: {certificate['all_exact_recovery_checks_pass']}")
    print(f"positivity_status: {certificate['positivity']['status']}")
    print(
        "symbolic_target_response_status: "
        f"{certificate['symbolic_target_response']['status']}"
    )
    return 0 if certificate["all_sample_checks_pass"] and certificate["all_exact_recovery_checks_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
