#!/usr/bin/env python3
"""Independent exact audit of the separating-minor coordinates.

For ``n=3,...,10`` this script removes the observed centre and all centre
edges, assigns the resulting circular-planar graph ``C_n`` the asymmetric
positive rational weights returned by :func:`make_baseline`, and computes
its exact Laplacian and response.  The exit matrix is then formed directly
from the Dirichlet inverse of ``C_n``.

For each basis vector ``mu=e_t`` we construct the full observed response
matrix

    M_OO = L + diag(j),  M_Oz = -j,  M_zz = sum(j),  j=H mu.

For every centre edge ``s`` the script evaluates the wedge minor attached
to the explicit pairing in ``verify_wedge_witnesses.py``.  Its sign is fixed
by ``(-1)^k`` times the parity of that explicit pairing; no sign is chosen
from the numerical value of the determinant.  The expected result is a
positive diagonal matrix ``(f_s(M_{e_t}))_{s,t}``.

This is a finite algebraic audit of the coordinate identity, including the
cases in which a centre endpoint is itself an observed outer port.  It is
not a proof of the all-n statement.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence


HERE = Path(__file__).resolve().parent
PREDECESSOR = HERE.parents[1] / "punctured_disk_conditional_moves" / "computations"
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
if str(PREDECESSOR) not in sys.path:
    sys.path.insert(0, str(PREDECESSOR))

from probe_n7_symbolic_ray import make_baseline  # noqa: E402
from verify_local_controls import graph_nodes, graph_response, solve  # noqa: E402
from verify_n7_closed_move import determinant  # noqa: E402
from verify_uniform_minors import (  # noqa: E402
    Q,
    build_base_and_target,
    build_source,
)
from verify_wedge_witnesses import explicit_pairing, wedge_sets  # noqa: E402


def fs(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


def exact_json(value: Any) -> Any:
    if isinstance(value, Fraction):
        return fs(value)
    if isinstance(value, dict):
        return {str(key): exact_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [exact_json(item) for item in value]
    return value


def zero_matrix(rows: int, cols: int) -> list[list[Fraction]]:
    return [[Q(0) for _ in range(cols)] for _ in range(rows)]


def laplacian(graph: Mapping[str, Any], weights: Mapping[str, Fraction]) -> tuple[list[str], list[list[Fraction]]]:
    nodes = graph_nodes(graph)
    positions = {node: index for index, node in enumerate(nodes)}
    result = zero_matrix(len(nodes), len(nodes))
    for edge in graph["edges"]:
        weight = weights[edge["id"]]
        u, v = positions[edge["u"]], positions[edge["v"]]
        result[u][u] += weight
        result[v][v] += weight
        result[u][v] -= weight
        result[v][u] -= weight
    return nodes, result


def matrix_submatrix(matrix: Sequence[Sequence[Fraction]], rows: Sequence[int], cols: Sequence[int]) -> list[list[Fraction]]:
    return [[matrix[row][col] for col in cols] for row in rows]


def matrix_max_abs(matrix: Sequence[Sequence[Fraction]]) -> Fraction:
    return max((abs(value) for row in matrix for value in row), default=Q(0))


def remove_centre(target: Mapping[str, Any]) -> dict[str, Any]:
    """Return ``C_n`` with ports ``p_0,...,p_{n-1}`` and no centre edges."""

    edges = [
        dict(edge)
        for edge in target["edges"]
        if not edge["id"].startswith("center_")
        and edge["u"] != "z"
        and edge["v"] != "z"
    ]
    return {
        "ports": [node for node in target["ports"] if node != "z"],
        "internal": list(target.get("internal", [])),
        "edges": edges,
    }


def centre_endpoints(target: Mapping[str, Any]) -> list[str]:
    result: list[str] = []
    for edge in target["edges"]:
        if not edge["id"].startswith("center_"):
            continue
        endpoint = edge["v"] if edge["u"] == "z" else edge["u"]
        if endpoint == "z" or endpoint in result:
            raise ValueError(f"invalid centre edge list: {target!r}")
        result.append(endpoint)
    return result


def exit_matrix(
    c_graph: Mapping[str, Any],
    nodes: Sequence[str],
    k_matrix: Sequence[Sequence[Fraction]],
    S: Sequence[str],
) -> tuple[list[str], list[list[Fraction]], dict[str, Any]]:
    """Compute H by unit columns for observed S and a Dirichlet inverse otherwise."""

    outer = list(c_graph["ports"])
    internal = list(c_graph.get("internal", []))
    positions = {node: index for index, node in enumerate(nodes)}
    outer_positions = [positions[node] for node in outer]
    internal_positions = [positions[node] for node in internal]
    k_ii = matrix_submatrix(k_matrix, internal_positions, internal_positions)
    k_oi = matrix_submatrix(k_matrix, outer_positions, internal_positions)
    if internal:
        # H_int = -K_OI K_II^{-1}; solving the transpose gives all columns
        # without using a floating point inverse.
        transposed = [list(row) for row in zip(*k_ii)]
        solved = solve(transposed, [list(row) for row in zip(*k_oi)])
        k_ii_inv_k_io = [list(row) for row in zip(*solved)]
        harmonic = [
            [-k_ii_inv_k_io[row][col] for col in range(len(internal))]
            for row in range(len(outer))
        ]
    else:
        harmonic = []
    outer_index = {node: index for index, node in enumerate(outer)}
    internal_index = {node: index for index, node in enumerate(internal)}
    columns: list[list[Fraction]] = []
    for endpoint in S:
        if endpoint in outer_index:
            column = [Q(0) for _ in outer]
            column[outer_index[endpoint]] = Q(1)
        elif endpoint in internal_index:
            column = [harmonic[row][internal_index[endpoint]] for row in range(len(outer))]
        else:
            raise ValueError(f"centre endpoint {endpoint!r} is absent from C_n")
        columns.append(column)
    H = [[columns[col][row] for col in range(len(columns))] for row in range(len(outer))]
    return outer, H, {
        "outer": outer,
        "internal": internal,
        "observed_endpoint_indices": [outer_index.get(endpoint) for endpoint in S],
        "internal_endpoint_indices": [internal_index.get(endpoint) for endpoint in S],
        "dirichlet_inverse_used": bool(internal),
    }


def build_full_response(L: Sequence[Sequence[Fraction]], j: Sequence[Fraction]) -> list[list[Fraction]]:
    n = len(j)
    M = zero_matrix(n + 1, n + 1)
    for row in range(n):
        for col in range(n):
            M[row][col] = L[row][col]
        M[row][row] += j[row]
        M[row][n] = -j[row]
        M[n][row] = -j[row]
    M[n][n] = sum(j)
    return M


def permutation_parity(P: Sequence[int], Q_indices: Sequence[int], pairing: Mapping[int, int]) -> int:
    q_position = {q: index for index, q in enumerate(Q_indices)}
    sequence = [q_position[pairing[p]] for p in P]
    return sum(sequence[i] > sequence[j] for i in range(len(sequence)) for j in range(i + 1, len(sequence))) % 2


def signed_wedge_minor(
    M: Sequence[Sequence[Fraction]],
    n: int,
    layers: int,
    residue: int,
    center_index: int,
) -> dict[str, Any]:
    P, Q_indices, construction = wedge_sets(n, layers, residue, center_index)
    pairing_data = explicit_pairing(n, layers, residue, P, Q_indices, construction)
    pairing = pairing_data["pairing"]
    parity = permutation_parity(P, Q_indices, pairing)
    k = len(P)
    determinant_value = determinant([[M[row][col] for col in Q_indices] for row in P])
    sign_factor = Q(1) if (k + parity) % 2 == 0 else Q(-1)
    return {
        "P": list(P),
        "Q": list(Q_indices),
        "k": k,
        "pairing": pairing,
        "pairing_parity": parity,
        "sign_factor": sign_factor,
        "raw_determinant": determinant_value,
        "signed_value": sign_factor * determinant_value,
    }


def audit_case(n: int) -> dict[str, Any]:
    source, layers, residue = build_source(n)
    _base, target = build_base_and_target(source, n, layers, residue)
    c_graph = remove_centre(target)
    weights = make_baseline(c_graph)
    nodes, k_matrix = laplacian(c_graph, weights)
    outer, L = c_graph["ports"], graph_response(c_graph, weights)
    S = centre_endpoints(target)
    if len(S) != n or len(set(S)) != n:
        raise ValueError(f"centre endpoints are not a size-n set for n={n}: {S}")
    _, H, h_meta = exit_matrix(c_graph, nodes, k_matrix, S)
    f_matrix: list[list[Fraction]] = []
    minor_records: list[dict[str, Any]] = []
    for center_index in range(n):
        record = signed_wedge_minor(M=build_full_response(L, [Q(0)] * n), n=n, layers=layers, residue=residue, center_index=center_index)
        # The endpoint sets, pairing, and fixed sign do not depend on mu; the
        # actual minors are computed below and the first record is retained as
        # the compact sign certificate.
        minor_records.append({key: value for key, value in record.items() if key not in {"raw_determinant", "signed_value"}})
    for t in range(n):
        mu = [Q(1) if index == t else Q(0) for index in range(n)]
        j = [sum(H[row][col] * mu[col] for col in range(n)) for row in range(n)]
        M = build_full_response(L, j)
        row_values = [
            signed_wedge_minor(M, n, layers, residue, center_index)["signed_value"]
            for center_index in range(n)
        ]
        f_matrix.append(row_values)
    diagonal = [f_matrix[index][index] for index in range(n)]
    off_diagonal = [
        {"row": row, "column": col, "value": f_matrix[row][col]}
        for row in range(n)
        for col in range(n)
        if row != col and f_matrix[row][col] != 0
    ]
    h_column_sums = [sum(H[row][col] for row in range(n)) for col in range(n)]
    l_row_sums = [sum(row) for row in L]
    response_checks = {
        "L_symmetric": all(L[row][col] == L[col][row] for row in range(n) for col in range(n)),
        "L_row_sum_zero": all(value == 0 for value in l_row_sums),
        "H_column_stochastic": all(value == 1 for value in h_column_sums),
        "H_nonnegative": all(value >= 0 for row in H for value in row),
        "M_row_sum_zero_for_all_basis": all(
            sum(build_full_response(L, [H[row][col] for row in range(n)])[row]) == 0
            for col in range(n) for row in range(n + 1)
        ),
    }
    checks = {
        **response_checks,
        "f_matrix_diagonal": not off_diagonal,
        "f_matrix_diagonal_strictly_positive": all(value > 0 for value in diagonal),
    }
    return {
        "n": n,
        "layers_L": layers,
        "residue": residue,
        "graph_counts": {
            "C_vertices": len(nodes),
            "C_edges": len(c_graph["edges"]),
            "C_internal": len(c_graph.get("internal", [])),
        },
        "centre_endpoints_S": S,
        "weights": weights,
        "H": H,
        "L": L,
        "H_metadata": h_meta,
        "minor_signs": minor_records,
        "f_matrix": f_matrix,
        "diagonal_coefficients": diagonal,
        "off_diagonal_nonzero": off_diagonal,
        "checks": checks,
        "all_checks_pass": all(checks.values()),
    }


def run(output: Path, n_min: int, n_max: int) -> dict[str, Any]:
    started = time.monotonic()
    cases = [audit_case(n) for n in range(n_min, n_max + 1)]
    certificate = {
        "scope": "Exact Fraction audit of f_s(M_{e_t}) = kappa_s delta_{s,t}, n=3,...,10; C_n has the observed centre and centre edges removed.",
        "status": "finite_audit_not_general_proof",
        "sign_rule": "sign_factor = (-1)^(k + explicit_pairing_inversion_parity); it is fixed before evaluating the determinant.",
        "requested_n_values": list(range(n_min, n_max + 1)),
        "cases": cases,
        "all_cases_pass": all(case["all_checks_pass"] for case in cases),
        "elapsed_seconds": time.monotonic() - started,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(exact_json(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return certificate


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "audit_minor_coordinates_certificate.json")
    parser.add_argument("--n-min", type=int, default=3)
    parser.add_argument("--n-max", type=int, default=10)
    args = parser.parse_args(argv)
    certificate = run(args.output, args.n_min, args.n_max)
    print(f"certificate: {args.output.resolve()}")
    print(f"completed_n_values: {certificate['requested_n_values']}")
    print(f"all_cases_pass: {certificate['all_cases_pass']}")
    print(f"elapsed_seconds: {certificate['elapsed_seconds']:.3f}")
    return 0 if certificate["all_cases_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
