#!/usr/bin/env python3
"""Cheap structural sweep for the cyclic center-deletion witnesses.

This check deliberately avoids response minors, max-flow linkage counts, and
pairing-parity enumeration.  It only exercises the explicit construction:
the proposed sets, the displayed paths, the staircase separator, and the
literal graph-level separation check.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
PREDECESSOR = HERE.parents[1] / "punctured_disk_conditional_moves" / "computations"
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
if str(PREDECESSOR) not in sys.path:
    sys.path.insert(0, str(PREDECESSOR))

from verify_uniform_minors import build_base_and_target, build_source, exact_json  # noqa: E402
from verify_wedge_witnesses import (  # noqa: E402
    delete_edge_graph,
    explicit_paths,
    staircase_cut,
    validate_explicit_paths,
    wedge_sets,
)


def verify_case(n: int) -> dict[str, Any]:
    source, layers, residue = build_source(n)
    _base, target = build_base_and_target(source, n, layers, residue)
    results: list[dict[str, Any]] = []
    for center_index in range(n):
        P, Q, construction = wedge_sets(n, layers, residue, center_index)
        after = delete_edge_graph(target, f"center_{center_index}")
        cut = staircase_cut(target, n, layers, residue, center_index)
        path_data = explicit_paths(target, n, layers, residue, P, Q, construction)
        path_checks = validate_explicit_paths(
            target,
            after,
            P,
            Q,
            path_data,
            cut,
            residue == 3,
        )
        cut_size_expected = len(P) - 1
        results.append(
            {
                "center_index": center_index,
                "P": P,
                "Q": Q,
                "k": len(P),
                "sizes_equal": construction["sizes_equal"],
                "disjoint": construction["disjoint"],
                "z_in_Q": construction["z_in_Q"],
                "explicit_path_checks": path_checks,
                "staircase_cut_size": len(cut),
                "staircase_cut_size_expected": cut_size_expected,
                "all_checks_pass": (
                    construction["sizes_equal"]
                    and construction["disjoint"]
                    and construction["z_in_Q"]
                    and path_checks["all_checks_pass"]
                    and len(cut) == cut_size_expected
                ),
            }
        )
    return {
        "n": n,
        "layers_L": layers,
        "residue": residue,
        "status": "complete",
        "results": results,
        "all_checks_pass": all(item["all_checks_pass"] for item in results),
        "all_explicit_path_checks_pass": all(
            item["explicit_path_checks"]["all_checks_pass"] for item in results
        ),
        "all_cut_sizes_pass": all(
            item["staircase_cut_size"] == item["staircase_cut_size_expected"]
            for item in results
        ),
    }


def run(output: Path, n_min: int, n_max: int) -> dict[str, Any]:
    started = time.monotonic()
    cases = [verify_case(n) for n in range(n_min, n_max + 1)]
    requested = list(range(n_min, n_max + 1))
    certificate = {
        "scope": f"Structural-only cyclic wedge witness sweep, n={n_min},...,{n_max}.",
        "diagnostic_status": (
            "No response minors, max-flow linkage counts, or pairing-parity enumeration; "
            "checks only explicit paths and staircase cuts."
        ),
        "requested_n_values": requested,
        "completed_n_values": [case["n"] for case in cases if case["status"] == "complete"],
        "cases": cases,
        "all_cases_pass": all(case["all_checks_pass"] for case in cases),
        "all_explicit_path_checks_pass": all(
            case["all_explicit_path_checks_pass"] for case in cases
        ),
        "all_cut_sizes_pass": all(case["all_cut_sizes_pass"] for case in cases),
        "elapsed_seconds": time.monotonic() - started,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(exact_json(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return certificate


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "wedge_structure_certificate.json")
    parser.add_argument("--n-min", type=int, default=3)
    parser.add_argument("--n-max", type=int, default=40)
    args = parser.parse_args(argv)
    certificate = run(args.output, args.n_min, args.n_max)
    print(f"certificate: {args.output.resolve()}")
    print(f"completed_n_values: {certificate['completed_n_values']}")
    print(f"all_cases_pass: {certificate['all_cases_pass']}")
    print(f"all_explicit_path_checks_pass: {certificate['all_explicit_path_checks_pass']}")
    print(f"all_cut_sizes_pass: {certificate['all_cut_sizes_pass']}")
    print(f"elapsed_seconds: {certificate['elapsed_seconds']:.3f}")
    return 0 if certificate["all_cases_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
