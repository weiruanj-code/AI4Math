#!/usr/bin/env python3
"""Exact separating-minor probe for deletion of target center edges.

For n=3,...,8 this enumerates disjoint response minors on the full observed
port set (including z), compares linkage before and after deleting each
center edge, and checks the resulting determinant vanishing at two positive
target assignments.  It is a finite topology diagnostic, not a general
separation theorem.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
import sys
import time
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence

HERE = Path(__file__).resolve().parent
PREDECESSOR = HERE.parents[1] / "punctured_disk_conditional_moves" / "computations"
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
if str(PREDECESSOR) not in sys.path:
    sys.path.insert(0, str(PREDECESSOR))

from probe_n7_symbolic_ray import make_baseline  # noqa: E402
from verify_local_controls import graph_response  # noqa: E402
from verify_uniform_minors import (  # noqa: E402
    Q,
    all_one,
    build_base_and_target,
    build_source,
    exact_json,
    linkage_count,
    response_minor,
)
from verify_uniform_transform import remove_edge  # noqa: E402


def observed_minor_candidates(graph: Mapping[str, Any]) -> list[tuple[tuple[int, ...], tuple[int, ...], int]]:
    """Enumerate disjoint equal-size P,Q with z in P union Q."""

    ports = list(graph["ports"])
    z_index = ports.index("z")
    candidates: list[tuple[tuple[int, ...], tuple[int, ...], int]] = []
    for k in range(1, len(ports) // 2 + 1):
        for P in itertools.combinations(range(len(ports)), k):
            remaining = [index for index in range(len(ports)) if index not in P]
            for Q_indices in itertools.combinations(remaining, k):
                if z_index not in P and z_index not in Q_indices:
                    continue
                candidates.append((P, Q_indices, k))
    return candidates


def delete_edge_graph(graph: Mapping[str, Any], edge_id: str) -> dict[str, Any]:
    return remove_edge(graph, edge_id)


class PairingSearchTimeout(RuntimeError):
    """The bounded path-pairing enumeration exceeded its time budget."""


def graph_adjacency(graph: Mapping[str, Any]) -> dict[str, set[str]]:
    adjacency: dict[str, set[str]] = {}
    for edge in graph["edges"]:
        u, v = edge["u"], edge["v"]
        adjacency.setdefault(u, set()).add(v)
        adjacency.setdefault(v, set()).add(u)
    return adjacency


def pairing_parity_diagnostic(
    graph: Mapping[str, Any],
    P: Sequence[int],
    Q_indices: Sequence[int],
    deadline: float,
) -> dict[str, Any]:
    """Exhaustively test all endpoint permutations for vertex-disjoint paths.

    Other observed ports are forbidden as path interiors.  For each fixed
    endpoint permutation, the recursive search stops after one disjoint path
    family is found; all permutations are still tested, which is enough to
    determine the set of feasible pairing parities.
    """

    ports = list(graph["ports"])
    p_nodes = tuple(ports[index] for index in P)
    q_nodes = tuple(ports[index] for index in Q_indices)
    # Every observed port is terminal: ports outside P union Q are forbidden
    # as path interiors, exactly as in the linkage computation.
    terminals = set(ports)
    adjacency = graph_adjacency(graph)
    feasible: list[tuple[int, ...]] = []
    tested = 0

    def path_extensions(start: str, target: str, used: frozenset[str]):
        visited = set(used)
        visited.add(start)
        path = [start]

        def walk(node: str):
            if time.monotonic() >= deadline:
                raise PairingSearchTimeout
            for nxt in sorted(adjacency.get(node, ())):
                if nxt in visited:
                    continue
                if nxt in terminals and nxt != target:
                    continue
                visited.add(nxt)
                path.append(nxt)
                if nxt == target:
                    yield frozenset(path)
                else:
                    yield from walk(nxt)
                path.pop()
                visited.remove(nxt)

        yield from walk(start)

    def family_exists(assignment: tuple[str, ...]) -> bool:
        failed: set[tuple[int, frozenset[str]]] = set()

        def search(index: int, used: frozenset[str]) -> bool:
            if time.monotonic() >= deadline:
                raise PairingSearchTimeout
            if index == len(p_nodes):
                return True
            state = (index, used)
            if state in failed:
                return False
            start = p_nodes[index]
            target = assignment[index]
            for path_nodes in path_extensions(start, target, used):
                if search(index + 1, used | path_nodes):
                    return True
            failed.add(state)
            return False

        return search(0, frozenset())

    try:
        for assignment in itertools.permutations(q_nodes):
            tested += 1
            if family_exists(tuple(assignment)):
                feasible.append(tuple(Q_indices[q_nodes.index(node)] for node in assignment))
    except PairingSearchTimeout:
        return {
            "status": "timeout",
            "permutation_count": math.factorial(len(q_nodes)),
            "tested_permutations": tested,
            "feasible_pairings": feasible,
            "parities": sorted({permutation_parity(pairing) for pairing in feasible}),
            "same_parity": None,
        }

    parities = sorted({permutation_parity(pairing) for pairing in feasible})
    return {
        "status": "complete",
        "permutation_count": math.factorial(len(q_nodes)),
        "tested_permutations": tested,
        "feasible_pairings": feasible,
        "parities": parities,
        "same_parity": len(parities) <= 1,
    }


def permutation_parity(pairing: Sequence[int]) -> int:
    inversions = sum(
        pairing[i] > pairing[j]
        for i in range(len(pairing))
        for j in range(i + 1, len(pairing))
    )
    return inversions % 2


def determinant_checks(
    target: Mapping[str, Any],
    after: Mapping[str, Any],
    witness: Mapping[str, Any],
) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    assignments = [
        ("all_one", all_one(target)),
        ("asymmetric_rational", make_baseline(target)),
    ]
    P = witness["P"]
    Q_indices = witness["Q"]
    for name, weights in assignments:
        before_response = graph_response(target, weights)
        after_weights = {edge["id"]: weights[edge["id"]] for edge in after["edges"]}
        after_response = graph_response(after, after_weights)
        before_det = response_minor(before_response, P, Q_indices)
        after_det = response_minor(after_response, P, Q_indices)
        records.append({
            "assignment": name,
            "before_determinant": before_det,
            "after_determinant": after_det,
            "before_nonzero": before_det != 0,
            "after_zero": after_det == 0,
        })
    return records


def scan_target(
    n: int,
    target: Mapping[str, Any],
    edge_id: str,
    candidates: Sequence[tuple[tuple[int, ...], tuple[int, ...], int]],
    before_linkage: Mapping[tuple[tuple[int, ...], tuple[int, ...], int], int],
    started: float,
    time_limit: float,
) -> dict[str, Any]:
    after = delete_edge_graph(target, edge_id)
    lost_by_rank: dict[int, int] = {}
    witnesses: list[dict[str, Any]] = []
    timed_out = False
    # High ranks first make the diagnostic report the strongest separation
    # witness promptly, while the complete rank counts are still collected
    # whenever the bounded time budget permits.
    for P, Q_indices, k in sorted(candidates, key=lambda item: -item[2]):
        if time.monotonic() - started >= time_limit:
            timed_out = True
            break
        key = (P, Q_indices, k)
        if before_linkage.get(key) != k:
            continue
        after_value = linkage_count(after, P, Q_indices)
        if after_value >= k:
            continue
        lost_by_rank[k] = lost_by_rank.get(k, 0) + 1
        if len(witnesses) < 3:
            witness = {
                "P": P,
                "Q": Q_indices,
                "k": k,
                "before_linkage": before_linkage[key],
                "after_linkage": after_value,
            }
            witness["determinant_checks"] = determinant_checks(target, after, witness)
            witness["determinant_checks_pass"] = all(
                item["before_nonzero"] and item["after_zero"]
                for item in witness["determinant_checks"]
            )
            witness["pairing_parity"] = pairing_parity_diagnostic(
                target, P, Q_indices, started + time_limit
            )
            witnesses.append(witness)
    return {
        "edge_id": edge_id,
        "lost_witness_count_by_rank": lost_by_rank,
        "max_lost_rank": max(lost_by_rank, default=None),
        "witnesses": witnesses,
        "timed_out": timed_out,
    }


def high_rank_candidates(graph: Mapping[str, Any]) -> list[tuple[tuple[int, ...], tuple[int, ...], int]]:
    """Candidates at the largest possible equal minor rank."""

    maximum_rank = len(graph["ports"]) // 2
    return [
        candidate
        for candidate in observed_minor_candidates(graph)
        if candidate[2] == maximum_rank
    ]


def quick_high_rank_scan(
    n: int,
    target: Mapping[str, Any],
    started: float,
    time_limit: float,
) -> dict[str, Any]:
    """Search one maximal-rank lost witness per center edge for larger n."""

    candidates = high_rank_candidates(target)
    before_linkage: dict[tuple[tuple[int, ...], tuple[int, ...], int], int] = {}
    edge_results: list[dict[str, Any]] = []
    timed_out = False
    for edge in target["edges"]:
        if not edge["id"].startswith("center_"):
            continue
        edge_id = edge["id"]
        after = delete_edge_graph(target, edge_id)
        found: dict[str, Any] | None = None
        tested = 0
        for P, Q_indices, k in candidates:
            if time.monotonic() - started >= time_limit:
                timed_out = True
                break
            tested += 1
            key = (P, Q_indices, k)
            if key not in before_linkage:
                before_linkage[key] = linkage_count(target, P, Q_indices)
            if before_linkage[key] != k:
                continue
            after_value = linkage_count(after, P, Q_indices)
            if after_value >= k:
                continue
            found = {
                "P": P,
                "Q": Q_indices,
                "k": k,
                "before_linkage": before_linkage[key],
                "after_linkage": after_value,
            }
            found["determinant_checks"] = determinant_checks(target, after, found)
            found["determinant_checks_pass"] = all(
                item["before_nonzero"] and item["after_zero"]
                for item in found["determinant_checks"]
            )
            found["pairing_parity"] = pairing_parity_diagnostic(
                target, P, Q_indices, started + time_limit
            )
            break
        edge_results.append({
            "edge_id": edge_id,
            "tested_candidates": tested,
            "witness": found,
            "timed_out": timed_out,
        })
        if timed_out:
            break
    return {
        "search_scope": "maximal equal-minor rank only",
        "candidate_count": len(candidates),
        "center_edge_results": edge_results,
        "timed_out": timed_out,
    }


def cyclic_interval(start: int, end: int, n: int) -> tuple[int, ...]:
    return tuple((start + offset) % n for offset in range(end - start + 1))


def explicit_residue3_witnesses(
    n: int,
    target: Mapping[str, Any],
    started: float,
    time_limit: float,
) -> dict[str, Any]:
    """Test the cyclic block witnesses for n=4L-1 at n=11 and n=15."""

    if n % 4 != 3:
        raise ValueError("explicit residue-3 patterns require n=4L-1")
    layers = (n + 1) // 4
    z_index = n
    results: list[dict[str, Any]] = []
    parity_centers = set(range(n)) if n <= 10 else {0, layers, 3 * layers}
    for s in range(n):
        if time.monotonic() - started >= time_limit:
            return {"status": "timeout", "n": n, "layers_L": layers, "results": results}
        if s in (layers, 3 * layers):
            if s == layers:
                P = tuple(sorted({0, *range(2 * layers + 1, 4 * layers - 1), z_index}))
                Q_indices = tuple(range(1, 2 * layers + 1))
            else:
                P = tuple(sorted({0, *range(2 * layers, 4 * layers - 1)}))
                Q_indices = tuple(sorted({*range(1, 2 * layers), z_index}))
            witness_type = "exceptional"
        else:
            P = tuple(sorted(set(cyclic_interval(s - layers + 1, s + layers - 1, n))))
            Q_indices = tuple(sorted(set(cyclic_interval(s + layers + 1, s + 3 * layers - 2, n)) | {z_index}))
            witness_type = "ordinary"
        k = len(P)
        edge_id = f"center_{s}"
        after = delete_edge_graph(target, edge_id)
        before_value = linkage_count(target, P, Q_indices)
        after_value = linkage_count(after, P, Q_indices)
        witness = {
            "P": P,
            "Q": Q_indices,
            "k": k,
            "witness_type": witness_type,
            "before_linkage": before_value,
            "after_linkage": after_value,
            "lost": before_value == k and after_value < k,
        }
        if witness["lost"]:
            witness["determinant_checks"] = determinant_checks(target, after, witness)
            witness["determinant_checks_pass"] = all(
                item["before_nonzero"] and item["after_zero"]
                for item in witness["determinant_checks"]
            )
            if s in parity_centers:
                witness["pairing_parity"] = pairing_parity_diagnostic(
                    target,
                    P,
                    Q_indices,
                    min(started + time_limit, time.monotonic() + 5.0),
                )
            else:
                witness["pairing_parity"] = {
                    "status": "not_attempted",
                    "reason": "bounded explicit probe reserves parity enumeration for representative centers",
                }
        results.append({"edge_id": edge_id, "witness": witness})
    return {
        "status": "complete",
        "n": n,
        "layers_L": layers,
        "target_spike_index": 2 * layers,
        "results": results,
        "all_topological_witnesses_lost": all(item["witness"]["lost"] for item in results),
    }


def run_explicit_only(output: Path, checkpoint: Path, time_limit: float) -> dict[str, Any]:
    started = time.monotonic()
    explicit_cases: list[dict[str, Any]] = []
    stopped_due_to_time = False
    for n in (11, 15):
        source, layers, residue = build_source(n)
        _base, target = build_base_and_target(source, n, layers, residue)
        case = explicit_residue3_witnesses(n, target, started, time_limit)
        explicit_cases.append(case)
        if case.get("status") == "timeout":
            stopped_due_to_time = True
            break
    certificate = {
        "scope": "Explicit cyclic residue-3 separating-minor probes for n=11 and n=15.",
        "diagnostic_status": "Finite topology and parity diagnostic only.",
        "explicit_residue3_cases_n11_n15": explicit_cases,
        "stopped_due_to_time": stopped_due_to_time,
        "elapsed_seconds": time.monotonic() - started,
        "all_explicit_witnesses_lost": all(
            case.get("all_topological_witnesses_lost", False)
            for case in explicit_cases
            if case.get("status") == "complete"
        ),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(exact_json(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    checkpoint.write_text(json.dumps(exact_json({
        "status": "partial" if stopped_due_to_time else "completed",
        "elapsed_seconds": certificate["elapsed_seconds"],
    }), indent=2) + "\n", encoding="utf-8")
    return certificate


def run(output: Path, checkpoint: Path, time_limit: float) -> dict[str, Any]:
    started = time.monotonic()
    cases: list[dict[str, Any]] = []
    explicit_cases: list[dict[str, Any]] = []
    extended_cases: list[dict[str, Any]] = []
    stopped_due_to_time = False
    checkpoint.parent.mkdir(parents=True, exist_ok=True)
    checkpoint.write_text(json.dumps({"status": "in_progress", "stage": "started"}, indent=2) + "\n", encoding="utf-8")
    for n in range(3, 9):
        if time.monotonic() - started >= time_limit:
            stopped_due_to_time = True
            break
        source, layers, residue = build_source(n)
        _base, target = build_base_and_target(source, n, layers, residue)
        candidates = observed_minor_candidates(target)
        before_linkage: dict[tuple[tuple[int, ...], tuple[int, ...], int], int] = {}
        rank_counts: dict[int, int] = {}
        for P, Q_indices, k in candidates:
            if time.monotonic() - started >= time_limit:
                stopped_due_to_time = True
                break
            value = linkage_count(target, P, Q_indices)
            before_linkage[(P, Q_indices, k)] = value
            if value == k:
                rank_counts[k] = rank_counts.get(k, 0) + 1
        if stopped_due_to_time:
            break
        center_ids = [edge["id"] for edge in target["edges"] if edge["id"].startswith("center_")]
        edge_results: list[dict[str, Any]] = []
        for edge_id in center_ids:
            result = scan_target(
                n, target, edge_id, candidates, before_linkage, started, time_limit
            )
            edge_results.append(result)
            checkpoint.write_text(
                json.dumps(exact_json({
                    "status": "in_progress",
                    "stage": "center_edge_scan",
                    "elapsed_seconds": time.monotonic() - started,
                    "completed_n": n,
                    "completed_center_edges": len(edge_results),
                }), indent=2)
                + "\n",
                encoding="utf-8",
            )
            if result["timed_out"]:
                stopped_due_to_time = True
                break
        case = {
            "n": n,
            "layers_L": layers,
            "residue": residue,
            "ports": target["ports"],
            "candidate_count_including_z": len(candidates),
            "candidate_max_linkage_counts": rank_counts,
            "center_edge_results": edge_results,
        }
        cases.append(case)
        if stopped_due_to_time:
            break
    if not stopped_due_to_time:
        for n in (11, 15):
            if time.monotonic() - started >= time_limit:
                stopped_due_to_time = True
                break
            source, layers, residue = build_source(n)
            _base, target = build_base_and_target(source, n, layers, residue)
            explicit = explicit_residue3_witnesses(n, target, started, time_limit)
            explicit_cases.append(explicit)
            if explicit.get("status") == "timeout":
                stopped_due_to_time = True
                break
    if not stopped_due_to_time:
        for n in range(9, 13):
            if time.monotonic() - started >= time_limit:
                stopped_due_to_time = True
                break
            source, layers, residue = build_source(n)
            _base, target = build_base_and_target(source, n, layers, residue)
            extended = quick_high_rank_scan(n, target, started, time_limit)
            extended_cases.append({
                "n": n,
                "layers_L": layers,
                "residue": residue,
                "ports": target["ports"],
                **extended,
            })
            if extended["timed_out"]:
                stopped_due_to_time = True
                break
    certificate = {
        "scope": "Finite exact center-edge deletion probe for target graphs n=3,...,8; P,Q are disjoint observed-port subsets and z is required in P union Q.",
        "diagnostic_status": "Topology and determinant diagnostic only; no general separation theorem.",
        "cases": cases,
        "explicit_residue3_cases_n11_n15": explicit_cases,
        "extended_cases_n9_n12": extended_cases,
        "stopped_due_to_time": stopped_due_to_time,
        "elapsed_seconds": time.monotonic() - started,
        "all_recorded_witness_determinants_pass": all(
            witness["determinant_checks_pass"]
            for case in cases
            for edge in case["center_edge_results"]
            for witness in edge["witnesses"]
        ) and all(
            result["witness"]["determinant_checks_pass"]
            for case in extended_cases
            for result in case["center_edge_results"]
            if result.get("witness") is not None
        ),
        "all_explicit_witnesses_lost": all(
            case.get("all_topological_witnesses_lost", False)
            for case in explicit_cases
            if case.get("status") == "complete"
        ),
        "pairing_parity_violations": [
            {
                "n": case["n"],
                "residue": case["residue"],
                "edge_id": edge["edge_id"],
                "P": witness["P"],
                "Q": witness["Q"],
                "parities": witness["pairing_parity"]["parities"],
            }
            for case in cases
            for edge in case["center_edge_results"]
            for witness in edge["witnesses"]
            if witness["pairing_parity"].get("status") == "complete"
            and witness["pairing_parity"].get("same_parity") is False
        ],
        "extended_pairing_parity_violations": [
            {
                "n": case["n"],
                "residue": case["residue"],
                "edge_id": result["edge_id"],
                "P": result["witness"]["P"],
                "Q": result["witness"]["Q"],
                "parities": result["witness"]["pairing_parity"]["parities"],
            }
            for case in extended_cases
            for result in case["center_edge_results"]
            if result.get("witness") is not None
            and result["witness"]["pairing_parity"].get("status") == "complete"
            and result["witness"]["pairing_parity"].get("same_parity") is False
        ],
        "explicit_pairing_parity_violations": [
            {
                "n": case["n"],
                "edge_id": item["edge_id"],
                "P": item["witness"]["P"],
                "Q": item["witness"]["Q"],
                "parities": item["witness"]["pairing_parity"]["parities"],
            }
            for case in explicit_cases
            for item in case.get("results", [])
            if item["witness"].get("pairing_parity", {}).get("status") == "complete"
            and item["witness"]["pairing_parity"].get("same_parity") is False
        ],
        "all_recorded_pairing_enumerations_complete": all(
            witness["pairing_parity"].get("status") == "complete"
            for case in cases
            for edge in case["center_edge_results"]
            for witness in edge["witnesses"]
        ),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(exact_json(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    checkpoint.write_text(json.dumps(exact_json({
        "status": "partial" if stopped_due_to_time else "completed",
        "stage": "certificate_ready",
        "elapsed_seconds": certificate["elapsed_seconds"],
        "case_count": len(cases),
    }), indent=2) + "\n", encoding="utf-8")
    return certificate


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "center_deletion_minor_certificate.json")
    parser.add_argument("--checkpoint", type=Path, default=HERE / "center_deletion_minor_checkpoint.json")
    parser.add_argument("--time-limit", type=float, default=55.0)
    parser.add_argument(
        "--explicit-only",
        action="store_true",
        help="run only the explicit n=11,n=15 residue-3 witness patterns",
    )
    args = parser.parse_args(argv)
    certificate = (
        run_explicit_only(args.output, args.checkpoint, args.time_limit)
        if args.explicit_only
        else run(args.output, args.checkpoint, args.time_limit)
    )
    print(f"certificate: {args.output.resolve()}")
    print(f"n_cases: {len(certificate.get('cases', certificate.get('explicit_residue3_cases_n11_n15', [])))}")
    print(f"elapsed_seconds: {certificate['elapsed_seconds']:.3f}")
    if "all_recorded_witness_determinants_pass" in certificate:
        print(f"all_recorded_witness_determinants_pass: {certificate['all_recorded_witness_determinants_pass']}")
    if "all_explicit_witnesses_lost" in certificate:
        print(f"all_explicit_witnesses_lost: {certificate['all_explicit_witnesses_lost']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
