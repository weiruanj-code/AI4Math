#!/usr/bin/env python3
"""Exact finite checks for the ground-state linear criterion.

For each ``n=3,...,11`` this utility assigns the target graph a fixed,
asymmetric positive rational conductance vector.  It solves the target
Dirichlet problem with outer boundary value one and centre value zero,
conjugates the target with the resulting ground state, and checks:

* ``L = A - diag(A 1)`` is the ordinary response of the target with its
  centre edges removed and conductances ``a_e=c_e h_u h_v``;
* the system ``K_a[V\\S,I] r_I = rhs`` recovers ``r=1/h``;
* the source vector ``mu`` equals ``c_{zs} h_s`` on every centre endpoint;
* the determinant of the system is, up to sign, the product of all radial,
  spike, and target-spike conductances.

All calculations use only ``fractions.Fraction``.  This is a finite algebraic
certificate for the criterion, not a proof of the all-n statement.
"""

from __future__ import annotations

import argparse
import json
import sys
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping, Sequence


HERE = Path(__file__).resolve().parent
PREDECESSOR = HERE.parents[1] / "punctured_disk_conditional_moves" / "computations"
if str(PREDECESSOR) not in sys.path:
    sys.path.insert(0, str(PREDECESSOR))

from verify_local_controls import graph_response, graph_nodes, solve  # noqa: E402
from verify_n7_closed_move import determinant  # noqa: E402
from verify_uniform_minors import Q, build_base_and_target, build_source  # noqa: E402


def fs(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


def exact_json(value: Any) -> Any:
    if isinstance(value, Fraction):
        return fs(value)
    if isinstance(value, dict):
        return {str(key): exact_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [exact_json(item) for item in value]
    return value


def zero_matrix(rows: int, cols: int) -> list[list[Fraction]]:
    return [[Q(0) for _ in range(cols)] for _ in range(rows)]


def matrix_sub(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> list[list[Fraction]]:
    return [[left[i][j] - right[i][j] for j in range(len(left[i]))] for i in range(len(left))]


def matrix_max_abs(matrix: Sequence[Sequence[Fraction]]) -> Fraction:
    return max((abs(value) for row in matrix for value in row), default=Q(0))


def matrix_equal(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> bool:
    return len(left) == len(right) and all(
        len(a) == len(b) and all(x == y for x, y in zip(a, b))
        for a, b in zip(left, right)
    )


def laplacian(graph: Mapping[str, Any], weights: Mapping[str, Fraction]) -> tuple[list[str], list[list[Fraction]]]:
    nodes = graph_nodes(graph)
    positions = {node: index for index, node in enumerate(nodes)}
    result = zero_matrix(len(nodes), len(nodes))
    for edge in graph["edges"]:
        weight = weights[edge["id"]]
        u, v = positions[edge["u"]], positions[edge["v"]]
        result[u][u] += weight
        result[v][v] += weight
        result[u][v] -= weight
        result[v][u] -= weight
    return nodes, result


def target_weights(target: Mapping[str, Any]) -> dict[str, Fraction]:
    # This is the same deterministic asymmetry used by the n=7 probe, now
    # applied to the complete target edge list so every target edge is fixed.
    return {
        edge["id"]: Q(1) + Q((7 * index + 3) % 19, 100)
        for index, edge in enumerate(target["edges"])
    }


def target_ground_state(
    target: Mapping[str, Any], weights: Mapping[str, Fraction]
) -> tuple[dict[str, Fraction], list[list[Fraction]]]:
    nodes, full = laplacian(target, weights)
    positions = {node: index for index, node in enumerate(nodes)}
    boundary = list(target["ports"])
    internal = list(target.get("internal", []))
    boundary_values = [Q(0) if node == "z" else Q(1) for node in boundary]
    i_indices = [positions[node] for node in internal]
    b_indices = [positions[node] for node in boundary]
    l_ii = [[full[row][col] for col in i_indices] for row in i_indices]
    l_ib = [[full[row][col] for col in b_indices] for row in i_indices]
    rhs = [[-sum(l_ib[row][col] * boundary_values[col] for col in range(len(boundary)))] for row in range(len(internal))]
    solved = solve(l_ii, rhs)
    h = {node: boundary_values[index] for index, node in enumerate(boundary)}
    h.update({node: solved[index][0] for index, node in enumerate(internal)})
    residual = []
    full_values = [h[node] for node in nodes]
    for row in i_indices:
        residual.append([sum(full[row][col] * full_values[col] for col in range(len(nodes)))])
    return h, residual


def centre_endpoints(target: Mapping[str, Any]) -> list[str]:
    result = []
    for edge in target["edges"]:
        if not edge["id"].startswith("center_"):
            continue
        endpoint = edge["v"] if edge["u"] == "z" else edge["u"]
        if endpoint == "z" or endpoint in result:
            raise ValueError(f"invalid centre edge list: {target!r}")
        result.append(endpoint)
    return result


def reduced_graph_and_weights(
    target: Mapping[str, Any], weights: Mapping[str, Fraction], h: Mapping[str, Fraction]
) -> tuple[dict[str, Any], dict[str, Fraction]]:
    edges = []
    reduced_weights: dict[str, Fraction] = {}
    for edge in target["edges"]:
        if edge["u"] == "z" or edge["v"] == "z":
            continue
        edges.append(dict(edge))
        reduced_weights[edge["id"]] = weights[edge["id"]] * h[edge["u"]] * h[edge["v"]]
    reduced = {
        "ports": [node for node in target["ports"] if node != "z"],
        "internal": list(target.get("internal", [])),
        "edges": edges,
    }
    return reduced, reduced_weights


def reduced_laplacian(
    graph: Mapping[str, Any], weights: Mapping[str, Fraction]
) -> tuple[list[str], list[list[Fraction]]]:
    return laplacian(graph, weights)


def criterion_case(n: int) -> dict[str, Any]:
    source, layers, residue = build_source(n)
    base, target = build_base_and_target(source, n, layers, residue)
    weights = target_weights(target)
    h, harmonic_residual = target_ground_state(target, weights)
    reduced, a_weights = reduced_graph_and_weights(target, weights, h)
    reduced_nodes, k_a = reduced_laplacian(reduced, a_weights)
    outer = [node for node in target["ports"] if node != "z"]
    inner = list(target.get("internal", []))
    outer_index = {node: index for index, node in enumerate(outer)}
    full_target_response = graph_response(target, weights)
    A = [row[:n] for row in full_target_response[:n]]
    j = [sum(row) for row in A]
    L = [list(row) for row in A]
    for index in range(n):
        L[index][index] -= j[index]
    reduced_response = graph_response(reduced, a_weights)
    S = centre_endpoints(target)
    if len(S) != n or len(set(S)) != n:
        raise ValueError(f"centre endpoints are not a size-n set for n={n}: {S}")
    S_set = set(S)
    I = [node for node in reduced_nodes if node in inner]
    rows = [node for node in reduced_nodes if node not in S_set]
    if len(rows) != len(I):
        raise ValueError(f"Q is not square for n={n}: rows={len(rows)}, I={len(I)}")
    positions = {node: index for index, node in enumerate(reduced_nodes)}
    i_positions = [positions[node] for node in I]
    row_positions = [positions[node] for node in rows]
    q_matrix = [[k_a[row][col] for col in i_positions] for row in row_positions]
    known = [Q(1) for _ in outer]
    rhs: list[list[Fraction]] = []
    for node, row in zip(rows, row_positions):
        source_term = -j[outer_index[node]] if node in outer_index else Q(0)
        boundary_term = sum(k_a[row][positions[boundary]] for boundary in outer)
        rhs.append([source_term - boundary_term])
    solved = solve(q_matrix, rhs)
    r = {node: Q(1) for node in outer}
    r.update({node: solved[index][0] for index, node in enumerate(I)})
    inverse_h = {node: Q(1) / h[node] for node in reduced_nodes}
    mu = {}
    center_conductance = {}
    for edge in target["edges"]:
        if edge["id"].startswith("center_"):
            endpoint = edge["v"] if edge["u"] == "z" else edge["u"]
            center_conductance[endpoint] = weights[edge["id"]]
    for node in S:
        row = positions[node]
        value = sum(k_a[row][col] * r[reduced_nodes[col]] for col in range(len(reduced_nodes)))
        if node in outer_index:
            value += j[outer_index[node]]
        mu[node] = value
    determinant_q = determinant(q_matrix)
    factor_edges = [
        edge for edge in target["edges"]
        if edge["id"].startswith("rad")
        or edge["id"].startswith("spike_")
        or edge["id"].startswith("target_spike_")
    ]
    factor_product = Q(1)
    for edge in factor_edges:
        factor_product *= a_weights[edge["id"]]
    det_ratio = determinant_q / factor_product if factor_product else Q(0)
    criterion_checks = {
        "target_ground_state_positive": all(
            h[node] > 0 for node in h if node != "z"
        ),
        "target_harmonic_internal": all(value == 0 for row in harmonic_residual for value in row),
        "response_scaling_exact": matrix_equal(L, reduced_response),
        "response_scaling_residual_zero": matrix_max_abs(matrix_sub(L, reduced_response)) == 0,
        "q_square": len(q_matrix) == len(I),
        "q_determinant_nonzero": determinant_q != 0,
        "r_equals_inverse_h": all(r[node] == inverse_h[node] for node in reduced_nodes),
        "mu_equals_center_conductance_times_h": all(
            mu[node] == center_conductance[node] * h[node] for node in S
        ),
        "determinant_product_up_to_sign": abs(determinant_q) == abs(factor_product),
        "determinant_ratio_is_sign": det_ratio in (Q(1), Q(-1)),
    }
    return {
        "n": n,
        "layers_L": layers,
        "residue": residue,
        "graph_counts": {
            "target_edges": len(target["edges"]),
            "target_internal": len(target.get("internal", [])),
            "reduced_vertices": len(reduced_nodes),
            "q_rows": len(q_matrix),
            "q_columns": len(I),
        },
        "sets": {"outer": outer, "inner": inner, "S": S, "Q_rows": rows, "Q_columns": I},
        "determinant": {
            "Q": determinant_q,
            "factor_edge_ids": [edge["id"] for edge in factor_edges],
            "factor_product": factor_product,
            "ratio": det_ratio,
        },
        "ground_state": {
            "h": h,
            "min_positive_h": min(value for value in h.values() if value > 0),
        },
        "criterion": {
            "r": r,
            "inverse_h": inverse_h,
            "mu": mu,
            "center_conductance_times_h": {
                node: center_conductance[node] * h[node] for node in S
            },
        },
        "checks": criterion_checks,
        "all_checks_pass": all(criterion_checks.values()),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=HERE / "ground_state_criterion_certificate.json"
    )
    args = parser.parse_args(argv)
    cases = [criterion_case(n) for n in range(3, 12)]
    certificate = {
        "scope": "Exact Fraction checks of the ground-state linear criterion for n=3,...,11.",
        "target_weight_rule": "c_e=1+((7*edge_index+3) mod 19)/100 in target edge order",
        "cases": cases,
        "all_cases_pass": all(case["all_checks_pass"] for case in cases),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(exact_json(certificate), ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"certificate: {args.output.resolve()}")
    print(f"all_cases_pass: {certificate['all_cases_pass']}")
    return 0 if certificate["all_cases_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
