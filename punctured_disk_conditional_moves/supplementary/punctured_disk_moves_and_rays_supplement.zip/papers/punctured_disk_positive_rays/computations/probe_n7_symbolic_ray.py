#!/usr/bin/env python3
"""Exact one-parameter probe for the n=7 boundary-edge ray.

The probe reuses the predecessor's graph constructors and its deterministic
``find_witness`` routine, but performs the response and stripping algebra in
an independent univariate rational-function implementation.  It is a
targeted calculation, not a positivity theorem: the output records exact
weights, zeros/poles, and only the positivity intervals certified by the
available factor information.  Independent Fraction evaluations are used to
check the symbolic response identity at several positive rational values.

Run from this directory or from the paper root, for example::

    python computations/probe_n7_symbolic_ray.py --output computations/n7_symbolic_ray_certificate.json

Only files in this new ``computations`` directory are written.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
from dataclasses import dataclass
from fractions import Fraction
from itertools import combinations
from pathlib import Path
from typing import Any, Mapping, Sequence


HERE = Path(__file__).resolve().parent
PREDECESSOR = HERE.parents[1] / "punctured_disk_conditional_moves" / "computations"
if str(PREDECESSOR) not in sys.path:
    sys.path.insert(0, str(PREDECESSOR))

from verify_local_controls import graph_response as fraction_graph_response  # noqa: E402
from verify_uniform_minors import (  # noqa: E402
    Q,
    build_base_and_target,
    build_source,
    validate_graph,
)
from verify_uniform_transform import (  # noqa: E402
    AlgorithmError,
    clone_graph,
    contract_port_edge,
    edge_by_id,
    find_witness,
    matrix_copy,
    port_edge_matrix,
    remove_edge,
    rank_one_from_response,
)


# ---------------------------------------------------------------------------
# A small exact Q[x] / Q(x) implementation.  It is intentionally independent
# of verify_local_controls' Fraction Gaussian elimination and has no external
# dependency.  SymPy is not required; if it is present it is not used here,
# so the generated certificate remains reproducible with the standard library.

Poly = tuple[Fraction, ...]


def _trim(value: Sequence[Fraction]) -> Poly:
    result = list(value)
    while len(result) > 1 and result[-1] == 0:
        result.pop()
    if not result:
        return (Q(0),)
    return tuple(result)


def _p_const(value: Fraction | int) -> Poly:
    return (Q(value),)


def _p_add(left: Poly, right: Poly) -> Poly:
    size = max(len(left), len(right))
    return _trim([
        (left[i] if i < len(left) else Q(0)) + (right[i] if i < len(right) else Q(0))
        for i in range(size)
    ])


def _p_neg(value: Poly) -> Poly:
    return tuple(-item for item in value)


def _p_sub(left: Poly, right: Poly) -> Poly:
    return _p_add(left, _p_neg(right))


def _p_mul(left: Poly, right: Poly) -> Poly:
    result = [Q(0)] * (len(left) + len(right) - 1)
    for i, a in enumerate(left):
        for j, b in enumerate(right):
            result[i + j] += a * b
    return _trim(result)


def _p_scale(value: Poly, scalar: Fraction) -> Poly:
    return _trim([scalar * item for item in value])


def _p_divmod(left: Poly, right: Poly) -> tuple[Poly, Poly]:
    right = _trim(right)
    if right == (Q(0),):
        raise ZeroDivisionError("polynomial division by zero")
    remainder = list(_trim(left))
    quotient = [Q(0)] * max(1, len(remainder) - len(right) + 1)
    while len(remainder) >= len(right) and _trim(remainder) != (Q(0),):
        degree = len(remainder) - len(right)
        coefficient = remainder[-1] / right[-1]
        quotient[degree] += coefficient
        for index, value in enumerate(right):
            remainder[index + degree] -= coefficient * value
        remainder = list(_trim(remainder))
    return _trim(quotient), _trim(remainder)


def _p_exact_div(left: Poly, right: Poly) -> Poly:
    quotient, remainder = _p_divmod(left, right)
    if remainder != (Q(0),):
        raise ArithmeticError(f"non-exact polynomial division: {left!r} / {right!r}")
    return quotient


def _p_gcd(left: Poly, right: Poly) -> Poly:
    left, right = _trim(left), _trim(right)
    while right != (Q(0),):
        _, remainder = _p_divmod(left, right)
        left, right = right, remainder
    if left == (Q(0),):
        return (Q(1),)
    return _p_scale(left, Q(1) / left[-1])


def _p_eval(poly: Poly, x: Fraction) -> Fraction:
    result = Q(0)
    for coefficient in reversed(poly):
        result = result * x + coefficient
    return result


def _poly_to_ints(poly: Poly) -> tuple[int, ...]:
    lcm = 1
    for coefficient in poly:
        lcm = math.lcm(lcm, coefficient.denominator)
    values = [int(coefficient * lcm) for coefficient in poly]
    gcd = 0
    for value in values:
        gcd = math.gcd(gcd, abs(value))
    if gcd:
        values = [value // gcd for value in values]
    while len(values) > 1 and values[-1] == 0:
        values.pop()
    if values and values[-1] < 0:
        values = [-value for value in values]
    return tuple(values or [0])


def _format_fraction(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


@dataclass(frozen=True)
class Rat:
    numerator: Poly
    denominator: Poly = (Q(1),)

    def __post_init__(self) -> None:
        numerator = _trim(self.numerator)
        denominator = _trim(self.denominator)
        if denominator == (Q(0),):
            raise ZeroDivisionError("rational-function denominator is zero")
        if numerator == (Q(0),):
            object.__setattr__(self, "numerator", (Q(0),))
            object.__setattr__(self, "denominator", (Q(1),))
            return
        common = _p_gcd(numerator, denominator)
        numerator = _p_exact_div(numerator, common)
        denominator = _p_exact_div(denominator, common)
        # Make the denominator monic.  Constants are units in Q[x]; leaving
        # them in the denominator causes harmless but catastrophic coefficient
        # growth during repeated Schur-complement operations.
        scale = Q(1) / denominator[-1]
        numerator = _p_scale(numerator, scale)
        denominator = _p_scale(denominator, scale)
        object.__setattr__(self, "numerator", numerator)
        object.__setattr__(self, "denominator", denominator)

    @classmethod
    def constant(cls, value: Fraction | int) -> "Rat":
        return cls(_p_const(Q(value)))

    @classmethod
    def variable(cls) -> "Rat":
        return cls((Q(0), Q(1)))

    def __add__(self, other: Any) -> "Rat":
        other = as_rat(other)
        return Rat(
            _p_add(_p_mul(self.numerator, other.denominator), _p_mul(other.numerator, self.denominator)),
            _p_mul(self.denominator, other.denominator),
        )

    def __radd__(self, other: Any) -> "Rat":
        return self + other

    def __neg__(self) -> "Rat":
        return Rat(_p_neg(self.numerator), self.denominator)

    def __sub__(self, other: Any) -> "Rat":
        return self + (-as_rat(other))

    def __rsub__(self, other: Any) -> "Rat":
        return as_rat(other) - self

    def __mul__(self, other: Any) -> "Rat":
        other = as_rat(other)
        return Rat(_p_mul(self.numerator, other.numerator), _p_mul(self.denominator, other.denominator))

    def __rmul__(self, other: Any) -> "Rat":
        return self * other

    def __truediv__(self, other: Any) -> "Rat":
        other = as_rat(other)
        if other.numerator == (Q(0),):
            raise ZeroDivisionError("division by zero rational function")
        return Rat(_p_mul(self.numerator, other.denominator), _p_mul(self.denominator, other.numerator))

    def __rtruediv__(self, other: Any) -> "Rat":
        return as_rat(other) / self

    def __eq__(self, other: Any) -> bool:
        try:
            other = as_rat(other)
        except (TypeError, ValueError):
            return False
        return self.numerator == other.numerator and self.denominator == other.denominator

    def __bool__(self) -> bool:
        return self.numerator != (Q(0),)

    @property
    def degree(self) -> int:
        return -1 if self.numerator == (Q(0),) else len(self.numerator) - 1

    @property
    def denominator_degree(self) -> int:
        return len(self.denominator) - 1

    def evaluate(self, x: Fraction) -> Fraction:
        denominator = _p_eval(self.denominator, x)
        if denominator == 0:
            raise ZeroDivisionError(f"rational function has a pole at {x}")
        return _p_eval(self.numerator, x) / denominator


def as_rat(value: Any) -> Rat:
    if isinstance(value, Rat):
        return value
    if isinstance(value, Fraction):
        return Rat.constant(value)
    if isinstance(value, int):
        return Rat.constant(value)
    raise TypeError(f"cannot convert {type(value).__name__} to Rat")


ZERO = Rat.constant(0)
ONE = Rat.constant(1)


def rat_matrix(rows: int, cols: int) -> list[list[Rat]]:
    return [[ZERO for _ in range(cols)] for _ in range(rows)]


def matrix_sub(left: Sequence[Sequence[Rat]], right: Sequence[Sequence[Rat]]) -> list[list[Rat]]:
    return [[left[i][j] - right[i][j] for j in range(len(left[i]))] for i in range(len(left))]


def matrix_add(left: Sequence[Sequence[Rat]], right: Sequence[Sequence[Rat]]) -> list[list[Rat]]:
    return [[left[i][j] + right[i][j] for j in range(len(left[i]))] for i in range(len(left))]


def matrix_scale(matrix: Sequence[Sequence[Rat]], scalar: Rat) -> list[list[Rat]]:
    return [[scalar * entry for entry in row] for row in matrix]


def determinant(matrix: Sequence[Sequence[Rat]]) -> Rat:
    if not matrix:
        return ONE
    size = len(matrix)
    if any(len(row) != size for row in matrix):
        raise ValueError("determinant requires a square matrix")
    work = [list(row) for row in matrix]
    result = ONE
    sign = 1
    for column in range(size):
        pivot = next((row for row in range(column, size) if work[row][column]), None)
        if pivot is None:
            return ZERO
        if pivot != column:
            work[column], work[pivot] = work[pivot], work[column]
            sign = -sign
        pivot_value = work[column][column]
        result *= pivot_value
        for row in range(column + 1, size):
            if not work[row][column]:
                continue
            factor = work[row][column] / pivot_value
            for entry in range(column + 1, size):
                work[row][entry] -= factor * work[column][entry]
    return result if sign == 1 else -result


def symbolic_solve(left: Sequence[Sequence[Rat]], right: Sequence[Sequence[Rat]]) -> list[list[Rat]]:
    size = len(left)
    if size == 0:
        return []
    width = len(right[0]) if right else 0
    augmented = [list(left[row]) + list(right[row]) for row in range(size)]
    pivot_row = 0
    for column in range(size):
        pivot = next((row for row in range(pivot_row, size) if augmented[row][column]), None)
        if pivot is None:
            raise ValueError("singular symbolic internal Laplacian")
        augmented[pivot_row], augmented[pivot] = augmented[pivot], augmented[pivot_row]
        divisor = augmented[pivot_row][column]
        augmented[pivot_row] = [entry / divisor for entry in augmented[pivot_row]]
        for row in range(size):
            if row == pivot_row:
                continue
            factor = augmented[row][column]
            if factor:
                augmented[row] = [
                    augmented[row][col] - factor * augmented[pivot_row][col]
                    for col in range(size + width)
                ]
        pivot_row += 1
    return [row[size:] for row in augmented]


def graph_nodes(graph: Mapping[str, Any]) -> list[str]:
    result: list[str] = []
    for node in list(graph["ports"]) + list(graph.get("internal", [])):
        if node not in result:
            result.append(node)
    for edge in graph["edges"]:
        for node in (edge["u"], edge["v"]):
            if node not in result:
                result.append(node)
    return result


def graph_response_symbolic(graph: Mapping[str, Any], weights: Mapping[str, Rat]) -> list[list[Rat]]:
    nodes = graph_nodes(graph)
    positions = {node: index for index, node in enumerate(nodes)}
    laplacian = rat_matrix(len(nodes), len(nodes))
    for edge in graph["edges"]:
        conductance = as_rat(weights[edge["id"]])
        u, v = positions[edge["u"]], positions[edge["v"]]
        laplacian[u][u] += conductance
        laplacian[v][v] += conductance
        laplacian[u][v] -= conductance
        laplacian[v][u] -= conductance
    ports = [positions[node] for node in graph["ports"]]
    internals = [positions[node] for node in graph.get("internal", [])]
    l_pp = [[laplacian[row][col] for col in ports] for row in ports]
    if not internals:
        return l_pp
    l_pi = [[laplacian[row][col] for col in internals] for row in ports]
    l_ip = [[laplacian[row][col] for col in ports] for row in internals]
    l_ii = [[laplacian[row][col] for col in internals] for row in internals]
    return matrix_sub(l_pp, _matrix_multiply(l_pi, symbolic_solve(l_ii, l_ip)))


def _matrix_multiply(left: Sequence[Sequence[Rat]], right: Sequence[Sequence[Rat]]) -> list[list[Rat]]:
    if not left or not right:
        return rat_matrix(len(left), len(right[0]) if right else 0)
    return [
        [sum((left[i][k] * right[k][j] for k in range(len(right))), ZERO) for j in range(len(right[0]))]
        for i in range(len(left))
    ]


def submatrix(matrix: Sequence[Sequence[Rat]], rows: Sequence[int], cols: Sequence[int]) -> list[list[Rat]]:
    return [[matrix[row][col] for col in cols] for row in rows]


def response_minor(response: Sequence[Sequence[Rat]], rows: Sequence[int], cols: Sequence[int]) -> Rat:
    return determinant(submatrix(response, rows, cols))


def rank_one(response: Sequence[Sequence[Rat]], index: int) -> list[list[Rat]]:
    return [[response[row][index] * response[index][col] for col in range(len(response))] for row in range(len(response))]


def port_edge_matrix_symbolic(ports: Sequence[str], edge: Mapping[str, str]) -> list[list[Rat]]:
    size = len(ports)
    if edge["u"] not in ports or edge["v"] not in ports:
        raise AlgorithmError(f"edge {edge['id']!r} is not a port-port edge")
    u, v = ports.index(edge["u"]), ports.index(edge["v"])
    update = rat_matrix(size, size)
    update[u][u] += ONE
    update[v][v] += ONE
    update[u][v] -= ONE
    update[v][u] -= ONE
    return update


def clone_matrix(matrix: Sequence[Sequence[Rat]]) -> list[list[Rat]]:
    return [list(row) for row in matrix]


def recover_base_symbolic(base: Mapping[str, Any], initial_response: Sequence[Sequence[Rat]], n: int, layers: int, residue: int) -> dict[str, Any]:
    graph = clone_graph(base)
    response = clone_matrix(initial_response)
    ports = list(base["ports"])
    weights: dict[str, Rat] = {}
    divisions: list[dict[str, Any]] = []
    operations: list[dict[str, Any]] = []

    def record(name: str, numerator: Rat, denominator: Rat) -> None:
        divisions.append({"name": name, "numerator": numerator, "denominator": denominator, "nonzero": bool(denominator)})
        if not denominator:
            raise AlgorithmError(f"zero symbolic denominator in {name}")

    def recover_edge(edge_id: str) -> None:
        nonlocal graph, response
        if os.environ.get("N7_PROBE_VERBOSE"):
            print(f"symbolic recover delete {edge_id}", flush=True)
        edge = edge_by_id(graph, edge_id)
        after = remove_edge(graph, edge_id)
        witness = find_witness(graph, after, n)
        if witness is None:
            raise AlgorithmError(f"no deletion witness for {edge_id}")
        rows, cols = witness["P"], witness["Q"]
        F = response_minor(response, rows, cols)
        update = port_edge_matrix_symbolic(ports, edge)
        D = response_minor(matrix_add(response, update), rows, cols) - F
        record(f"delete:{edge_id}:D", F, D)
        coefficient = F / D
        response = matrix_sub(response, matrix_scale(update, coefficient))
        weights[edge_id] = coefficient
        operations.append({"operation": "delete_edge", "edge_id": edge_id, "witness": dict(witness)})
        graph = after

    def recover_contraction(edge_id: str, port_index: int) -> None:
        nonlocal graph, response
        if os.environ.get("N7_PROBE_VERBOSE"):
            print(f"symbolic recover contract {edge_id}", flush=True)
        port = ports[port_index]
        edge = edge_by_id(graph, edge_id)
        port_degree = sum(port in (candidate["u"], candidate["v"]) for candidate in graph["edges"])
        if port_degree != 1:
            raise AlgorithmError(f"cannot contract {edge_id} at {port}: degree {port_degree}")
        after = contract_port_edge(graph, edge_id, port)
        witness = find_witness(graph, after, n, exclude_ports=(port_index,))
        if witness is None:
            raise AlgorithmError(f"no contraction witness for {edge_id} at {port}")
        rows, cols = witness["P"], witness["Q"]
        F = response_minor(response, rows, cols)
        rank = rank_one(response, port_index)
        B = response_minor(matrix_add(response, rank), rows, cols) - F
        record(f"contract:{edge_id}:F", B, F)
        coefficient = response[port_index][port_index] - B / F
        denominator = coefficient - response[port_index][port_index]
        record(f"contract:{edge_id}:c-Mpp", ONE, denominator)
        response = matrix_add(response, matrix_scale(rank, ONE / denominator))
        weights[edge_id] = coefficient
        operations.append({
            "operation": "contract_radial",
            "edge_id": edge_id,
            "contract_port": port,
            "witness": dict(witness),
        })
        graph = after

    if residue == 2:
        for index in range(-layers, layers + 1):
            if index == 0:
                continue
            edge_id = f"b{'m' + str(-index) if index < 0 else index}"
            if any(edge["id"] == edge_id for edge in graph["edges"]):
                recover_edge(edge_id)

    spike_ids = sorted((edge["id"] for edge in graph["edges"] if edge["id"].startswith("spike_")), key=lambda item: int(item.split("_")[1]))
    for edge_id in spike_ids:
        edge = edge_by_id(graph, edge_id)
        ports_here = [node for node in (edge["u"], edge["v"]) if node in ports]
        if len(ports_here) != 1:
            raise AlgorithmError(f"unexpected spike endpoints {edge}")
        recover_contraction(edge_id, ports.index(ports_here[0]))

    for layer in range(max(0, layers - 1)):
        for index in range(n):
            edge_id = f"c{layer}_{index}"
            if any(edge["id"] == edge_id for edge in graph["edges"]):
                recover_edge(edge_id)
        for index in range(n):
            edge_id = f"rad{layer}_{index}"
            recover_contraction(edge_id, index)

    for edge in graph["edges"]:
        u, v = ports.index(edge["u"]), ports.index(edge["v"])
        weights[edge["id"]] = -response[u][v]
        operations.append({"operation": "final_off_diagonal", "edge_id": edge["id"]})
    return {
        "weights": weights,
        "stripped_response": response,
        "divisions": divisions,
        "operations": operations,
        "graph_after": graph,
    }


def extract_target_symbolic(target: Mapping[str, Any], base: Mapping[str, Any], source_response: Sequence[Sequence[Rat]], n: int, layers: int, residue: int) -> dict[str, Any]:
    if residue != 3:
        raise ValueError("this first probe intentionally fixes the n=7 residue-3 boundary-edge case")
    target_feature_id = f"target_spike_{2 * layers}"
    target_port_index = 2 * layers
    after = contract_port_edge(target, target_feature_id, target["ports"][target_port_index])
    from verify_uniform_minors import minor_indices  # local import keeps predecessor surface explicit

    rows, cols, k = minor_indices(n, layers, residue)
    F = response_minor(source_response, rows, cols)
    B = response_minor(matrix_add(source_response, rank_one(source_response, target_port_index)), rows, cols) - F
    parameter = source_response[target_port_index][target_port_index] - B / F
    denominator = parameter - source_response[target_port_index][target_port_index]
    stripped = matrix_add(source_response, matrix_scale(rank_one(source_response, target_port_index), ONE / denominator))
    return {
        "feature_id": target_feature_id,
        "port_index": target_port_index,
        "witness": {"P": rows, "Q": cols, "k": k},
        "F": F,
        "B": B,
        "parameter": parameter,
        "stripped_response": stripped,
        "target_without_feature": after,
    }


# ---------------------------------------------------------------------------
# Certificate formatting and exact positive-root information.


def polynomial_data(poly: Poly) -> dict[str, Any]:
    integer = _poly_to_ints(poly)
    return {
        "degree": -1 if integer == (0,) else len(integer) - 1,
        "coefficients_low_to_high": [_format_fraction(item) for item in poly],
        "primitive_integer_coefficients_low_to_high": list(integer),
    }


def rational_roots(poly: Poly) -> list[dict[str, Any]]:
    integer = _poly_to_ints(poly)
    if integer == (0,) or len(integer) <= 1:
        return []
    degree = len(integer) - 1
    # Linear and quadratic factors are handled directly.  This avoids trying
    # to enumerate divisors of the large primitive coefficients produced by a
    # perfectly ordinary rational response calculation.
    if degree == 1:
        return [{"root": _format_fraction(-poly[0] / poly[1]), "multiplicity": 1}]
    if degree == 2:
        a, b, c = poly[2], poly[1], poly[0]
        discriminant = b * b - 4 * a * c

        def rational_sqrt(value: Fraction) -> Fraction | None:
            if value < 0:
                return None
            numerator = math.isqrt(value.numerator)
            denominator = math.isqrt(value.denominator)
            if numerator * numerator != value.numerator or denominator * denominator != value.denominator:
                return None
            return Q(numerator, denominator)

        root_sqrt = rational_sqrt(discriminant)
        if root_sqrt is None:
            return []
        roots = [(-b + root_sqrt) / (2 * a)]
        if root_sqrt:
            roots.append((-b - root_sqrt) / (2 * a))
        result: list[dict[str, Any]] = []
        for root in sorted(set(roots)):
            multiplicity = 2 if root_sqrt == 0 else roots.count(root)
            result.append({"root": _format_fraction(root), "multiplicity": multiplicity})
        return result
    # For higher degree factors, retain the exact rational-root theorem only
    # when trial division is bounded.  The positivity report records unresolved
    # factors rather than using a numerical root guess.
    if abs(integer[0]) > 1_000_000 or abs(integer[-1]) > 1_000_000:
        return []
    leading, constant = integer[-1], integer[0]
    if constant == 0:
        roots = [{"root": "0", "multiplicity": 0}]
        while len(integer) > 1 and integer[0] == 0:
            integer = integer[1:]
            roots[0]["multiplicity"] += 1
        return roots

    def divisors(value: int) -> list[int]:
        value = abs(value)
        result: list[int] = []
        for divisor in range(1, int(math.sqrt(value)) + 1):
            if value % divisor == 0:
                result.append(divisor)
                if divisor * divisor != value:
                    result.append(value // divisor)
        return sorted(result)

    candidates = set()
    for numerator in divisors(constant):
        for denominator in divisors(leading):
            candidates.add(Q(numerator, denominator))
            candidates.add(-Q(numerator, denominator))
    result: list[dict[str, Any]] = []
    current = tuple(Q(value) for value in integer)
    for candidate in sorted(candidates):
        multiplicity = 0
        factor = (-(candidate), Q(1))
        while len(current) > 1 and _p_eval(current, candidate) == 0:
            quotient, remainder = _p_divmod(current, factor)
            if remainder != (Q(0),):
                break
            current = quotient
            multiplicity += 1
        if multiplicity:
            result.append({"root": _format_fraction(candidate), "multiplicity": multiplicity})
    return result


def factor_data(poly: Poly) -> dict[str, Any]:
    roots = rational_roots(poly)
    remaining = poly
    for item in roots:
        root = Fraction(item["root"])
        for _ in range(item["multiplicity"]):
            remaining = _p_exact_div(remaining, (-root, Q(1)))
    return {
        "polynomial": polynomial_data(poly),
        "rational_roots": roots,
        "all_roots_resolved_over_Q": sum(item["multiplicity"] for item in roots) == polynomial_data(poly)["degree"],
        "factorization_over_Q": {
            "linear_factors": [
                {"factor": f"(epsilon - ({item['root']}))", "multiplicity": item["multiplicity"]}
                for item in roots
            ],
            "remaining_polynomial": polynomial_data(remaining),
            "reconstruction": "product of the displayed monic linear factors and the displayed remaining polynomial",
        },
    }


def rat_summary(value: Rat) -> dict[str, Any]:
    return {
        "expression": {
            "numerator_coefficients_low_to_high": [_format_fraction(item) for item in value.numerator],
            "denominator_coefficients_low_to_high": [_format_fraction(item) for item in value.denominator],
        },
        "numerator": factor_data(value.numerator),
        "denominator": factor_data(value.denominator),
        "zeros": rational_roots(value.numerator),
        "poles": rational_roots(value.denominator),
        "numerator_degree": value.degree,
        "denominator_degree": value.denominator_degree,
    }


def exact_positive_intervals(weights: Mapping[str, Rat]) -> dict[str, Any]:
    # Rational roots are sufficient for this probe's certificate when every
    # remaining factor has no positive root.  If an unresolved factor remains,
    # we deliberately return an unclassified status instead of guessing.
    critical: set[Fraction] = set()
    unresolved: list[str] = []
    for edge_id, value in weights.items():
        for poly, label in ((value.numerator, "zero"), (value.denominator, "pole")):
            roots = rational_roots(poly)
            critical.update(Q(item["root"]) for item in roots if Q(item["root"]) > 0)
            degree = len(poly) - 1
            if sum(item["multiplicity"] for item in roots) != degree and degree >= 1:
                unresolved.append(f"{edge_id}:{label}")
    if unresolved:
        return {
            "status": "unresolved",
            "reason": "some numerator/denominator factors have roots not represented by rational-root data",
            "unresolved_factors": unresolved,
            "certified_intervals": [],
        }
    ordered = sorted(critical)
    endpoints: list[Fraction | None] = [None] + ordered + [None]
    intervals: list[dict[str, Any]] = []
    for left, right in zip(endpoints, endpoints[1:]):
        if left is None:
            sample = (right / 2) if right is not None else Q(1)
        elif right is None:
            sample = left + 1
        else:
            sample = (left + right) / 2
        values = {edge_id: value.evaluate(sample) for edge_id, value in weights.items()}
        intervals.append({
            "left": "0" if left is None or left == 0 else _format_fraction(left),
            "right": "infinity" if right is None else _format_fraction(right),
            "sample": _format_fraction(sample),
            "all_target_weights_positive": all(value > 0 for value in values.values()),
            "sample_signs": {edge_id: (1 if value > 0 else -1 if value < 0 else 0) for edge_id, value in values.items()},
        })
    return {
        "status": "exact_on_rational_critical_partition",
        "critical_positive_points": [_format_fraction(item) for item in ordered],
        "certified_intervals": intervals,
    }


def fs_value(value: Any) -> Any:
    if isinstance(value, Fraction):
        return _format_fraction(value)
    if isinstance(value, Rat):
        return rat_summary(value)
    if isinstance(value, dict):
        return {str(key): fs_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [fs_value(item) for item in value]
    return value


def matrix_equal(left: Sequence[Sequence[Fraction]], right: Sequence[Sequence[Fraction]]) -> bool:
    return len(left) == len(right) and all(
        len(row_left) == len(row_right) and all(a == b for a, b in zip(row_left, row_right))
        for row_left, row_right in zip(left, right)
    )


def symbolic_matrix_residual_entries(
    left: Sequence[Sequence[Rat]], right: Sequence[Sequence[Rat]]
) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    if len(left) != len(right) or any(len(a) != len(b) for a, b in zip(left, right)):
        return [{"shape_mismatch": True}]
    for row in range(len(left)):
        for column in range(len(left[row])):
            residual = left[row][column] - right[row][column]
            if residual:
                entries.append({"row": row, "column": column, "residual": residual})
    return entries


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def make_baseline(base: Mapping[str, Any]) -> dict[str, Fraction]:
    # Fixed, asymmetric and rational; this is the only inherited parameter
    # choice in the probe.  The source feature c0_0 is replaced by epsilon.
    return {
        edge["id"]: Q(1) + Q((7 * index + 3) % 19, 100)
        for index, edge in enumerate(base["edges"])
    }


def run_probe(samples: Sequence[Fraction]) -> dict[str, Any]:
    n = 7
    source, layers, residue = build_source(n)
    base, target = build_base_and_target(source, n, layers, residue)
    if residue != 3 or layers != 2:
        raise AssertionError("the first probe is fixed to n=7, residue 3, L=2")
    baseline = make_baseline(base)
    epsilon = Rat.variable()
    source_weights = {edge["id"]: Rat.constant(baseline[edge["id"]]) for edge in source["edges"] if edge["id"] in baseline}
    source_weights["c0_0"] = epsilon
    source_response = graph_response_symbolic(source, source_weights)
    extracted = extract_target_symbolic(target, base, source_response, n, layers, residue)
    recovery = recover_base_symbolic(base, extracted["stripped_response"], n, layers, residue)
    target_weights = dict(recovery["weights"])
    target_weights[extracted["feature_id"]] = extracted["parameter"]
    target_response = graph_response_symbolic(target, target_weights)
    symbolic_residuals = symbolic_matrix_residual_entries(source_response, target_response)

    sample_records: list[dict[str, Any]] = []
    for sample in samples:
        source_numeric = dict(baseline)
        source_numeric["c0_0"] = sample
        evaluated_target = {edge_id: value.evaluate(sample) for edge_id, value in target_weights.items()}
        direct_source = fraction_graph_response(source, source_numeric)
        direct_target = fraction_graph_response(target, evaluated_target)
        symbolic_source = [[value.evaluate(sample) for value in row] for row in source_response]
        sample_records.append({
            "epsilon": _format_fraction(sample),
            "all_source_weights_positive": all(value > 0 for value in source_numeric.values()),
            "all_target_weights_positive": all(value > 0 for value in evaluated_target.values()),
            "symbolic_source_equals_fraction_source": matrix_equal(symbolic_source, direct_source),
            "target_equals_source_response": matrix_equal(direct_target, direct_source),
            "target_weights": {edge_id: _format_fraction(value) for edge_id, value in evaluated_target.items()},
        })

    return {
        "scope": "Exact n=7 residue-3 boundary-edge ray: source c0_0=epsilon, asymmetric fixed positive inherited weights, full observed ports (p0,...,p6,z).",
        "interpretation": "The symbolic target weights and the listed sample identities are exact. Positivity is certified only on intervals reported by exact rational critical-point data; no low-degree inference is used.",
        "predecessor_modules": {
            "graph_construction": str((PREDECESSOR / "verify_uniform_minors.py").resolve()),
            "witness_search": str((PREDECESSOR / "verify_uniform_transform.py").resolve()),
            "fraction_response": str((PREDECESSOR / "verify_local_controls.py").resolve()),
            "graph_construction_sha256": sha256_file(PREDECESSOR / "verify_uniform_minors.py"),
            "witness_search_sha256": sha256_file(PREDECESSOR / "verify_uniform_transform.py"),
            "fraction_response_sha256": sha256_file(PREDECESSOR / "verify_local_controls.py"),
        },
        "n": n,
        "layers_L": layers,
        "residue": residue,
        "ports": source["ports"],
        "source_feature": {"edge_id": "c0_0", "conductance": "epsilon"},
        "baseline_inherited_weights": baseline,
        "source_edge_ids": [edge["id"] for edge in source["edges"]],
        "base_edge_ids": [edge["id"] for edge in base["edges"]],
        "target_edge_ids": [edge["id"] for edge in target["edges"]],
        "graph_counts": {
            "source_edges": len(source["edges"]),
            "base_edges": len(base["edges"]),
            "target_edges": len(target["edges"]),
            "target_weights": len(target_weights),
            "checks": {
                "source_is_28": len(source["edges"]) == 28,
                "base_is_27": len(base["edges"]) == 27,
                "target_is_28": len(target["edges"]) == 28,
                "target_weights_match_target": len(target_weights) == len(target["edges"]),
            },
        },
        "target_feature": {"edge_id": extracted["feature_id"], "port_index": extracted["port_index"]},
        "symbolic_full_response_identity": {
            "exact": not symbolic_residuals,
            "dimension": [len(source_response), len(source_response[0])],
            "nonzero_residual_entries": symbolic_residuals,
        },
        "symbolic_target_weights": {edge_id: rat_summary(value) for edge_id, value in sorted(target_weights.items())},
        "symbolic_extraction": {
            "witness": extracted["witness"],
            "F": extracted["F"],
            "B": extracted["B"],
            "parameter": extracted["parameter"],
        },
        "recovery": {
            "operation_count": len(recovery["operations"]),
            "operations": recovery["operations"],
            "division_count": len(recovery["divisions"]),
            "all_symbolic_divisors_nonzero": all(item["nonzero"] for item in recovery["divisions"]),
            "divisions": recovery["divisions"],
        },
        "zeros_poles_degrees": {
            edge_id: {
                "numerator_degree": value.degree,
                "denominator_degree": value.denominator_degree,
                "zeros": rational_roots(value.numerator),
                "poles": rational_roots(value.denominator),
            }
            for edge_id, value in sorted(target_weights.items())
        },
        "positivity": exact_positive_intervals(target_weights),
        "samples": sample_records,
        "all_sample_checks_pass": all(
            record["all_source_weights_positive"]
            and record["symbolic_source_equals_fraction_source"]
            and record["target_equals_source_response"]
            for record in sample_records
        ),
        "all_exact_checks_pass": not symbolic_residuals,
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "n7_symbolic_ray_certificate.json")
    args = parser.parse_args(argv)
    samples = [Q(1, 100), Q(1, 10), Q(1, 2), Q(1), Q(2), Q(10)]
    certificate = fs_value(run_probe(samples))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(certificate, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"certificate: {args.output.resolve()}")
    print(f"all_sample_checks_pass: {certificate['all_sample_checks_pass']}")
    print(f"all_exact_checks_pass: {certificate['all_exact_checks_pass']}")
    print(f"positivity_status: {certificate['positivity']['status']}")
    return 0 if certificate["all_sample_checks_pass"] and certificate["all_exact_checks_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
