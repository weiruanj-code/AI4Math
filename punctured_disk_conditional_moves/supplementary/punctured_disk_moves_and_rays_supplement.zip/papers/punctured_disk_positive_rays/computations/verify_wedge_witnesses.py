#!/usr/bin/env python3
"""Verify the proposed cyclic wedge witnesses for center-edge deletion.

The construction is tested on the target graphs n=3,...,20.  It records the
two linkage ranks, exact determinant checks at two positive assignments, and
a bounded endpoint-pairing parity search.  The parity search may be unknown
for larger ranks; topology checks remain independent of that diagnostic.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from fractions import Fraction
from pathlib import Path
from typing import Any, Mapping

HERE = Path(__file__).resolve().parent
PREDECESSOR = HERE.parents[1] / "punctured_disk_conditional_moves" / "computations"
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
if str(PREDECESSOR) not in sys.path:
    sys.path.insert(0, str(PREDECESSOR))

from center_deletion_minor_probe import (  # noqa: E402
    delete_edge_graph,
    determinant_checks,
    pairing_parity_diagnostic,
)
from verify_uniform_minors import (  # noqa: E402
    build_base_and_target,
    build_source,
    exact_json,
    linkage_count,
    response_minor,
)
from probe_n7_symbolic_ray import make_baseline  # noqa: E402
from verify_local_controls import graph_response  # noqa: E402


def interval_mod(start: int, end: int, n: int) -> set[int]:
    length = (end - start) % n + 1
    return {(start + offset) % n for offset in range(length)}


def target_spike_indices(n: int, layers: int, residue: int) -> set[int]:
    if residue == 3:
        return {2 * layers}
    if residue == 0:
        return set(range(1, 2 * layers + 1))
    if residue == 1:
        return set(range(1, n))
    return set(range(n))


def wedge_sets(
    n: int,
    layers: int,
    residue: int,
    center_index: int,
) -> tuple[tuple[int, ...], tuple[int, ...], dict[str, Any]]:
    """Return the proposed P,Q and the correction bookkeeping."""

    s = center_index
    a = (s - layers) % n
    b = (s + layers) % n
    spike_set = target_spike_indices(n, layers, residue)
    P_set = interval_mod(a + 1, b - 1, n)
    P_set.update(index for index in (a, b) if index in spike_set)
    Q_set = set(range(n)) - P_set
    Q_set.difference_update(index for index in (a, b) if index not in spike_set)
    corrections: dict[str, Any] = {
        "center_index": s,
        "a": a,
        "b": b,
        "target_spike_indices": sorted(spike_set),
        "initial_P": sorted(P_set),
        "initial_Q_outer": sorted(Q_set),
        "corrections": [],
    }
    if residue == 3 and ((a in spike_set) != (b in spike_set)):
        nonspike_gap = b if b not in spike_set else a
        Q_set.add(nonspike_gap)
        corrections["corrections"].append({"type": "residue3_add_nonspike_gap", "index": nonspike_gap})
    elif residue == 1 and (a == 0 or b == 0):
        excluded = (2 * layers + 1) % n if a == 0 else (2 * layers) % n
        Q_set.discard(excluded)
        corrections["corrections"].append({"type": "residue1_exclude_exterior_neighbor", "index": excluded})
    elif residue == 2:
        external_edges = (
            {(index % n) for index in range(-layers, 0)}
            | set(range(1, layers + 1))
            | {(2 * layers + 1) % n}
        )
        left_crossing = (a - 1) % n
        right_crossing = b
        crossing_in_external = [
            index for index in (left_crossing, right_crossing)
            if index in external_edges
        ]
        if len(crossing_in_external) == 1:
            if crossing_in_external[0] == left_crossing:
                excluded = (a - 1) % n
            else:
                excluded = (b + 1) % n
            Q_set.discard(excluded)
            corrections["corrections"].append({
                "type": "residue2_exclude_exterior_neighbor",
                "external_edge_indices": [left_crossing, right_crossing],
                "external_crossing": crossing_in_external[0],
                "index": excluded,
            })
        else:
            corrections["corrections"].append({
                "type": "residue2_crossing_rule_failure",
                "external_edge_indices": [left_crossing, right_crossing],
                "external_crossings": crossing_in_external,
            })
    Q_set.add(n)  # z is the last observed port.
    P = tuple(sorted(P_set))
    Q = tuple(sorted(Q_set))
    corrections["final_P"] = list(P)
    corrections["final_Q"] = list(Q)
    corrections["sizes_equal"] = len(P) == len(Q)
    corrections["disjoint"] = not P_set.intersection(Q_set)
    corrections["z_in_Q"] = n in Q_set
    return P, Q, corrections


def graph_adjacency(graph: Mapping[str, Any]) -> dict[str, set[str]]:
    adjacency: dict[str, set[str]] = {}
    for edge in graph["edges"]:
        adjacency.setdefault(edge["u"], set()).add(edge["v"])
        adjacency.setdefault(edge["v"], set()).add(edge["u"])
    return adjacency


def layer_vertex(graph: Mapping[str, Any], index: int, layer: int) -> str:
    candidates = [f"w{layer}_{index}", f"v{index}"] if layer == 0 else [f"w{layer}_{index}"]
    for candidate in candidates:
        if candidate in graph.get("internal", []) or candidate in graph["ports"]:
            return candidate
    port = f"p{index}"
    if layer == 0 and port in graph["ports"]:
        return port
    raise AssertionError(f"missing layer vertex for index={index}, layer={layer}")


def cyclic_order(start: int, end: int, n: int) -> list[int]:
    return [(start + offset) % n for offset in range((end - start) % n + 1)]


def explicit_pairing(
    n: int,
    layers: int,
    residue: int,
    P: tuple[int, ...],
    Q: tuple[int, ...],
    construction: Mapping[str, Any],
) -> dict[str, Any]:
    """Build the explicit reverse-order pairing prescribed by the wedge proof."""

    s = construction["center_index"] if "center_index" in construction else None
    if s is None:
        raise AssertionError("center index missing from construction")
    a, b = construction["a"], construction["b"]
    D = set(construction["target_spike_indices"])
    q_outer = set(Q) - {n}
    right_count = layers - 1 + int(b in D)
    left_count = layers - 1 + int(a in D)
    interval = [
        index
        for index in cyclic_order((b + 1) % n, (a - 1) % n, n)
        if index in q_outer and index not in (a, b)
    ]
    q_right: list[int]
    q_left: list[int]
    if residue == 3 and ((a in D) != (b in D)):
        if b in D:
            if left_count:
                q_right = interval[:right_count]
                q_left = interval[right_count:] + [a]
            else:
                q_right = [a] + interval[:right_count - 1]
                q_left = interval[right_count - 1:]
        else:
            if right_count:
                q_right = [b] + interval[:right_count - 1]
                q_left = interval[right_count - 1:]
            else:
                q_right = interval[:right_count]
                q_left = interval + [b]
    else:
        q_right = interval[:right_count]
        q_left = interval[right_count:]
    right_p = [(s + r) % n for r in range(1, right_count + 1)]
    left_p = [(s - r) % n for r in range(1, left_count + 1)]
    if len(q_right) != len(right_p) or len(q_left) != len(left_p):
        raise AssertionError(
            f"side count mismatch n={n},s={s}: P=({right_p},{left_p}), Q=({q_right},{q_left})"
        )
    pairing = {s: n}
    # The right-hand P-list is ordered in the same cyclic direction as the
    # right Q-list, so its reverse pairing sends the deepest port to the
    # boundary Q-port.  On the left, the Q-list is written in the opposite
    # (increasing-index) direction; pairing in the displayed order has the
    # same boundary-to-depth effect and avoids crossing the depth-zero arc.
    pairing.update({p: q_right[-1 - index] for index, p in enumerate(right_p)})
    pairing.update({p: q_left[index] for index, p in enumerate(left_p)})
    if (
        set(pairing) != set(P)
        or set(pairing.values()) != (q_outer | {n})
        or len(pairing) != len(P)
    ):
        raise AssertionError(f"pairing does not use all P,Q: {pairing}, P={P}, Q={Q}")
    return {
        "pairing": pairing,
        "right_P": right_p,
        "right_Q_order": q_right,
        "left_P": left_p,
        "left_Q_order": q_left,
    }


def route_port_to_layer(
    graph: Mapping[str, Any], index: int, depth: int
) -> list[str]:
    path = [f"p{index}"]
    outer = layer_vertex(graph, index, 0)
    if path[-1] != outer:
        path.append(outer)
    for layer in range(1, depth + 1):
        path.append(layer_vertex(graph, index, layer))
    return path


def route_layer_to_port(
    graph: Mapping[str, Any], index: int, depth: int
) -> list[str]:
    path = [layer_vertex(graph, index, depth)]
    for layer in range(depth - 1, -1, -1):
        vertex = layer_vertex(graph, index, layer)
        if path[-1] != vertex:
            path.append(vertex)
    port = f"p{index}"
    if path[-1] != port:
        path.append(port)
    return path


def horizontal_route(
    graph: Mapping[str, Any], layer: int, start: int, end: int, direction: int, n: int
) -> list[str]:
    columns = [start]
    current = start
    while current != end:
        current = (current + direction) % n
        columns.append(current)
    return [layer_vertex(graph, index, layer) for index in columns]


def explicit_paths(
    graph: Mapping[str, Any],
    n: int,
    layers: int,
    residue: int,
    P: tuple[int, ...],
    Q: tuple[int, ...],
    construction: Mapping[str, Any],
) -> dict[str, Any]:
    pairing_data = explicit_pairing(n, layers, residue, P, Q, construction)
    s = construction["center_index"]
    paths: dict[str, list[str]] = {}
    center = route_port_to_layer(graph, s, layers - 1)
    center.append("z")
    paths[f"p{s}->z"] = center
    right_count = len(pairing_data["right_P"])
    for r, p in enumerate(pairing_data["right_P"], start=1):
        q = pairing_data["pairing"][p]
        depth = layers - r
        path = route_port_to_layer(graph, p, depth)
        horizontal = horizontal_route(graph, depth, p, q, +1, n)
        path.extend(horizontal[1:])
        path.extend(route_layer_to_port(graph, q, depth)[1:])
        paths[f"p{p}->p{q}"] = path
    for r, p in enumerate(pairing_data["left_P"], start=1):
        q = pairing_data["pairing"][p]
        depth = layers - r
        path = route_port_to_layer(graph, p, depth)
        horizontal = horizontal_route(graph, depth, p, q, -1, n)
        path.extend(horizontal[1:])
        path.extend(route_layer_to_port(graph, q, depth)[1:])
        paths[f"p{p}->p{q}"] = path
    return {"pairing": pairing_data, "paths": paths}


def staircase_cut(
    graph: Mapping[str, Any],
    n: int,
    layers: int,
    residue: int,
    center_index: int,
) -> set[str]:
    a = (center_index - layers) % n
    b = (center_index + layers) % n
    D = target_spike_indices(n, layers, residue)
    cut = {
        layer_vertex(graph, (center_index - (layers - layer)) % n, layer)
        for layer in range(1, layers)
    }
    cut.update(
        layer_vertex(graph, (center_index + (layers - layer)) % n, layer)
        for layer in range(1, layers)
    )
    if a in D:
        cut.add(layer_vertex(graph, a, 0))
    if b in D:
        cut.add(layer_vertex(graph, b, 0))
    return cut


def edge_ids_for_path(graph: Mapping[str, Any], path: list[str]) -> list[str]:
    lookup: dict[frozenset[str], list[str]] = {}
    for edge in graph["edges"]:
        lookup.setdefault(frozenset((edge["u"], edge["v"])), []).append(edge["id"])
    return [lookup[frozenset((u, v))][0] for u, v in zip(path, path[1:])]


def validate_explicit_paths(
    graph: Mapping[str, Any],
    after: Mapping[str, Any],
    P: tuple[int, ...],
    Q: tuple[int, ...],
    path_data: Mapping[str, Any],
    T: set[str],
    require_missing_outer_edge_01: bool,
) -> dict[str, Any]:
    ports = list(graph["ports"])
    adjacency = graph_adjacency(graph)
    paths = path_data["paths"]
    path_vertices = [set(path) for path in paths.values()]
    edge_ids = [edge_id for path in paths.values() for edge_id in edge_ids_for_path(graph, path)]
    endpoint_set = {ports[index] for index in P} | {ports[index] for index in Q}
    shared_vertices = [
        sorted((left & right) - endpoint_set)
        for index, left in enumerate(path_vertices)
        for right in path_vertices[index + 1:]
        if (left & right) - endpoint_set
    ]
    shared_vertices_including_endpoints = [
        sorted(left & right)
        for index, left in enumerate(path_vertices)
        for right in path_vertices[index + 1:]
        if left & right
    ]
    non_simple_paths = [
        name for name, path in paths.items() if len(path) != len(set(path))
    ]
    invalid_edges = [
        (u, v)
        for path in paths.values()
        for u, v in zip(path, path[1:])
        if v not in adjacency.get(u, set())
    ]
    port_interiors = [
        (name, vertex)
        for name, path in paths.items()
        for vertex in path[1:-1]
        if vertex in ports
    ]
    unused_ports = set(ports) - endpoint_set
    after_adjacency = graph_adjacency(after)
    blocked = set(T) | unused_ports
    queue = [ports[index] for index in P if ports[index] not in blocked]
    seen = set(queue)
    while queue:
        node = queue.pop()
        for neighbor in after_adjacency.get(node, set()):
            if neighbor in blocked or neighbor in seen:
                continue
            seen.add(neighbor)
            queue.append(neighbor)
    reachable_Q = sorted(ports[index] for index in Q if ports[index] in seen)
    return {
        "all_edges_exist": not invalid_edges,
        "invalid_edges": invalid_edges,
        "paths_vertex_disjoint_off_endpoints": not shared_vertices,
        "shared_internal_vertices": shared_vertices,
        "paths_vertex_disjoint_including_endpoints": not shared_vertices_including_endpoints,
        "shared_vertices_including_endpoints": shared_vertices_including_endpoints,
        "paths_are_simple": not non_simple_paths,
        "non_simple_paths": non_simple_paths,
        "no_other_port_interiors": not port_interiors,
        "port_interiors": port_interiors,
        "missing_outer_edge_01_unused": (
            ("c0_0" not in edge_ids) if require_missing_outer_edge_01 else True
        ),
        "used_edge_ids": edge_ids,
        "cut_separator_T": sorted(T),
        "cut_size": len(T),
        "P_to_Q_separated_after_center_deletion": not reachable_Q,
        "reachable_Q_after_cut": reachable_Q,
        "all_checks_pass": (
            not invalid_edges
            and not shared_vertices
            and not shared_vertices_including_endpoints
            and not non_simple_paths
            and not port_interiors
            and (("c0_0" not in edge_ids) if require_missing_outer_edge_01 else True)
            and not reachable_Q
        ),
    }


def verify_case(
    n: int,
    source: Mapping[str, Any],
    target: Mapping[str, Any],
    layers: int,
    residue: int,
    started: float,
    time_limit: float,
    parity_budget: float,
) -> dict[str, Any]:
    results: list[dict[str, Any]] = []
    for center_index in range(n):
        P, Q, construction = wedge_sets(n, layers, residue, center_index)
        edge_id = f"center_{center_index}"
        after = delete_edge_graph(target, edge_id)
        before_linkage = linkage_count(target, P, Q)
        after_linkage = linkage_count(after, P, Q)
        witness = {
            "center_index": center_index,
            "edge_id": edge_id,
            "P": P,
            "Q": Q,
            "k": len(P),
            "construction": construction,
            "before_linkage": before_linkage,
            "after_linkage": after_linkage,
            "topological_witness": before_linkage == len(P) and after_linkage < len(P),
        }
        if witness["topological_witness"]:
            witness["determinant_checks"] = determinant_checks(target, after, witness)
            witness["determinant_checks_pass"] = all(
                item["before_nonzero"] and item["after_zero"]
                for item in witness["determinant_checks"]
            )
            cut = staircase_cut(target, n, layers, residue, center_index)
            path_data = explicit_paths(
                target, n, layers, residue, P, Q, construction
            )
            witness["explicit_path_data"] = path_data
            witness["explicit_path_checks"] = validate_explicit_paths(
                target, after, P, Q, path_data, cut, residue == 3
            )
            witness["staircase_cut_size"] = len(cut)
            witness["staircase_cut_size_expected"] = len(P) - 1
            if parity_budget <= 0:
                witness["pairing_parity"] = {
                    "status": "not_attempted",
                    "reason": "parity budget is zero",
                }
            else:
                parity_deadline = min(
                    started + time_limit,
                    time.monotonic() + parity_budget,
                )
                witness["pairing_parity"] = pairing_parity_diagnostic(
                    target, P, Q, parity_deadline
                )
        else:
            witness["determinant_checks_pass"] = False
            witness["pairing_parity"] = {"status": "not_applicable"}
        results.append(witness)
        if time.monotonic() - started >= time_limit:
            return {
                "n": n,
                "layers_L": layers,
                "residue": residue,
                "status": "timeout",
                "results": results,
            }
    return {
        "n": n,
        "layers_L": layers,
        "residue": residue,
        "status": "complete",
        "results": results,
        "all_sizes_disjoint_z": all(
            item["construction"]["sizes_equal"]
            and item["construction"]["disjoint"]
            and item["construction"]["z_in_Q"]
            for item in results
        ),
        "all_topological_witnesses": all(item["topological_witness"] for item in results),
        "all_determinant_checks_pass": all(item["determinant_checks_pass"] for item in results),
        "all_explicit_path_checks_pass": all(
            item.get("explicit_path_checks", {}).get("all_checks_pass", False)
            and item.get("staircase_cut_size") == item.get("staircase_cut_size_expected")
            for item in results
        ),
        "parity_status_counts": {
            status: sum(item["pairing_parity"].get("status") == status for item in results)
            for status in sorted({item["pairing_parity"].get("status") for item in results})
        },
        "parity_violations": [
            {
                "center_index": item["center_index"],
                "P": item["P"],
                "Q": item["Q"],
                "parities": item["pairing_parity"]["parities"],
            }
            for item in results
            if item["pairing_parity"].get("status") == "complete"
            and item["pairing_parity"].get("same_parity") is False
        ],
    }


def n7_threshold_check() -> dict[str, Any]:
    """Check the known n=7 ray threshold from the wedge minors.

    The source edge ``c0_0`` is the ray parameter.  Since it is a boundary
    edge, the response has the exact rank-one interpolation
    ``M(epsilon)=M(0)+epsilon*(M(1)-M(0))``.  Each signed wedge minor is
    therefore affine in epsilon.  The sign is fixed by the corresponding
    all-one target minor so that the witness is positive at the control point.
    """

    n = 7
    source, layers, residue = build_source(n)
    base, target = build_base_and_target(source, n, layers, residue)
    baseline = make_baseline(base)

    def source_weights(epsilon: Fraction) -> dict[str, Fraction]:
        return {
            edge["id"]: (
                baseline[edge["id"]] if edge["id"] in baseline else Fraction(0)
            )
            for edge in source["edges"]
        } | {"c0_0": epsilon}

    source_zero = graph_response(source, source_weights(Fraction(0)))
    source_one = graph_response(source, source_weights(Fraction(1)))
    source_two = graph_response(source, source_weights(Fraction(2)))
    target_all_one = graph_response(
        target, {edge["id"]: Fraction(1) for edge in target["edges"]}
    )
    records: list[dict[str, Any]] = []
    positive_roots: list[Fraction] = []
    for center_index in range(n):
        P, Q, construction = wedge_sets(n, layers, residue, center_index)
        raw_control = response_minor(target_all_one, P, Q)
        sign = 1 if raw_control > 0 else -1 if raw_control < 0 else 0
        alpha_raw = response_minor(source_zero, P, Q)
        beta_raw = response_minor(source_one, P, Q) - alpha_raw
        value_two_raw = response_minor(source_two, P, Q)
        affine_prediction_two_raw = alpha_raw + 2 * beta_raw
        affine_residual_at_two = value_two_raw - affine_prediction_two_raw
        alpha = sign * alpha_raw
        beta = sign * beta_raw
        root = -alpha / beta if alpha > 0 and beta < 0 else None
        if root is not None:
            positive_roots.append(root)
        records.append({
            "center_index": center_index,
            "P": P,
            "Q": Q,
            "control_minor_all_one_target": raw_control,
            "control_sign": sign,
            "alpha_f_M0": alpha,
            "beta_f_M1_minus_M0": beta,
            "positive_root_if_beta_negative": root,
            "minor_at_epsilon_2_raw": value_two_raw,
            "affine_prediction_at_epsilon_2_raw": affine_prediction_two_raw,
            "affine_residual_at_epsilon_2_raw": affine_residual_at_two,
            "affine_identity_checked_at_third_point": affine_residual_at_two == 0,
        })

    expected = Fraction(54997063108, 61616096925)
    minimum = min(positive_roots) if positive_roots else None
    return {
        "status": "exact",
        "n": n,
        "layers_L": layers,
        "residue": residue,
        "source_feature": "c0_0=epsilon",
        "baseline_inherited_weights": baseline,
        "records": records,
        "positive_roots": positive_roots,
        "minimum_positive_root": minimum,
        "expected_minimum_positive_root": expected,
        "affine_identity_all_records_pass": all(
            record["affine_identity_checked_at_third_point"] for record in records
        ),
        "matches_expected": (
            minimum == expected
            and all(record["affine_identity_checked_at_third_point"] for record in records)
        ),
    }


def run(output: Path, checkpoint: Path, n_min: int, n_max: int, time_limit: float, parity_budget: float) -> dict[str, Any]:
    started = time.monotonic()
    cases: list[dict[str, Any]] = []
    for n in range(n_min, n_max + 1):
        if time.monotonic() - started >= time_limit:
            break
        source, layers, residue = build_source(n)
        _base, target = build_base_and_target(source, n, layers, residue)
        case = verify_case(n, source, target, layers, residue, started, time_limit, parity_budget)
        cases.append(case)
        checkpoint.parent.mkdir(parents=True, exist_ok=True)
        checkpoint.write_text(json.dumps(exact_json({
            "status": "timed_out" if case["status"] == "timeout" else "in_progress",
            "completed_n_values": [item["n"] for item in cases if item["status"] == "complete"],
            "last_started_n": n,
            "timed_out_n_values": [item["n"] for item in cases if item["status"] == "timeout"],
            "elapsed_seconds": time.monotonic() - started,
        }), indent=2) + "\n", encoding="utf-8")
        if case["status"] == "timeout":
            break
    requested_n_values = list(range(n_min, n_max + 1))
    completed_n_values = [case["n"] for case in cases if case["status"] == "complete"]
    timed_out_n_values = [case["n"] for case in cases if case["status"] == "timeout"]
    missing_n_values = [n for n in requested_n_values if n not in {case["n"] for case in cases}]
    run_status = (
        "complete"
        if completed_n_values == requested_n_values
        else "timed_out"
        if timed_out_n_values
        else "incomplete"
    )
    n7_check = n7_threshold_check()
    validation_failed = (
        any(
            not case.get("all_topological_witnesses", False)
            or not case.get("all_determinant_checks_pass", False)
            or not case.get("all_explicit_path_checks_pass", False)
            for case in cases
            if case["status"] == "complete"
        )
        or not n7_check["matches_expected"]
    )
    certificate = {
        "scope": f"Cyclic wedge witnesses for target center deletion, n=3,...,{n_max}.",
        "diagnostic_status": "Finite exact topology/determinant test; parity may be bounded-unknown for large ranks.",
        "run_status": run_status,
        "validation_failed": validation_failed,
        "requested_n_values": requested_n_values,
        "cases": cases,
        "completed_n_values": completed_n_values,
        "timed_out_n_values": timed_out_n_values,
        "missing_n_values": missing_n_values,
        "all_completed_topological_witnesses": all(
            case.get("all_topological_witnesses", False) for case in cases if case["status"] == "complete"
        ),
        "all_completed_determinant_checks_pass": all(
            case.get("all_determinant_checks_pass", False) for case in cases if case["status"] == "complete"
        ),
        "all_completed_explicit_path_checks_pass": all(
            case.get("all_explicit_path_checks_pass", False)
            for case in cases if case["status"] == "complete"
        ),
        "parity_violations": [
            {"n": case["n"], **violation}
            for case in cases
            for violation in case.get("parity_violations", [])
        ],
        "n7_threshold_check": n7_check,
        "elapsed_seconds": time.monotonic() - started,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(exact_json(certificate), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    checkpoint.write_text(json.dumps(exact_json({
        "status": run_status,
        "validation_failed": validation_failed,
        "requested_n_values": requested_n_values,
        "completed_n_values": certificate["completed_n_values"],
        "timed_out_n_values": timed_out_n_values,
        "missing_n_values": missing_n_values,
        "elapsed_seconds": certificate["elapsed_seconds"],
    }), indent=2) + "\n", encoding="utf-8")
    return certificate


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=HERE / "wedge_witness_certificate.json")
    parser.add_argument("--checkpoint", type=Path, default=HERE / "wedge_witness_checkpoint.json")
    parser.add_argument("--n-min", type=int, default=3)
    parser.add_argument("--n-max", type=int, default=20)
    parser.add_argument("--time-limit", type=float, default=55.0)
    parser.add_argument("--parity-budget", type=float, default=0.5)
    args = parser.parse_args(argv)
    certificate = run(args.output, args.checkpoint, args.n_min, args.n_max, args.time_limit, args.parity_budget)
    print(f"certificate: {args.output.resolve()}")
    print(f"run_status: {certificate['run_status']}")
    print(f"validation_failed: {certificate['validation_failed']}")
    print(f"completed_n_values: {certificate['completed_n_values']}")
    print(f"all_completed_topological_witnesses: {certificate['all_completed_topological_witnesses']}")
    print(f"all_completed_determinant_checks_pass: {certificate['all_completed_determinant_checks_pass']}")
    print(f"all_completed_explicit_path_checks_pass: {certificate['all_completed_explicit_path_checks_pass']}")
    print(f"parity_violation_count: {len(certificate['parity_violations'])}")
    print(f"elapsed_seconds: {certificate['elapsed_seconds']:.3f}")
    if certificate["validation_failed"]:
        return 1
    if certificate["run_status"] != "complete":
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
